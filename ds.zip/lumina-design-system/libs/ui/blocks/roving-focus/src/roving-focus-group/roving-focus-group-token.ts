import { FactoryProvider, InjectionToken, Type, inject } from '@angular/core';
import { LudsRovingFocusGroup } from './roving-focus-group';

export const LudsRovingFocusGroupToken = new InjectionToken<LudsRovingFocusGroup>(
  'LudsRovingFocusGroupToken',
);

/**
 * Injeta a instância da diretiva RovingFocusGroup
 * @returns A instância da diretiva RovingFocusGroup
 */
export function injectRovingFocusGroup(): LudsRovingFocusGroup {
  return inject(LudsRovingFocusGroupToken);
}

export interface LudsRovingFocusGroupOptions {
  /**
   * Indica se deve-se herdar o grupo de foco do elemento pai
   * @default true
   */
  inherit?: boolean;
}

/**
 * Fornece a instância da diretiva RovingFocusGroup
 * @param type O tipo da diretiva RovingFocusGroup
 * @returns O token de RovingFocusGroup
 */
export function provideRovingFocusGroup(
  type: Type<LudsRovingFocusGroup>,
  { inherit = true }: LudsRovingFocusGroupOptions = {},
): FactoryProvider {
  return {
    provide: LudsRovingFocusGroupToken,
    // Roving focus groups podem ser aninhados, nesse caso, o grupo pai deve ser utilizado
    useFactory: () => {
      if (!inherit) {
        return inject(type, { self: true });
      }

      // Se o grupo pai não for encontrado, retorna o grupo atual
      // Útil para grupos aninhados
      return (
        inject(LudsRovingFocusGroupToken, { skipSelf: true, optional: true }) ??
        inject(type, { self: true })
      );
    },
  };
}
