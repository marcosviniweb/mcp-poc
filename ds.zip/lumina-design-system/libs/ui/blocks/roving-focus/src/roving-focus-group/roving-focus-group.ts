import { FocusOrigin } from '@angular/cdk/a11y';
import { Directionality } from '@angular/cdk/bidi';
import { BooleanInput } from '@angular/cdk/coercion';
import { booleanAttribute, Directive, inject, input, signal } from '@angular/core';
import { LudsRovingFocusItem } from '../roving-focus-item/roving-focus-item';
import { provideRovingFocusGroupState, rovingFocusGroupState } from './roving-focus-group-state';
import { provideRovingFocusGroup } from './roving-focus-group-token';
import { LudsOrientation } from '@luds/ui/blocks/common';

/**
 * Aplica a diretiva `ludsRovingFocusGroup` para gerenciar o foco entre os elementos filhos de um grupo.
 */
@Directive({
  selector: '[ludsRovingFocusGroup]',
  exportAs: 'ludsRovingFocusGroup',
  providers: [provideRovingFocusGroup(LudsRovingFocusGroup), provideRovingFocusGroupState()],
  standalone: true
})
export class LudsRovingFocusGroup {
  /**
   * Acessa o serviço de direcionalidade.
   */
  private readonly directionality = inject(Directionality);

  /**
   * Determina a orientação do roving focus group.
   * @default 'horizontal'
   */
  readonly orientation = input<LudsOrientation>('horizontal', {
    alias: 'ludsRovingFocusGroupOrientation',
  });

  /**
   * Determina se o foco deve circular ao atingir o início ou o fim.
   */
  readonly wrap = input<boolean, BooleanInput>(true, {
    alias: 'ludsRovingFocusGroupWrap',
    transform: booleanAttribute,
  });

  /**
   * Determina se as teclas Home e End devem navegar para o primeiro e o último item.
   */
  readonly homeEnd = input<boolean, BooleanInput>(true, {
    alias: 'ludsRovingFocusGroupHomeEnd',
    transform: booleanAttribute,
  });

  /**
   * Determina se o roving focus group está desabilitado.
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsRovingFocusGroupDisabled',
    transform: booleanAttribute,
  });

  /**
   * Armazena os itens no roving focus group.
   */
  private readonly items = signal<LudsRovingFocusItem[]>([]);

  /**
   * Obtém os itens, ordenados por ordem, do roving focus group.
   */
  private get sortedItems() {
    return this.items().sort((a, b) => {
      // sort the items by their position in the document
      // ordena os itens pela posição no documento
      return a.elementRef.nativeElement.compareDocumentPosition(b.elementRef.nativeElement) &
        Node.DOCUMENT_POSITION_FOLLOWING
        ? -1
        : 1;
    });
  }

  /**
   * Armazena o item ativo no roving focus group.
   * @internal
   */
  readonly activeItem = signal<LudsRovingFocusItem | null>(null);

  /**
   * O estado do roving focus group.
   */
  readonly state = rovingFocusGroupState<LudsRovingFocusGroup>(this);

  /**
   * Registra um item no roving focus group.
   * @internal
   * @param item O item a ser registrado
   */
  register(item: LudsRovingFocusItem): void {
    this.items.update(items => [...items, item]);

    // se não houver item ativo, torna o primeiro item o item focável
    if (!this.activeItem()) {
      this.activeItem.set(item);
    }
  }

  /**
   * Remove o registro de um item do roving focus group.
   * @param item O item a ser removido
   */
  unregister(item: LudsRovingFocusItem): void {
    this.items.update(items => items.filter(i => i !== item));

    // verifica se o item removido é o item ativo
    if (this.activeItem() === item) {
      // se o item ativo for removido, ativa o primeiro item
      this.activeItem.set(this.items()[0] ?? null);
    }
  }

  /**
   * Ativa um item no roving focus group.
   * @param item O item a ser ativado
   * @param origin A origem da mudança de foco
   */
  setActiveItem(item: LudsRovingFocusItem | null, origin: FocusOrigin = 'program'): void {
    if (item?.disabled() || item?.error()) return;
    this.activeItem.set(item);
    item?.focus(origin);
  }

  /**
   * Ativa o primeiro item do roving focus group.
   * @param origin A origem da mudança de foco
   */
  private activateFirstItem(origin: FocusOrigin): void {
    // encontra o primeiro item que não está desabilitado
    const item = this.sortedItems.find(i => !i.disabled() && !i.error()) ?? null;

    // define o primeiro item como o item ativo
    this.setActiveItem(item, origin);
  }

  /**
   * Ativa o último item do roving focus group.
   * @param origin A origem da mudança de foco
   */
  private activateLastItem(origin: FocusOrigin): void {
    // encontra o último item que não está desabilitado
    const item = [...this.sortedItems].reverse().find(i => !i.disabled() && !i.error()) ?? null;

    // define o último item como o item ativo
    this.setActiveItem(item, origin);
  }

  /**
   * Ativa o próximo item do roving focus group.
   * @param origin A origem da mudança de foco
   */
  private activateNextItem(origin: FocusOrigin): void {
    const activeItem = this.activeItem();

    // se não houver item ativo, ativa o primeiro item
    if (!activeItem) {
      this.activateFirstItem(origin);
      return;
    }

    // encontra o índice do item ativo
    const index = this.sortedItems.indexOf(activeItem);

    // encontra o próximo item que não está desabilitado/erro
    const item = this.sortedItems.slice(index + 1).find(i => !i.disabled() && !i.error()) ?? null;

    // se estiver no final da lista, volta para o início
    if (!item && this.state.wrap()) {
      this.activateFirstItem(origin);
      return;
    }

    // se não houver próximo item, não faz nada
    if (!item) {
      return;
    }

    // define o próximo item como o item ativo
    this.setActiveItem(item, origin);
  }

  /**
   * Ativa o item anterior do roving focus group.
   * @param origin A origem da mudança de foco
   */
  private activatePreviousItem(origin: FocusOrigin): void {
    const activeItem = this.activeItem();

    // se não houver item ativo, ativa o último item
    if (!activeItem) {
      this.activateLastItem(origin);
      return;
    }

    // encontra o índice do item ativo
    const index = this.sortedItems.indexOf(activeItem);

    // encontra o item anterior que não está desabilitado/erro
    const item =
      this.sortedItems
        .slice(0, index)
        .reverse()
        .find(i => !i.disabled() && !i.error()) ?? null;

    // se estiver no início da lista, volta para o final
    if (!item && this.state.wrap()) {
      this.activateLastItem(origin);
      return;
    }

    // se não houver item anterior, não faz nada
    if (!item) {
      return;
    }

    // define o item anterior como o item ativo
    this.setActiveItem(item, origin);
  }

  /**
   * Responsável pela navegação por teclado do roving focus group.
   * @internal
   * @param event O evento de teclado
   */
  onKeydown(event: KeyboardEvent): void {
    if (this.state.disabled()) {
      return;
    }

    switch (event.key) {
      case 'ArrowUp':
        if (this.state.orientation() === 'vertical') {
          event.preventDefault();
          this.activatePreviousItem('keyboard');
        }
        break;
      case 'ArrowDown':
        if (this.state.orientation() === 'vertical') {
          event.preventDefault();
          this.activateNextItem('keyboard');
        }
        break;
      case 'ArrowLeft':
        if (this.state.orientation() === 'horizontal') {
          event.preventDefault();

          if (this.directionality.value === 'ltr') {
            this.activatePreviousItem('keyboard');
          } else {
            this.activateNextItem('keyboard');
          }
        }
        break;
      case 'ArrowRight':
        if (this.state.orientation() === 'horizontal') {
          event.preventDefault();

          if (this.directionality.value === 'ltr') {
            this.activateNextItem('keyboard');
          } else {
            this.activatePreviousItem('keyboard');
          }
        }
        break;
      case 'Home':
        if (this.state.homeEnd()) {
          event.preventDefault();
          this.activateFirstItem('keyboard');
        }
        break;
      case 'End':
        if (this.state.homeEnd()) {
          event.preventDefault();
          this.activateLastItem('keyboard');
        }
        break;
    }
  }
}
