import { render } from '@testing-library/angular';
import { LudsRovingFocusGroup } from './roving-focus-group';
import { describe, it } from 'vitest';

describe('LudsRovingFocusGroup', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsRovingFocusGroup></div>`, {
      imports: [LudsRovingFocusGroup],
    });
  });
});
