import { createState, createStateInjector, createStateProvider, createStateToken } from '@luds/ui/blocks/state';
import type { LudsRovingFocusGroup } from './roving-focus-group';

/**
 * O token de estado para o componente RovingFocusGroup.
 */
export const LudsRovingFocusGroupStateToken =
  createStateToken<LudsRovingFocusGroup>('RovingFocusGroup');

/**
 * Fornece o estado do RovingFocusGroup.
 */
export const provideRovingFocusGroupState = createStateProvider(LudsRovingFocusGroupStateToken);

/**
 * Injeta o estado do RovingFocusGroup.
 */
export const injectRovingFocusGroupState = createStateInjector<LudsRovingFocusGroup>(
  LudsRovingFocusGroupStateToken,
);

/**
 * Função de registro de estado do RovingFocusGroup.
 */
export const rovingFocusGroupState = createState(LudsRovingFocusGroupStateToken);
