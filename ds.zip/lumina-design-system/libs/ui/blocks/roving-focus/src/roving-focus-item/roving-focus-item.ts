import { FocusMonitor, FocusOrigin } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import {
  Directive,
  ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  booleanAttribute,
  computed,
  inject,
  input,
} from '@angular/core';
import { injectRovingFocusGroup } from '../roving-focus-group/roving-focus-group-token';

/**L * Aplique a diretiva `ludsRovingFocusItem` a um elemento dentro de um roving focus group para gerenciar o foco de forma automática.
 */
@Directive({
  selector: '[ludsRovingFocusItem]',
  exportAs: 'ludsRovingFocusItem',
  host: {
    '[attr.tabindex]': 'tabindex()',
  },
  standalone: true
})
export class LudsRovingFocusItem implements OnInit, OnDestroy {
  /**
   * Acessa o grupo ao qual o roving focus item pertence.
   */
  private readonly group = injectRovingFocusGroup();

  /**
   * Acessa o serviço de monitoramento de foco.
   */
  private readonly focusMonitor = inject(FocusMonitor);

  /**
   * Acessa o elemento ao qual o roving focus item está vinculado.
   */
  readonly elementRef = inject<ElementRef<HTMLElement>>(ElementRef);

  /**
   * Define se o item está desabilitado.
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsRovingFocusItemDisabled',
    transform: booleanAttribute,
  });

  /**
   * Indica se o item apresenta erro.
   * @default false
   */
  readonly error = input<boolean, BooleanInput>(false, {
    alias: 'ludsRovingFocusItemError',
    transform: booleanAttribute,
  });

  /**
   * Determina o tabindex do roving focus item.
   */
  readonly tabindex = computed(() =>
    !this.group.disabled() && this.group.activeItem() === this ? 0 : -1,
  );

  /**
   * Inicializa o roving focus item.
   */
  ngOnInit(): void {
    this.group.register(this);
  }

  /**
   * Limpa o roving focus item.
   */
  ngOnDestroy(): void {
    this.group.unregister(this);
  }

  /**
   * Encaminha o evento de keydown do teclado (quando alguma tecla é pressionada) para o grupo de roving focus item.
   * @param event O evento de teclado
   */
  @HostListener('keydown', ['$event'])
  protected onKeydown(event: KeyboardEvent): void {
    if (this.disabled() || this.error()) {
      return;
    }

    this.group.onKeydown(event);
  }

  /**
   * Ativa o roving focus item ao clicar.
   */
  @HostListener('click')
  protected activate(): void {
    if (this.disabled() || this.error()) {
      return;
    }

    this.group.setActiveItem(this, 'mouse');
  }

  /**
   * Foca o roving focus item.
   * @param origin A origem do foco
   */
  focus(origin: FocusOrigin): void {
    this.focusMonitor.focusVia(this.elementRef, origin);
  }
}
