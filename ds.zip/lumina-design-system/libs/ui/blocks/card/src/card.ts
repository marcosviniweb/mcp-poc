import { Directive, input, signal, computed, output, effect, inject } from "@angular/core";
import { uniqueId } from "@luds/ui/blocks/utils";

/**
 * Variantes de card disponíveis que determinam o estilo visual.
 */
export type LudsCardVariant = "low-contrast" | "high-contrast";

/**
 * Tamanhos de card disponíveis que determinam o estilo visual.
 */
export type LudsCardSize = "small" | "medium" | "large";

/**
 * Aplique a diretiva `ludsCard` para criar cards estruturados.
 * Esta diretiva fornece um container principal que agrupa e exibe informações de forma clara,
 * compacta e organizada, oferecendo uma estrutura modular que facilita a leitura e a interação
 * do usuário com o conteúdo apresentado.
 */
@Directive({
  selector: "[ludsCard]",
  exportAs: "ludsCard",
  providers: [],
  host: {
    "[attr.data-variant]": "variant()",
    "[attr.data-size]": "size()",
  },
  standalone: true,
})
export class LudsCard {
  public variant = input<LudsCardVariant>("high-contrast");
  public size = input<LudsCardSize>("small");
}

/**
 * Aplique a diretiva `ludsCardHeader` para criar o cabeçalho do card.
 * Esta área geralmente contém ícones, imagens ou elementos visuais que identificam
 * o tipo ou categoria do conteúdo do card.
 */
@Directive({
  selector: "[ludsCardHeader]",
  exportAs: "ludsCardHeader",
  standalone: true,
})
export class LudsCardHeader {}

/**
 * Aplique a diretiva `ludsCardHeaderBar` para criar uma barra de ações no topo do card.
 * Esta área é ideal para agrupar ícones e botões de ação que devem aparecer
 * alinhados horizontalmente no cabeçalho do card.
 */
@Directive({
  selector: "[ludsCardHeaderBar]",
  exportAs: "ludsCardHeaderBar",
  standalone: true,
})
export class LudsCardHeaderBar {}

/**
 * Aplique a diretiva `ludsCardAction` para criar uma área de ações do card.
 * Esta área é especialmente útil para cards que precisam de botões de ação alinhados
 * verticalmente ou em posições específicas dentro do layout.
 */
@Directive({
  selector: "[ludsCardAction]",
  exportAs: "ludsCardAction",
  standalone: true,
})
export class LudsCardAction {}

/**
 * Aplique a diretiva `ludsCardIcon` para estilizar ícones dentro do card.
 * Esta diretiva aplica o tamanho e a cor adequados conforme o design system.
 */
@Directive({
  selector: "[ludsCardIcon]",
  exportAs: "ludsCardIcon",
  standalone: true,
})
export class LudsCardIcon {}

/**
 * Aplique a diretiva `ludsCardFooter` para criar o rodapé do card.
 * Esta área geralmente contém botões de ação, links ou informações complementares
 * que devem aparecer na parte inferior do card.
 */
@Directive({
  selector: "[ludsCardFooter]",
  exportAs: "ludsCardFooter",
  standalone: true,
})
export class LudsCardFooter {}

/**
 * Aplique a diretiva `ludsCardTitle` para criar títulos dentro do card.
 * Esta diretiva aplica os estilos tipográficos adequados para títulos.
 */
@Directive({
  selector: "[ludsCardTitle]",
  exportAs: "ludsCardTitle",
  standalone: true,
})
export class LudsCardTitle {
}

/**
 * Aplique a diretiva `ludsCardContainer` para criar o container principal do conteúdo do card.
 * Esta diretiva organiza o layout interno e define o espaçamento adequado
 * entre os diferentes elementos do card.
 */
@Directive({
  selector: "[ludsCardContainer]",
  exportAs: "ludsCardContainer",
  standalone: true,
})
export class LudsCardContainer {}

/**
 * Aplique a diretiva `ludsCardBody` para criar o corpo principal do card.
 * Esta área contém o conteúdo principal, como título e descrição, organizados verticalmente
 * com espaçamento adequado.
 */
@Directive({
  selector: "[ludsCardBody]",
  exportAs: "ludsCardBody",
  standalone: true,
})
export class LudsCardBody {}

/**
 * Aplique a diretiva `ludsCardDescription` para criar descrições dentro do card.
 * Esta diretiva aplica os estilos tipográficos adequados para
 * textos descritivos secundários.
 */
@Directive({
  selector: "[ludsCardDescription]",
  exportAs: "ludsCardDescription",
  standalone: true,
})
export class LudsCardDescription {
}

/**
 * Aplique a diretiva `ludsCardOptionalText` para criar textos opcionais ou complementares dentro do card.
 * Esta diretiva aplica estilos especiais para informações adicionais que não fazem parte do conteúdo principal.
 */
@Directive({
  selector: "[ludsCardOptionalText]",
  exportAs: "ludsCardOptionalText",
  standalone: true,
})
export class LudsCardOptionalText {}
/**
 * Service para gerenciar o estado de expansão dos cards.
 * Garante que apenas um card esteja expandido por vez no mesmo container.
 */
export class LudsCardExpandService {
  private readonly expandedCardId = signal<string | null>(null);

  /**
   * Alterna o estado de expansão de um card.
   */
  toggle(cardId: string): void {
    this.expandedCardId.update((current) => (current === cardId ? null : cardId));
  }

  /**
   * Verifica se um card específico está expandido.
   */
  isExpanded(cardId: string): boolean {
    return this.expandedCardId() === cardId;
  }
}

/**
 * Container que fornece um contexto isolado para cards expansíveis.
 * Cada container mantém seu próprio estado de expansão.
 */
@Directive({
  selector: "[ludsCardExpandContainer]",
  exportAs: "ludsCardExpandContainer",
  providers: [LudsCardExpandService],
  standalone: true,
})
export class LudsCardExpandContainer {}

/**
 * Ícone clicável para expandir/recolher cards.
 */
@Directive({
  selector: "[ludsCardExpandIcon]",
  exportAs: "ludsCardExpandIcon",
  host: {
    "[attr.data-expanded]": "isExpanded()",
    "(click)": "toggle()",
    "[style.cursor]": '"pointer"',
  },
  standalone: true,
})
export class LudsCardExpandIcon {
  private readonly expandService = inject(LudsCardExpandService);
  private readonly cardExpandable = inject(LudsCardExpandable);

  readonly expandedChange = output<boolean>();
  readonly isExpanded = computed(() => this.expandService.isExpanded(this.cardExpandable.id()));

  constructor() {
    effect(() => {
      this.expandedChange.emit(this.isExpanded());
    });
  }

  toggle(): void {
    this.expandService.toggle(this.cardExpandable.id());
  }
}

/**
 * Torna um card expansível dentro de um container.
 */
@Directive({
  selector: "[ludsCardExpandable]",
  exportAs: "ludsCardExpandable",
  host: {
    "[attr.data-expanded]": 'isExpanded() ? "" : null',
    "[attr.id]": "id()",
  },
  standalone: true,
})
export class LudsCardExpandable {
  private readonly expandService = inject(LudsCardExpandService);

  readonly id = input(uniqueId("luds-card"));
  readonly isExpanded = computed(() => this.expandService.isExpanded(this.id()));

  toggle(): void {
    this.expandService.toggle(this.id());
  }
}
