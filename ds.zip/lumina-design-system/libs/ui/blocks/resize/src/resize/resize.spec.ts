import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { render } from '@testing-library/angular';
import { LudsResize } from './resize';
import { Dimensions } from '../utils/resize';

@Component({
  selector: 'test-component',
  standalone: true,
  imports: [LudsResize],
  template: `
    <div data-testid="resize-container" ludsResize (ludsResize)="onResize($event)" style="width: 100px; height: 100px;"></div>
  `,
})
class TestComponent {
  resized = false;
  lastDimensions: Dimensions | null = null;

  onResize(dimensions: Dimensions): void {
    this.resized = true;
    this.lastDimensions = dimensions;
  }
}

describe('LudsResize', () => {
  // Make sure we mock ResizeObserver before tests
  let mockResizeObserve: any;
  let mockResizeDisconnect: any;
  
  beforeEach(async () => {
    // Create a mock ResizeObserver for all tests
    mockResizeObserve = vi.fn();
    mockResizeDisconnect = vi.fn();
    
    // @ts-ignore - override ResizeObserver for test
    global.ResizeObserver = vi.fn().mockImplementation(() => ({
      observe: mockResizeObserve,
      disconnect: mockResizeDisconnect,
    }));
    
    await TestBed.configureTestingModule({
      imports: [TestComponent]
    }).compileComponents();
  });

  it('should initialize correctly', async () => {
    // Use TestComponent which already imports ludsResize as standalone
    const fixture = TestBed.createComponent(TestComponent);
    fixture.detectChanges();
    
    const container = fixture.nativeElement.querySelector('[data-testid="resize-container"]');
    expect(container).toBeTruthy();
  });

  it('should set up the resize observer', async () => {
    const fixture = TestBed.createComponent(TestComponent);
    fixture.detectChanges();
    
    // Verify that the ResizeObserver is created and called
    expect(mockResizeObserve).toHaveBeenCalled();
  });
});
