import { BooleanInput } from '@angular/cdk/coercion';
import {
  booleanAttribute,
  computed,
  Directive,
  HostListener,
  input,
} from '@angular/core';
import { setupButton } from '@luds/ui/blocks/internal';
import { injectPaginationState } from '../pagination/pagination-state';

/**
 * A diretiva `ludsPaginationPrevious` representa um botão que retorna à página anterior,
 * permitindo navegação paginada com base no estado atual da paginação.
 */
@Directive({
  selector: '[ludsPaginationPrevious]',
  exportAs: 'ludsPaginationPrevious',
  standalone: true,
  host: {
    '[tabindex]': 'disabled() ? -1 : 0',
    '[attr.data-first-page]': 'paginationState().firstPage() ? "" : null',
  },
})
export class LudsPaginationPrevious {
  /**
   * Accessa o estado da paginação.
   */
  protected readonly paginationState = injectPaginationState();

  /**
   * Indica se o botão está desabilitado.
   */
  readonly buttonDisabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsPaginationPreviousDisabled',
    transform: booleanAttribute,
  });

  /**
   * Indica se o botão está desabilitado.
   */
  readonly disabled = computed(
    () =>
      this.buttonDisabled() ||
      this.paginationState().disabled() ||
      this.paginationState().firstPage(),
  );

  constructor() {
    setupButton({ disabled: this.disabled });
  }

  /**
   * Encaminha para a página anterior.
   */
  @HostListener('click')
  goToPreviousPage() {
    if (this.disabled()) {
      return;
    }

    this.paginationState().goToPage(this.paginationState().page() - 1);
  }

  /**
   * O evento de click não deve ser disparado se o botão estiver em uma tag âncora e o href estiver vazio.
   * Isso é uma solução alternativa para garantir que o evento de click seja disparado.
   */
  @HostListener('keydown.enter', ['$event'])
  @HostListener('keydown.space', ['$event'])
  protected onEnter(event: KeyboardEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.goToPreviousPage();
  }
}
