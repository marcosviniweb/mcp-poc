import { BooleanInput } from '@angular/cdk/coercion';
import {
  booleanAttribute,
  computed,
  Directive,
  HostListener,
  input,
} from '@angular/core';
import { setupButton } from '@luds/ui/blocks/internal';
import { injectPaginationState } from '../pagination/pagination-state';

/**
 * A diretiva `ludsPaginationLast` representa um botão de navegação que leva à última página
 * em interfaces paginadas, utilizando o estado de paginação de forma integrada.
 */
@Directive({
  selector: '[ludsPaginationLast]',
  exportAs: 'ludsPaginationLast',
  standalone: true,
  host: {
    '[tabindex]': 'disabled() ? -1 : 0',
    '[attr.data-last-page]': 'paginationState().lastPage() ? "" : null',
  },
})
export class LudsPaginationLast {
  /**
   * Accessa o estado da paginação.
   */
  private readonly paginationState = injectPaginationState();

  /**
   * Indica se o botão está desabilitado.
   */
  readonly buttonDisabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsPaginationLastDisabled',
    transform: booleanAttribute,
  });

  readonly disabled = computed(
    () =>
      this.buttonDisabled() ||
      this.paginationState().disabled() ||
      this.paginationState().lastPage(),
  );

  constructor() {
    setupButton({ disabled: this.disabled });
  }

  /**
   * Encaminha para a última página.
   */
  @HostListener('click')
  goToLastPage(): void {
    if (this.disabled()) {
      return;
    }

    this.paginationState().goToPage(this.paginationState().pageCount());
  }

  /**
   * O evento de click não deve ser disparado se o botão estiver em uma tag âncora e o href estiver vazio.
   * Isso é uma solução alternativa para garantir que o evento de click seja disparado.
   */
  @HostListener('keydown.enter', ['$event'])
  @HostListener('keydown.space', ['$event'])
  protected onEnter(event: KeyboardEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.goToLastPage();
  }
}
