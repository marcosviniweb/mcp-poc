import { fireEvent, render } from '@testing-library/angular';
import { vi } from 'vitest';
import {
  LudsPagination,
  LudsPaginationButton,
  LudsPaginationFirst,
  LudsPaginationLast,
} from '@luds/ui/blocks/pagination';
import { signal } from '@angular/core';

// TODO: Remover após atualização para Angular 19
// fixture.detectChanges() utilizado temporariamente para suprir problema de ciclo de vida state
describe('LudsPagination', () => {
  it('should initialise correctly with defaults', async () => {
    const { getByRole } = await render(`<div ludsPagination></div>`, {
      imports: [LudsPagination],
    });
    const pagination = getByRole('navigation');
    expect(pagination.getAttribute('role')).toBe('navigation');
    expect(pagination.getAttribute('data-page')).toBe('1');
    expect(pagination.getAttribute('data-page-count')).toBe('0');
    expect(pagination.hasAttribute('data-first-page')).toBe(true);
    expect(pagination.hasAttribute('data-last-page')).toBe(false);
    expect(pagination.hasAttribute('data-disabled')).toBe(false);
    expect(pagination.hasAttribute('data-hide-unavailable')).toBe(true);
  });

  it('should reflect input values as data attributes', async () => {
    const { getByRole, fixture } = await render(
      `<div ludsPagination [ludsPaginationPage]="3" [ludsPaginationTotalItems]="50" [ludsPaginationDisabled]="true"></div>`,
      {
        imports: [LudsPagination],
      }
    );
    fixture.detectChanges();
    const pagination = getByRole('navigation');
    expect(pagination.getAttribute('data-page')).toBe('3');
    expect(pagination.getAttribute('data-page-count')).toBe('5');
    expect(pagination.hasAttribute('data-disabled')).toBe(true);
    expect(pagination.hasAttribute('data-first-page')).toBe(false);
    expect(pagination.hasAttribute('data-last-page')).toBe(false);
  });

  it('should set data-first-page and data-last-page correctly', async () => {
    const { rerender, getByRole, fixture } = await render(
      `<div ludsPagination [ludsPaginationPage]="page" [ludsPaginationTotalItems]="totalItems"></div>`,
      {
        imports: [LudsPagination],
        componentProperties: {
          page: 1,
          totalItems: 20,
        },
      }
    );
    fixture.detectChanges();
    let pagination = getByRole('navigation');
    expect(pagination.hasAttribute('data-first-page')).toBe(true);
    expect(pagination.hasAttribute('data-last-page')).toBe(false);

    // rerender with new @Input values using the second argument
    await rerender({
      componentProperties: {
        page: 2,
        totalItems: 20,
      },
    });
    fixture.detectChanges();
    pagination = getByRole('navigation');
    expect(pagination.hasAttribute('data-first-page')).toBe(false);
    expect(pagination.hasAttribute('data-last-page')).toBe(true);
  });

  it('should emit pageChange when goToPage is called', async () => {
    const onPageChange = vi.fn();

    const { getByRole, getByTestId, fixture } = await render(
      `
      <div
          [(ludsPaginationPage)]="page"
          [ludsPaginationTotalItems]="50"
          (ludsPaginationPageChange)="onPageChange($event)"
          ludsPagination
        >
        <button data-testid="go-to-page-3" ludsPaginationButton ludsPaginationButtonPage="3">Go to Page 3</button>
      </div>`,
      {
        imports: [LudsPagination, LudsPaginationButton],
        componentProperties: {
          page: 1,
          onPageChange,
        },
      }
    );
    fixture.detectChanges();
    const pagination = getByRole('navigation');
    const goToPageButton = getByTestId('go-to-page-3');
    expect(pagination.getAttribute('data-page')).toBe('1');
    expect(pagination.getAttribute('data-page-count')).toBe('5');
    expect(pagination.hasAttribute('data-first-page')).toBe(true);
    expect(pagination.hasAttribute('data-last-page')).toBe(false);

    fireEvent.click(goToPageButton);
    expect(onPageChange).toHaveBeenCalledWith(3);
    expect(pagination.getAttribute('data-page')).toBe('3');
    expect(pagination.hasAttribute('data-first-page')).toBe(false);
    expect(pagination.hasAttribute('data-last-page')).toBe(false);
  });

  it('should not emit pageChange or update page if goToPage is called with out-of-bounds value', async () => {
    const { getByRole, getByTestId } = await render(
      `<div ludsPagination [(ludsPaginationPage)]="page" [ludsPaginationTotalItems]="20">
        <button data-testid="go-to-page-3" ludsPaginationButton ludsPaginationButtonPage="3">Go to Page 3</button>
      </div>`,
      {
        imports: [LudsPagination],
        componentProperties: {
          page: 1,
        },
      }
    );
    const pagination = getByRole('navigation');
    const goToPageButton = getByTestId('go-to-page-3');
    fireEvent.click(goToPageButton);
    expect(pagination.getAttribute('data-page')).toBe('1');
  });

  it('should update data attributes when inputs change', async () => {
    const { rerender, getByRole, fixture } = await render(
      `<div ludsPagination [ludsPaginationPage]="page" [ludsPaginationTotalItems]="totalItems" [ludsPaginationDisabled]="disabled"></div>`,
      {
        imports: [LudsPagination],
        componentProperties: {
          page: 1,
          totalItems: 20,
          disabled: false,
        },
      }
    );
    fixture.detectChanges();
    let pagination = getByRole('navigation');
    expect(pagination.getAttribute('data-page')).toBe('1');
    expect(pagination.getAttribute('data-page-count')).toBe('2');
    expect(pagination.hasAttribute('data-disabled')).toBe(false);

    await rerender({
      componentProperties: {
        page: 2,
        totalItems: 20,
        disabled: true,
      },
    });
    fixture.detectChanges();
    pagination = getByRole('navigation');
    expect(pagination.getAttribute('data-page')).toBe('2');
    expect(pagination.getAttribute('data-page-count')).toBe('2');
    expect(pagination.hasAttribute('data-disabled')).toBe(true);
  });

  it('should navigate to the first page when first button is clicked', async () => {
    const { getByRole, getByTestId, fixture } = await render(
      `<div ludsPagination [(ludsPaginationPage)]="page" [ludsPaginationTotalItems]="50">
        <button data-testid="first-page-button" ludsPaginationFirst>First</button>
      </div>`,
      {
        imports: [LudsPagination, LudsPaginationFirst],
        componentProperties: {
          page: 3,
        },
      }
    );
    fixture.detectChanges();
    const pagination = getByRole('navigation');
    const firstPageButton = getByTestId('first-page-button');
    expect(pagination.getAttribute('data-page')).toBe('3');

    fireEvent.click(firstPageButton);
    expect(pagination.getAttribute('data-page')).toBe('1');
  });

  it('should navigate to the last page when last button is clicked', async () => {
    const { getByRole, getByTestId, fixture } = await render(
      `<div ludsPagination [(ludsPaginationPage)]="page" [ludsPaginationTotalItems]="50">
        <button data-testid="last-page-button" ludsPaginationLast>Last</button>
      </div>`,
      {
        imports: [LudsPagination, LudsPaginationLast],
        componentProperties: {
          page: 3,
        },
      }
    );
    fixture.detectChanges();
    const pagination = getByRole('navigation');
    const lastPageButton = getByTestId('last-page-button');

    fireEvent.click(lastPageButton);
    expect(pagination.getAttribute('data-page')).toBe('5');
  });

  // TODO: Atualizar testes posteriormente para utilizarem o state

  it('should update rangeLabel with context and values', async () => {
    const { fixture } = await render(
      `<div ludsPagination [ludsPaginationPage]="2" [ludsPaginationTotalItems]="35" ludsPaginationRangeLabelContext="produtos" #ludsPagination="ludsPagination"></div>`,
      { imports: [LudsPagination] }
    );

    const instance = fixture.debugElement.query(
      (el) => el.references['ludsPagination']
    )?.references['ludsPagination'];

    expect(instance.rangeLabel()).toBe('11 - 20 de 35 produtos');
  });

  it('should return empty rangeLabel if out of bounds or missing values', async () => {
    const { fixture } = await render(
      `<div ludsPagination [ludsPaginationPage]="0" [ludsPaginationTotalItems]="0" #ludsPagination="ludsPagination"></div>`,
      { imports: [LudsPagination] }
    );
    const instance = fixture.debugElement.query(
      (el) => el.references['ludsPagination']
    )?.references['ludsPagination'];

    expect(instance.rangeLabel()).toBe('');
  });

  it('should update itemsPerPage and emit itemsPerPageChange', async () => {
    const itemsPerPage = signal(10);
    
    // Função que atualiza o signal quando o output é emitido
    const onItemsPerPageChange = (newValue: number) => {
      itemsPerPage.set(newValue);
    };
    const onItemsPerPageChangeSpy = vi.fn(onItemsPerPageChange);
    
    const { fixture } = await render(
      `<div ludsPagination [ludsPaginationItemsPerPage]="itemsPerPage()" (ludsPaginationItemsPerPageChange)="onItemsPerPageChange($event)" #ludsPagination="ludsPagination"></div>`,
      {
        imports: [LudsPagination],
        componentProperties: { 
          onItemsPerPageChange: onItemsPerPageChangeSpy,
          itemsPerPage
        }
      }
    );
    fixture.detectChanges();
    const instance = fixture.debugElement.query(
      (el) => el.references['ludsPagination']
    )?.references['ludsPagination'];

    instance.setItemsPerPage(25);
    fixture.detectChanges();
    expect(instance.getItemsPerPage()).toBe(25);
    expect(onItemsPerPageChangeSpy).toHaveBeenCalledWith(25);
    expect(itemsPerPage()).toBe(25);
  });

  it('should use itemsPerPageOptions as input', async () => {
    const { fixture } = await render(
      `<div ludsPagination [ludsPaginationItemsPerPageOptions]="[5, 10, 20]" #ludsPagination="ludsPagination"></div>`,
      { imports: [LudsPagination] }
    );
    const instance = fixture.debugElement.query(
      (el) => el.references['ludsPagination']
    )?.references['ludsPagination'];

    expect(instance.itemsPerPageOptions()).toEqual([5, 10, 20]);
  });

  it('should calculate pageCount based on totalItems and itemsPerPage', async () => {
    const { fixture } = await render(
      `<div ludsPagination [ludsPaginationTotalItems]="45" #ludsPagination="ludsPagination"></div>`,
      { imports: [LudsPagination] }
    );
    const instance = fixture.debugElement.query(
      (el) => el.references['ludsPagination']
    )?.references['ludsPagination'];

    expect(instance.pageCount()).toBe(5);
  });

  it('should reflect hideUnavailable input as data attribute', async () => {
    const { getByRole, fixture } = await render(
      `<div ludsPagination [ludsPaginationHideUnavailable]="false"></div>`,
      { imports: [LudsPagination] }
    );
    fixture.detectChanges();
    const pagination = getByRole('navigation');
    expect(pagination.hasAttribute('data-hide-unavailable')).toBe(false);
  });

  it('should not update itemsPerPage if setItemsPerPage is called with <= 0', async () => {
    const { fixture } = await render(
      `<div ludsPagination [ludsPaginationItemsPerPage]="10" #ludsPagination="ludsPagination"></div>`,
      { imports: [LudsPagination] }
    );
    const instance = fixture.debugElement.query(
      (el) => el.references['ludsPagination']
    )?.references['ludsPagination'];

    instance.setItemsPerPage(0);
    expect(instance.getItemsPerPage()).toBe(10);
  });

  it('should calculate visiblePages with ellipsis for large page counts', async () => {
    const { fixture } = await render(
      `<div ludsPagination [ludsPaginationPage]="5" [ludsPaginationTotalItems]="100" [ludsPaginationItemsPerPage]="10" #ludsPagination="ludsPagination"></div>`,
      { imports: [LudsPagination] }
    );
    const instance = fixture.debugElement.query(
      (el) => el.references['ludsPagination']
    )?.references['ludsPagination'];

    expect(instance.visiblePages().length).toBeLessThanOrEqual(7);
    expect(instance.visiblePages()).toContain(1);
    expect(instance.visiblePages()).toContain(10);
    expect(instance.visiblePages()).toContain('...');
  });
});
