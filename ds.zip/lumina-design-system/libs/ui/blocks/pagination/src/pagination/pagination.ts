import { BooleanInput, NumberInput } from '@angular/cdk/coercion';
import {
  booleanAttribute,
  computed,
  Directive,
  input,
  numberAttribute,
  output,
} from '@angular/core';
import { paginationState, providePaginationState } from './pagination-state';

/**
 * A diretiva `ludsPagination` gerencia a navegação entre páginas em interfaces paginadas,
 * permitindo controlar o estado da página atual de forma reativa e acessível.
 */
@Directive({
  selector: '[ludsPagination]',
  exportAs: 'ludsPagination',
  providers: [providePaginationState()],
  standalone: true,
  host: {
    role: 'navigation',
    '[attr.data-page]': 'state.page()',
    '[attr.data-page-count]': 'pageCount()',
    '[attr.data-first-page]': 'firstPage() ? "" : null',
    '[attr.data-last-page]': 'lastPage() ? "" : null',
    '[attr.data-disabled]': 'state.disabled() ? "" : null',
    '[attr.data-hide-unavailable]': 'state.hideUnavailable() === true ? "" : null',
  },
})
export class LudsPagination {
  /**
   * A página selecionada no momento.
   */
  readonly page = input<number, NumberInput>(1, {
    alias: 'ludsPaginationPage',
    transform: numberAttribute,
  });

  /**
   * O evento que é disparado quando há uma troca de página.
   */
  readonly pageChange = output<number>({
    alias: 'ludsPaginationPageChange',
  });

  /**
   * Indica se a paginação está desabilitada.
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsPaginationDisabled',
    transform: booleanAttribute,
  });

  /**
   * Determina se estamos na primeira página.
   * @internal
   */
  readonly firstPage = computed(() => {
    if (!this.state) return this.page() === 1;
    return this.state.page() === 1;
  });

  /**
   * Determina se estamos na última página.
   * @internal
   */
  readonly lastPage = computed(() => {
    if (!this.state) return this.page() === this.pageCount();
    return this.state.page() === this.pageCount();
  });

  /**
   * Contexto adicional para o range label (ex: "produtos").
   */
  readonly rangeLabelContext = input<string>('', {
    alias: 'ludsPaginationRangeLabelContext',
  });

  /**
   * Array de opções para quantidade de itens por página.
   * @default [10,25,50,100]
   */
  readonly itemsPerPageOptions = input<number[]>([10, 25, 50, 100], {
    alias: 'ludsPaginationItemsPerPageOptions',
  });

  /**
   * Quantidade de itens por página.
   * @default 10
   */
  readonly itemsPerPage = input<number, NumberInput>(10, {
    alias: 'ludsPaginationItemsPerPage',
    transform: numberAttribute,
  });

  /**
   * O evento que é disparado quando há uma troca de página.
   */
  readonly itemsPerPageChange = output<number>({
    alias: 'ludsPaginationItemsPerPageChange',
  });

  /**
   * Quantidade total de itens para paginação.
   */
  readonly totalItems = input<number, NumberInput>(0, {
    alias: 'ludsPaginationTotalItems',
    transform: numberAttribute,
  });

  /**
   * Define se os botões de navegação indisponíveis devem ser ocultados (true) ou apenas desabilitados (false).
   */
  readonly hideUnavailable = input<boolean, BooleanInput>(true, {
    alias: 'ludsPaginationHideUnavailable',
    transform: booleanAttribute,
  });

  /**
   * O total de páginas calculado dinamicamente.
   */
  readonly pageCount = computed(() => {
    const totalItems = this.state.totalItems()
    const itemsPerPage = this.state.itemsPerPage()
    if (totalItems > 0 && itemsPerPage > 0)
      return Math.ceil(totalItems / itemsPerPage);
    return 0;
  });

  /**
   * Array de páginas para renderização, incluindo ellipsis.
   */
  readonly visiblePages = computed(() => {
    const current = this.state.page();
    const total = this.pageCount();
    const maxVisible = 7;

    if (total <= maxVisible)
      return Array.from({ length: total }, (_, i) => i + 1);

    const pages: (number | string)[] = [];

    // Sempre mostra primeira página
    pages.push(1);

    // Determina o range central
    let start = current - 2;
    let end = current + 2;

    // Ajusta para início
    if (current <= 4) {
      start = 2;
      end = 5;
    }
    // Ajusta para fim
    else if (current >= total - 3) {
      start = total - 4;
      end = total - 1;
    }

    // Adiciona ellipsis após primeira página se necessário
    if (start > 2) pages.push('...');

    // Adiciona páginas centrais
    for (let i = start; i <= end; i++) {
      pages.push(i);
    }
    // Adiciona ellipsis antes da última página se necessário
    if (end < total - 1) pages.push('...');

    // Sempre mostra última página
    pages.push(total);

    // Garante que sempre tenha a quantidade máxima de itens
    // Se por algum motivo exceder, remove extras do meio
    while (pages.length > maxVisible) {
      pages.splice(2, 1); // remove do meio, após o primeiro e possível ellipsis
    }

    return pages;
  });

  /**
   * Texto do range label da paginação (ex: "1 - 10 de 100 produtos").
   */
  readonly rangeLabel = computed(() => {
    const page = this.state.page();
    const itemsPerPage = this.state.itemsPerPage();
    const totalItems = this.state.totalItems();

    if (
      !totalItems ||
      !page ||
      !itemsPerPage ||
      !totalItems ||
      page > this.pageCount()
    )
      return '';

    const start = (page - 1) * itemsPerPage + 1;
    const end = Math.min(page * itemsPerPage, totalItems);
    const context = this.rangeLabelContext();
    return `${start} - ${end} de ${totalItems}${context ? ' ' + context : ''}`;
  });

  /**
   * O controle de estado para a paginação.
   * @internal
   */
  private readonly state = paginationState<LudsPagination>(this);

  /**
   * Encaminha para a página especificada.
   * @param page The page to go to.
   */
  goToPage(page: number) {
    // Valida se a página está dentro dos limites da paginação.
    if (page < 1 || page > this.pageCount()) {
      return;
    }

    this.state.page.set(page);
    this.pageChange.emit(page);
  }

  /**
   * Atualiza a quantidade de itens por página e reinicia para a primeira página.
   * @param qty Nova quantidade de itens por página.
   */
  setItemsPerPage(qty: number) {
    if (qty <= 0) return;
    this.state.itemsPerPage.set(qty);
    this.state.page.set(1);
    this.pageChange.emit(1);
    this.itemsPerPageChange.emit(qty);
  }

  // TODO: Remover após atualização para Angular 19
  // Útil somente enquanto não injetarmos paginationState nos exemplos
  getItemsPerPage() {
    return this.state.itemsPerPage();
  }
}
