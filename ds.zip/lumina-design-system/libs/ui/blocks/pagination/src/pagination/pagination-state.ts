import {
  createState,
  createStateInjector,
  createStateProvider,
  createStateToken,
} from '@luds/ui/blocks/state';
import type { LudsPagination } from './pagination';

/**
 * O token de estado para o componente primitivo de paginação.
 */
export const LudsPaginationStateToken = createStateToken<LudsPagination>('Pagination');

/**
 * Fornece o estado da paginação.
 */
export const providePaginationState = createStateProvider(LudsPaginationStateToken);

/**
 * Injeta o estado da paginação.
 */
export const injectPaginationState = createStateInjector<LudsPagination>(LudsPaginationStateToken);

/**
 * Função de registro de estado da paginação.
 */
export const paginationState = createState(LudsPaginationStateToken);
