import { BooleanInput, NumberInput } from '@angular/cdk/coercion';
import {
  booleanAttribute,
  computed,
  Directive,
  HostListener,
  input,
  numberAttribute,
} from '@angular/core';
import { setupButton } from '@luds/ui/blocks/internal';
import { injectPaginationState } from '../pagination/pagination-state';

/**
 * A diretiva `ludsPaginationButton` representa um botão de navegação para uma página específica,
 * permitindo interação com o estado de paginação de forma acessível e reativa.
 */
@Directive({
  selector: '[ludsPaginationButton]',
  exportAs: 'ludsPaginationButton',
  standalone: true,
  host: {
    '[tabindex]': 'disabled() ? -1 : 0',
    '[attr.data-page]': 'page()',
    '[attr.data-selected]': 'selected() ? "" : null',
    '[attr.aria-current]': 'selected()',
  },
})
export class LudsPaginationButton {
  /**
   * Acessa o estado da paginação.
   */
  protected readonly paginationState = injectPaginationState();

  /**
   * Define a página que o botão representa.
   */
  readonly page = input.required<number, NumberInput>({
    alias: 'ludsPaginationButtonPage',
    transform: numberAttribute,
  });

  /**
   * Indica se o botão está desabilitado.
   */
  readonly buttonDisabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsPaginationButtonDisabled',
    transform: booleanAttribute,
  });

  /**
   * Indica se o botão está desabilitado.
   */
  readonly disabled = computed(() => this.buttonDisabled() || this.paginationState().disabled());

  /**
   * Indica se a página está selecionada no momento.
   */
  protected readonly selected = computed(() => this.page() === this.paginationState().page());

  constructor() {
    setupButton({ disabled: this.disabled });
  }

  /**
   * Encaminha para a página que o botão representa.
   */
  @HostListener('click')
  goToPage(): void {
    if (this.disabled()) {
      return;
    }

    this.paginationState().goToPage(this.page());
  }

  /**
   * O evento de click não deve ser disparado se o botão estiver em uma tag âncora e o href estiver vazio.
   * Isso é uma solução alternativa para garantir que o evento de click seja disparado.
   */
  @HostListener('keydown.enter', ['$event'])
  @HostListener('keydown.space', ['$event'])
  protected onEnter(event: KeyboardEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.goToPage();
  }
}
