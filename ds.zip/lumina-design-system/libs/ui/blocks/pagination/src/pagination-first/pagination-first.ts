import { BooleanInput } from '@angular/cdk/coercion';
import {
  booleanAttribute,
  computed,
  Directive,
  HostListener,
  input,
} from '@angular/core';
import { setupButton } from '@luds/ui/blocks/internal';
import { injectPaginationState } from '../pagination/pagination-state';

/**
 * A diretiva `ludsPaginationFirst` representa um botão de navegação que leva à primeira página
 * em interfaces paginadas, integrando-se ao estado de paginação.
 */
@Directive({
  selector: '[ludsPaginationFirst]',
  exportAs: 'ludsPaginationFirst',
  standalone: true,
  host: {
    '[tabindex]': 'disabled() ? -1 : 0',
    '[attr.data-first-page]': 'paginationState().firstPage() ? "" : null',
  },
})
export class LudsPaginationFirst {
  /**
   * Accessa o estado da paginação.
   */
  protected readonly paginationState = injectPaginationState();

  /**
   * Indica se o botão está desabilitado.
   */
  readonly buttonDisabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsPaginationFirstDisabled',
    transform: booleanAttribute,
  });

  readonly disabled = computed(
    () =>
      this.buttonDisabled() ||
      this.paginationState().disabled() ||
      this.paginationState().firstPage(),
  );

  constructor() {
    setupButton({ disabled: this.disabled });
  }
  /**
   * Encaminha para a primeira página.
   */
  @HostListener('click')
  goToFirstPage() {
    if (this.disabled()) {
      return;
    }

    this.paginationState().goToPage(1);
  }

  /**
   * O evento de click não deve ser disparado se o botão estiver em uma tag âncora e o href estiver vazio.
   * Isso é uma solução alternativa para garantir que o evento de click seja disparado.
   */
  @HostListener('keydown.enter', ['$event'])
  @HostListener('keydown.space', ['$event'])
  protected onEnter(event: KeyboardEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.goToFirstPage();
  }
}
