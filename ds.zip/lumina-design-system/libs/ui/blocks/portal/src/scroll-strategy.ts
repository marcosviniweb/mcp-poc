/**
 * Este código é amplamente baseado na implementação da estratégia de scroll do CDK Overlay, porém foi
 * modificado para não depender dos estilos globais de overlay do CDK.
 */
import { coerceCssPixelValue } from '@angular/cdk/coercion';
import { ViewportRuler } from '@angular/cdk/overlay';
import { isFunction, isObject } from '@luds/ui/blocks/utils';

export interface ScrollStrategy {
  enable(): void;
  disable(): void;
}

/** Resultado em cache da verificação que indica se o navegador suporta comportamentos de scroll. */
let scrollBehaviorSupported: boolean | undefined;

export function supportsScrollBehavior(): boolean {
  if (scrollBehaviorSupported != null) {
    return scrollBehaviorSupported;
  }

  // Se não estamos no navegador, não pode ser suportado. Também verifica `Element`, porque
  // alguns projetos simulam o `document` global durante SSR o que pode nos confundir.
  if (!isObject(document) || !document || !isFunction(Element) || !Element) {
    return (scrollBehaviorSupported = false);
  }

  // Se o elemento pode ter um estilo `scrollBehavior`, podemos ter certeza de que é suportado.
  if ('scrollBehavior' in document.documentElement!.style) {
    return (scrollBehaviorSupported = true);
  }

  // Verifica se scrollTo é suportado e se foi polyfillado
  const scrollToFunction = Element.prototype.scrollTo;
  if (!scrollToFunction) {
    return (scrollBehaviorSupported = false);
  }

  // Podemos detectar se a função foi polyfillada chamando `toString` nela. Funções nativas
  // são ofuscadas usando `[native code]`, enquanto se foi sobrescrita obteríamos
  // o código fonte real da função. Via https://davidwalsh.name/detect-native-function. Considera
  // funções polyfilladas como suportando comportamento de scroll.
  return (scrollBehaviorSupported = !/\{\s*\[native code\]\s*\}/.test(scrollToFunction.toString()));
}

interface HTMLStyles {
  top: string;
  left: string;
  position: string;
  overflowY: string;
  width: string;
}

export class BlockScrollStrategy implements ScrollStrategy {
  private readonly previousHTMLStyles: HTMLStyles = {
    top: '',
    left: '',
    position: '',
    overflowY: '',
    width: '',
  };
  private previousScrollPosition = { top: 0, left: 0 };
  private isEnabled = false;

  constructor(
    private readonly viewportRuler: ViewportRuler,
    private readonly document: Document,
  ) {}

  /** Bloqueia o scroll a nível de página enquanto o overlay anexado está aberto. */
  enable() {
    if (this.canBeEnabled()) {
      const root = this.document.documentElement!;

      this.previousScrollPosition = this.viewportRuler.getViewportScrollPosition();

      // Armazena em cache os estilos inline anteriores caso o usuário os tenha definido.
      this.previousHTMLStyles.left = root.style.left || '';
      this.previousHTMLStyles.top = root.style.top || '';
      this.previousHTMLStyles.position = root.style.position || '';
      this.previousHTMLStyles.overflowY = root.style.overflowY || '';
      this.previousHTMLStyles.width = root.style.width || '';

      // Define os estilos para bloquear o scroll.
      root.style.position = 'fixed';

      // Necessário para o conteúdo não perder sua largura. Note que estamos usando 100%, ao invés de
      // 100vw, porque 100vw inclui a largura mais a scrollbar, enquanto 100% é a largura
      // que o elemento tinha antes de torná-lo `fixed`.
      root.style.width = '100%';

      // Nota: isso sempre adicionará uma scrollbar a qualquer elemento que esteja, o que pode
      // potencialmente resultar em scrollbars duplas. Não deve ser um problema, porque não
      // bloquearemos scroll em uma página que não tem scrollbar em primeiro lugar.
      root.style.overflowY = 'scroll';

      // Nota: estamos usando o nó `html`, ao invés do `body`, porque o `body` pode
      // ter a margem do user agent, enquanto o `html` é garantido de não ter uma.
      root.style.left = coerceCssPixelValue(-this.previousScrollPosition.left);
      root.style.top = coerceCssPixelValue(-this.previousScrollPosition.top);
      root.setAttribute('data-scrollblock', '');
      this.isEnabled = true;
    }
  }

  /** Desbloqueia o scroll a nível de página enquanto o overlay anexado está aberto. */
  disable(): void {
    if (this.isEnabled) {
      const html = this.document.documentElement!;
      const body = this.document.body!;
      const htmlStyle = html.style;
      const bodyStyle = body.style;
      const previousHtmlScrollBehavior = htmlStyle.scrollBehavior || '';
      const previousBodyScrollBehavior = bodyStyle.scrollBehavior || '';

      this.isEnabled = false;

      htmlStyle.left = this.previousHTMLStyles.left;
      htmlStyle.top = this.previousHTMLStyles.top;
      htmlStyle.position = this.previousHTMLStyles.position;
      htmlStyle.overflowY = this.previousHTMLStyles.overflowY;
      htmlStyle.width = this.previousHTMLStyles.width;
      html.removeAttribute('data-scrollblock');

      // Desabilita smooth scrolling definido pelo usuário temporariamente enquanto restauramos a posição de scroll.
      // Veja https://developer.mozilla.org/en-US/docs/Web/CSS/scroll-behavior
      // Note que não modificamos a propriedade se o navegador não suporta `scroll-behavior`,
      // porque pode afetar detecções de recursos em `supportsScrollBehavior` que
      // verifica `'scrollBehavior' in documentElement.style`.
      if (scrollBehaviorSupported) {
        htmlStyle.scrollBehavior = bodyStyle.scrollBehavior = 'auto';
      }

      window.scroll(this.previousScrollPosition.left, this.previousScrollPosition.top);

      if (scrollBehaviorSupported) {
        htmlStyle.scrollBehavior = previousHtmlScrollBehavior;
        bodyStyle.scrollBehavior = previousBodyScrollBehavior;
      }
    }
  }

  private canBeEnabled(): boolean {
    // Como as estratégias de scroll não podem ser singletons, temos que usar uma classe CSS global
    // (`cdk-global-scrollblock`) para garantir que não tentemos desabilitar scroll global
    // múltiplas vezes.
    const html = this.document.documentElement!;

    if (html.classList.contains('cdk-global-scrollblock') || this.isEnabled) {
      return false;
    }

    const viewport = this.viewportRuler.getViewportSize();
    return html.scrollHeight > viewport.height || html.scrollWidth > viewport.width;
  }
}

export class NoopScrollStrategy implements ScrollStrategy {
  enable(): void {
    // Nenhuma operação para habilitar
  }

  disable(): void {
    // Nenhuma operação para desabilitar
  }
}
