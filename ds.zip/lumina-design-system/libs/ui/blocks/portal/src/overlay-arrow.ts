import { DestroyRef, effect, inject } from '@angular/core';
import { injectElementRef } from '@luds/ui/blocks/internal';
import { injectOverlay } from './overlay';

/**
 * Configura uma seta para o overlay, registrando o elemento da seta e atualizando
 * sua posição automaticamente com base no posicionamento do overlay.
 *
 * Esta função deve ser chamada dentro do contexto de injeção de uma diretiva
 * que representa a seta do overlay.
 */
export function setupOverlayArrow(): void {
  const overlay = injectOverlay();
  const element = injectElementRef();
  const destroyRef = inject(DestroyRef);

  // registra o elemento da seta com o overlay
  overlay.registerArrow(element.nativeElement);

  // limpa o elemento da seta na destruição
  destroyRef.onDestroy(() => overlay.unregisterArrow());

  // atualiza a posição da seta após o overlay ser renderizado
  effect(() => {
    const position = overlay.arrowPosition();

    element.nativeElement.style.setProperty('--luds-overlay-arrow-x', `${position.x || 0}px`);
    element.nativeElement.style.setProperty('--luds-overlay-arrow-y', `${position.y || 0}px`);
    element.nativeElement.dataset['placement'] = overlay.finalPlacement();
  }, { allowSignalWrites: true });
}
