import { Component, ElementRef, Injector, TemplateRef, ViewChild, ViewContainerRef } from '@angular/core';
import { render } from '@testing-library/angular';
import { LudsComponentPortal, LudsTemplatePortal, createPortal } from './portal';

@Component({
  selector: 'test-portal-content',
  standalone: true,
  template: `<div data-testid="portal-content">Portal Content</div>`,
})
class TestPortalContentComponent {
  constructor(public elementRef: ElementRef) {}
}

@Component({
  selector: 'test-container',
  standalone: true,
  template: `
    <ng-template #contentTemplate>
      <div data-testid="template-content">Template Content</div>
    </ng-template>
  `,
})
class TestContainerComponent {
  @ViewChild('contentTemplate', { static: true })
  contentTemplate!: TemplateRef<unknown>;

  constructor(
    public viewContainerRef: ViewContainerRef,
    public injector: Injector
  ) {}
}

describe('Portal', () => {
  it('should create a component portal', async () => {
    const { fixture } = await render(TestContainerComponent);
    const component = fixture.componentInstance;
    
    // Create a component portal
    const portal = new LudsComponentPortal(TestPortalContentComponent);
    
    // This will actually create the component, but we're not attaching it to any container
    // In a real scenario, we would need a PortalOutlet to attach it
    expect(portal).toBeInstanceOf(LudsComponentPortal);
  });

  it('should create a template portal', async () => {
    const { fixture } = await render(TestContainerComponent);
    const component = fixture.componentInstance;
    
    // Create a template portal
    const portal = new LudsTemplatePortal(
      component.contentTemplate,
      component.viewContainerRef,
      {} as any
    );
    
    expect(portal).toBeInstanceOf(LudsTemplatePortal);
  });

  it('should create portal via createPortal factory function with component', async () => {
    const { fixture } = await render(TestContainerComponent);
    const component = fixture.componentInstance;
    
    // Use the factory function to create a component portal
    const portal = createPortal(
      TestPortalContentComponent,
      component.viewContainerRef,
      component.injector
    );
    
    expect(portal).toBeInstanceOf(LudsComponentPortal);
  });

  it('should create portal via createPortal factory function with template', async () => {
    const { fixture } = await render(TestContainerComponent);
    const component = fixture.componentInstance;
    
    // Use the factory function to create a template portal
    const portal = createPortal(
      component.contentTemplate,
      component.viewContainerRef,
      component.injector
    );
    
    expect(portal).toBeInstanceOf(LudsTemplatePortal);
  });
});
