import { FocusMonitor, FocusOrigin } from "@angular/cdk/a11y";
import { ViewportRuler } from "@angular/cdk/overlay";
import { DOCUMENT } from "@angular/common";
import {
  DestroyRef,
  Injector,
  Provider,
  Signal,
  TemplateRef,
  Type,
  ViewContainerRef,
  computed,
  inject,
  runInInjectionContext,
  signal,
} from "@angular/core";
import {
  Middleware,
  Placement,
  Strategy,
  arrow,
  autoUpdate,
  computePosition,
  flip,
  offset,
  shift,
  autoPlacement,
} from "@floating-ui/dom";
import { fromResizeEvent } from "@luds/ui/blocks/internal";
import { injectDisposables, safeTakeUntilDestroyed, uniqueId } from "@luds/ui/blocks/utils";
import { Subject, fromEvent } from "rxjs";
import { provideOverlayContext } from "./overlay-token";
import { LudsPortal, createPortal } from "./portal";
import { BlockScrollStrategy, NoopScrollStrategy } from "./scroll-strategy";

/**
 * Opções de configuração para criar um overlay
 * @internal
 */
export interface LudsOverlayConfig<T = unknown> {
  /** Conteúdo a ser exibido no overlay (componente ou template) */
  content: LudsOverlayContent<T>;

  /** O elemento que aciona o overlay */
  triggerElement: HTMLElement;

  /** O injetor a usar para criar o portal */
  injector: Injector;
  /** ViewContainerRef a usar para criar o portal */
  viewContainerRef: ViewContainerRef;

  /** Dados de contexto a serem passados para o conteúdo do overlay */
  context?: Signal<T | undefined>;

  /** Elemento container para anexar o overlay (padrão: document.body) */
  container?: HTMLElement | string | null;

  /** Posicionamento preferido do overlay relativo ao trigger */
  placement?: Placement;

  /** Distância de offset entre o overlay e o trigger em pixels */
  offset?: number;

  /** Se deve habilitar comportamento de flip quando o espaço é limitado */
  flip?: boolean;

  /** Se deve deslocar o elemento flutuante para mantê-lo visível. */
  shift?: boolean;

  /** Se deve usar autoPlacement ao invés de flip - considera todos os lados */
  autoPlacement?: boolean;

  /** Atraso antes de exibir o overlay em milissegundos */
  showDelay?: number;

  /** Atraso antes de ocultar o overlay em milissegundos */
  hideDelay?: number;

  /** Se o overlay deve ser posicionado com estratégia fixed ou absolute */
  strategy?: Strategy;

  /** Elemento da seta para middleware da seta */
  arrowElement?: HTMLElement;

  /** Padding da seta para middleware da seta */
  arrowPadding?: number;

  /** A estratégia de scroll a usar para o overlay */
  scrollBehaviour?: "reposition" | "block";
  /** Se deve fechar o overlay ao clicar fora */
  closeOnOutsideClick?: boolean;
  /** Se deve fechar o overlay ao pressionar escape */
  closeOnEscape?: boolean;
  /** Se deve restaurar o foco para o elemento trigger ao ocultar o overlay */
  restoreFocus?: boolean;
  /** Middleware adicional para posicionamento do floating UI */
  additionalMiddleware?: Middleware[];

  /** Providers adicionais */
  providers?: Provider[];
}

/** Tipo para conteúdo do overlay que pode ser template ou componente */
export type LudsOverlayContent<T> = TemplateRef<LudsOverlayTemplateContext<T>> | Type<unknown>;

/** Contexto para overlays baseados em template */
export type LudsOverlayTemplateContext<T> = {
  $implicit: T;
};

/**
 * LudsOverlay gerencia o ciclo de vida e posicionamento de elementos de interface overlay.
 * Abstrai o comportamento comum compartilhado por tooltips, popovers, menus, etc.
 * @internal
 */
export class LudsOverlay<T = unknown> {
  private readonly disposables = injectDisposables();
  private readonly document = inject(DOCUMENT);
  private readonly destroyRef = inject(DestroyRef);
  private readonly viewContainerRef: ViewContainerRef;
  private readonly viewportRuler = inject(ViewportRuler);
  private readonly focusMonitor = inject(FocusMonitor);
  /** Acessa qualquer overlay pai */
  private readonly parentOverlay = inject(LudsOverlay, { optional: true });
  /** Signal rastreando a instância do portal */
  private readonly portal = signal<LudsPortal | null>(null);

  /** Signal rastreando a posição do overlay */
  readonly position = signal<{ x: number | undefined; y: number | undefined }>({
    x: undefined,
    y: undefined,
  });

  /**
   * Determina se o overlay foi posicionado
   * @internal
   */
  readonly isPositioned = computed(() => this.position().x !== undefined && this.position().y !== undefined);

  /** Signal rastreando a largura do elemento trigger */
  readonly triggerWidth = signal<number | null>(null);

  /** A origem da transformação para o overlay */
  readonly transformOrigin = signal<string>("center center");

  /** Signal rastreando o posicionamento final do overlay */
  readonly finalPlacement = signal<Placement | undefined>(undefined);

  /** Função para descartar a atualização automática de posicionamento */
  private disposePositioning?: () => void;

  /** Handle de timeout para exibir o overlay */
  private openTimeout?: () => void;

  /** Handle de timeout para ocultar o overlay */
  private closeTimeout?: () => void;

  /** Signal rastreando se o overlay está aberto */
  readonly isOpen = signal(false);

  /** Um id único para o overlay */
  readonly id = signal<string>(uniqueId("luds-overlay"));

  /** O atributo aria-describedby para acessibilidade */
  readonly ariaDescribedBy = computed(() => (this.isOpen() ? this.id() : undefined));

  /** A estratégia de scroll */
  private scrollStrategy = new NoopScrollStrategy();

  /** Um observable que emite quando o overlay está fechando */
  readonly closing = new Subject<void>();

  /** Armazena o elemento da seta */
  private arrowElement: HTMLElement | null = null;

  /** @internal A posição da seta */
  readonly arrowPosition = signal<{ x: number | undefined; y: number | undefined }>({
    x: undefined,
    y: undefined,
  });

  /**
   * Cria uma nova instância de overlay
   * @param config Configuração inicial para o overlay
   * @param destroyRef Referência para limpeza automática
   */
  constructor(private config: LudsOverlayConfig<T>) {
    // não podemos injetar o viewContainerRef pois isso pode gerar erro durante hidratação no SSR
    this.viewContainerRef = config.viewContainerRef;

    // isso deve ser feito após a configuração ser definida
    this.transformOrigin.set(this.getTransformOrigin());

    // Monitora redimensionamento do elemento trigger
    fromResizeEvent(this.config.triggerElement)
      .pipe(safeTakeUntilDestroyed(this.destroyRef))
      .subscribe(({ width, height }) => {
        this.triggerWidth.set(width);

        // se o elemento foi ocultado, oculta imediatamente
        if (width === 0 || height === 0) {
          this.hideImmediate();
        }
      });

    // se há um overlay pai e ele está fechado, fecha este overlay
    this.parentOverlay?.closing.pipe(safeTakeUntilDestroyed(this.destroyRef)).subscribe(() => {
      if (this.isOpen()) {
        this.hideImmediate();
      }
    });

    // Se closeOnOutsideClick está habilitado, configura um listener de clique
    fromEvent<MouseEvent>(this.document, "mouseup", { capture: true })
      .pipe(safeTakeUntilDestroyed(this.destroyRef))
      .subscribe((event) => {
        if (!this.config.closeOnOutsideClick) {
          return;
        }

        const overlay = this.portal();

        if (!overlay || !this.isOpen()) {
          return;
        }

        const path = event.composedPath();
        const isInsideOverlay = overlay.getElements().some((el) => path.includes(el));
        const isInsideTrigger = path.includes(this.config.triggerElement);

        if (!isInsideOverlay && !isInsideTrigger) {
          this.hide();
        }
      });

    // Se closeOnEscape está habilitado, configura um listener de keydown
    fromEvent<KeyboardEvent>(this.document, "keydown", { capture: true })
      .pipe(safeTakeUntilDestroyed(this.destroyRef))
      .subscribe((event) => {
        if (!this.config.closeOnEscape) return;
        if (event.key === "Escape" && this.isOpen()) {
          this.hide({ origin: "keyboard", immediate: true });
        }
      });

    // Garante limpeza na destruição
    this.destroyRef.onDestroy(() => this.destroy());
  }

  /**
   * Exibe o overlay com o atraso especificado
   * @param showDelay Atraso opcional para sobrescrever o showDelay configurado
   */
  show(): Promise<void> {
    return new Promise<void>((resolve) => {
      // Se fechamento está em progresso, cancela
      if (this.closeTimeout) {
        this.closeTimeout();
        this.closeTimeout = undefined;
      }

      // Não prossegue se já está abrindo ou aberto
      if (this.openTimeout || this.isOpen()) {
        return;
      }

      // Usa o atraso fornecido ou volta para a configuração
      const delay = this.config.showDelay ?? 0;

      this.openTimeout = this.disposables.setTimeout(() => {
        this.openTimeout = undefined;
        this.createOverlay();
        resolve();
      }, delay);
    });
  }

  /**
   * Para qualquer operação de fechamento pendente. Isso é útil por exemplo, se movermos o mouse do trigger do tooltip para o próprio tooltip.
   * Isso impedirá que o tooltip feche imediatamente quando o mouse sair do trigger.
   * @internal
   */
  cancelPendingClose(): void {
    if (this.closeTimeout) {
      this.closeTimeout();
      this.closeTimeout = undefined;
    }
  }

  /**
   * Oculta o overlay com o atraso especificado
   * @param options Opções opcionais para ocultar o overlay
   */
  hide(options?: OverlayTriggerOptions): void {
    // Se abertura está em progresso, cancela
    if (this.openTimeout) {
      this.openTimeout();
      this.openTimeout = undefined;
    }

    // Não prossegue se já está fechando ou fechado, a menos que immediate seja true
    if ((this.closeTimeout && !options?.immediate) || !this.isOpen()) {
      return;
    }

    this.closing.next();

    const dispose = async () => {
      this.closeTimeout = undefined;

      if (this.config.restoreFocus) {
        this.focusMonitor.focusVia(this.config.triggerElement, options?.origin ?? "program", {
          preventScroll: true,
        });
      }

      await this.destroyOverlay();
    };

    if (options?.immediate) {
      // Se imediato, descarta imediatamente
      dispose();
    } else {
      this.closeTimeout = this.disposables.setTimeout(dispose, this.config.hideDelay ?? 0);
    }
  }

  /**
   * Atualiza a configuração deste overlay
   * @param config Nova configuração (parcial)
   */
  updateConfig(config: Partial<LudsOverlayConfig<T>>): void {
    this.config = { ...this.config, ...config };

    // Se o overlay já está aberto, atualiza sua posição
    if (this.isOpen()) {
      this.updatePosition();
    }
  }

  /**
   * Oculta imediatamente o overlay sem qualquer atraso
   */
  hideImmediate(): void {
    this.hide({ immediate: true });
  }

  /**
   * Alterna o estado aberto/fechado do overlay
   */
  toggle(): void {
    if (this.isOpen()) {
      this.hide();
    } else {
      this.show();
    }
  }

  /**
   * Força atualização da posição do overlay
   */
  updatePosition(): void {
    const portal = this.portal();

    if (!portal) {
      return;
    }

    const elements = portal.getElements();

    if (elements.length === 0) {
      return;
    }

    const overlayElement = elements[0] as HTMLElement;

    // Calcula nova posição
    this.computePosition(overlayElement);
  }

  /**
   * Destrói completamente esta instância de overlay
   */
  destroy(): void {
    this.hideImmediate();
    this.disposePositioning?.();
    this.scrollStrategy.disable();
  }

  /**
   * Obtém os elementos do overlay
   */
  getElements(): HTMLElement[] {
    return this.portal()?.getElements() ?? [];
  }

  /**
   * Método interno para criar o overlay
   */
  private createOverlay(): void {
    if (!this.config.content) {
      throw new Error("Overlay content must be provided");
    }

    // Cria um novo portal com contexto
    const portal = createPortal(
      this.config.content,
      this.viewContainerRef,
      Injector.create({
        parent: this.config.injector,
        providers: [
          ...(this.config.providers || []),
          { provide: LudsOverlay, useValue: this },
          provideOverlayContext<T>(this.config.context),
        ],
      }),
      { $implicit: this.config.context } as LudsOverlayTemplateContext<T>,
    );

    // Anexa o portal ao container
    const container = this.resolveContainer();
    portal.attach(container);

    // Atualiza signal do portal
    this.portal.set(portal);

    // Garante que view está atualizada
    portal.detectChanges();

    // encontra um elemento outlet dedicado
    // este é o elemento que tem o atributo `data-overlay`
    // se tal elemento não existe, usamos o primeiro elemento no portal
    const outletElement = portal.getElements().find((el) => el.hasAttribute("data-overlay")) ?? portal.getElements()[0];

    if (!outletElement) {
      throw new Error("Overlay element is not available.");
    }

    // Configura posicionamento
    this.setupPositioning(outletElement);

    // Marca como aberto
    this.isOpen.set(true);

    this.scrollStrategy =
      this.config.scrollBehaviour === "block"
        ? new BlockScrollStrategy(this.viewportRuler, this.document)
        : new NoopScrollStrategy();

    this.scrollStrategy.enable();
  }

  /**
   * Método interno para configurar posicionamento do overlay
   */
  private setupPositioning(overlayElement: HTMLElement): void {
    // Determina estratégia de posicionamento baseada no CSS do elemento overlay
    const strategy =
      getComputedStyle(overlayElement).position === "fixed" ? "fixed" : this.config.strategy || "absolute";

    // Configura auto-update para posicionamento
    this.disposePositioning = autoUpdate(this.config.triggerElement, overlayElement, () =>
      this.computePosition(overlayElement, strategy),
    );
  }

  /**
   * Calcula a posição do overlay usando floating-ui
   */
  private async computePosition(overlayElement: HTMLElement, strategy: Strategy = "absolute"): Promise<void> {
    // Cria array de middleware
    const middleware: Middleware[] = [offset(this.config.offset || 0), shift()];

    // Adiciona middleware flip ou autoPlacement
    if (this.config.autoPlacement) {
      // autoPlacement considera todos os lados automaticamente
      middleware.push(
        autoPlacement({
          // Você pode configurar quais posicionamentos considerar
          allowedPlacements: ["top", "bottom", "left", "right", "top-start", "top-end", "bottom-start", "bottom-end"],
        }),
      );
    } else if (this.config.flip !== false) {
      middleware.push(flip());
    }
    if (this.config.shift) {
      middleware.push(shift());
    }

    // Adiciona qualquer middleware adicional
    if (this.config.additionalMiddleware) {
      middleware.push(...this.config.additionalMiddleware);
    }

    // Se o elemento da seta está registrado, adiciona middleware da seta
    if (this.arrowElement) {
      middleware.push(arrow({
        element: this.arrowElement,
        padding: this.config.arrowPadding ?? 16
      }));
    }

    // Calcula a posição
    const position = await computePosition(this.config.triggerElement, overlayElement, {
      placement: this.config.placement || "top",
      middleware,
      strategy,
    });

    // Atualiza signal de posição
    this.position.set({ x: position.x, y: position.y });

    // Atualiza signal de posicionamento final
    this.finalPlacement.set(position.placement);

    // Atualiza posição da seta se disponível
    if (this.arrowElement) {
      this.arrowPosition.set({
        x: position.middlewareData.arrow?.x,
        y: position.middlewareData.arrow?.y,
      });
    }

    // Garante que view seja atualizada
    this.portal()?.detectChanges();
  }

  /**
   * Método interno para destruir o portal do overlay
   */
  private async destroyOverlay(): Promise<void> {
    const portal = this.portal();

    if (!portal) {
      return;
    }

    // Limpa referência do portal para prevenir destruição dupla
    this.portal.set(null);

    // Limpa posicionamento
    this.disposePositioning?.();
    this.disposePositioning = undefined;

    // Desanexa o portal
    await portal.detach();

    // Marca como fechado
    this.isOpen.set(false);

    // Reseta posicionamento final
    this.finalPlacement.set(undefined);

    // desabilita estratégia de scroll
    this.scrollStrategy.disable();
    this.scrollStrategy = new NoopScrollStrategy();
  }

  /**
   * Obtém a origem da transformação para o overlay
   */
  private getTransformOrigin(): string {
    const placement = this.config.placement ?? "top";

    const basePlacement = placement.split("-")[0]; // Extract "top", "bottom", etc.
    const alignment = placement.split("-")[1]; // Extract "start" or "end"

    const map: Record<string, string> = {
      top: "bottom",
      bottom: "top",
      left: "right",
      right: "left",
    };

    let x = "center";
    let y = "center";

    if (basePlacement === "top" || basePlacement === "bottom") {
      y = map[basePlacement];
      if (alignment === "start") x = "left";
      else if (alignment === "end") x = "right";
    } else {
      x = map[basePlacement];
      if (alignment === "start") y = "top";
      else if (alignment === "end") y = "bottom";
    }

    return `${y} ${x}`;
  }

  /**
   * Registra o elemento da seta para posicionamento
   * @internal
   */
  registerArrow(arrowElement: HTMLElement | null): void {
    this.arrowElement = arrowElement;
  }

  /**
   * Remove o elemento da seta registrado
   * @internal
   */
  unregisterArrow(): void {
    this.arrowElement = null;
  }

  /**
   * Resolve o elemento container a partir da configuração
   * @internal
   */
  private resolveContainer(): HTMLElement {
    if (!this.config.container) {
      return this.document.body;
    }

    if (typeof this.config.container === "string") {
      const element = this.document.querySelector(this.config.container);
      if (!element) {
        // Fallback para document.body se o container não for encontrado
        console.warn(
          `Lumina: Elemento Container com seletor "${this.config.container}" não encontrado. Retornando para document.body.`,
        );
        return this.document.body;
      }

      return element as HTMLElement;
    }

    return this.config.container;
  }
}

/**
 * Função auxiliar para criar um overlay em uma única chamada
 * @internal
 */
export function createOverlay<T>(config: LudsOverlayConfig<T>): LudsOverlay<T> {
  // executamos a criação do overlay no contexto do injetor para garantir que possa chamar a função inject
  return runInInjectionContext(config.injector, () => new LudsOverlay<T>(config));
}

/**
 * Função auxiliar para injetar a instância LudsOverlay
 * @internal
 */
export function injectOverlay<T>(): LudsOverlay<T> {
  return inject(LudsOverlay);
}

export interface OverlayTriggerOptions {
  /**
   * Se a mudança de visibilidade deve ser imediata.
   */
  immediate?: boolean;
  /**
   * A origem do evento de foco que acionou a mudança de visibilidade.
   */
  origin?: FocusOrigin;
}
