import { inject, InjectionToken, Signal, ValueProvider } from '@angular/core';

const LudsOverlayContextToken = new InjectionToken<unknown>('LudsOverlayContextToken');

/**
 * Injeta o contexto para o overlay.
 * @internal
 */
export function injectOverlayContext<T>(): Signal<T> {
  return inject(LudsOverlayContextToken) as Signal<T>;
}

/**
 * Fornece o contexto para o overlay.
 * @param value O valor a ser fornecido como contexto.
 * @internal
 */
export function provideOverlayContext<T>(value: Signal<T | undefined> | undefined): ValueProvider {
  return { provide: LudsOverlayContextToken, useValue: value };
}