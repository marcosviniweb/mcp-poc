import { InjectOptions, Signal } from '@angular/core';
import {
  createState,
  createStateInjector,
  createStateProvider,
  createStateToken,
  State,
} from '@luds/ui/blocks/state';
import type { LudsPopoverTrigger } from './popover-trigger';

/**
 * O token de estado para o primitivo PopoverTrigger.
 */
export const LudsPopoverTriggerStateToken = createStateToken<LudsPopoverTrigger>('PopoverTrigger');

/**
 * Fornece o estado do PopoverTrigger.
 */
export const providePopoverTriggerState = createStateProvider(LudsPopoverTriggerStateToken);

/**
 * Injeta o estado do PopoverTrigger.
 */
export const injectPopoverTriggerState = createStateInjector<LudsPopoverTrigger>(
  LudsPopoverTriggerStateToken,
) as <T>(options?: InjectOptions) => Signal<State<LudsPopoverTrigger<T>>>;

/**
 * A função de registro de estado do PopoverTrigger.
 */
export const popoverTriggerState = createState(LudsPopoverTriggerStateToken);
