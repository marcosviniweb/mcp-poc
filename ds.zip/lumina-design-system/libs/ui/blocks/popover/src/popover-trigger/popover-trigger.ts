import { FocusOrigin } from "@angular/cdk/a11y";
import { BooleanInput, NumberInput } from "@angular/cdk/coercion";
import {
  booleanAttribute,
  computed,
  Directive,
  inject,
  Injector,
  input,
  numberAttribute,
  OnDestroy,
  output,
  signal,
  ViewContainerRef,
} from "@angular/core";
import { Placement } from "@floating-ui/dom";
import { injectElementRef } from "@luds/ui/blocks/internal";
import { createOverlay, LudsOverlay, LudsOverlayConfig, LudsOverlayContent } from "@luds/ui/blocks/portal";
import { injectPopoverConfig } from "../config/popover-config";
import { popoverTriggerState, providePopoverTriggerState } from "./popover-trigger-state";

/**
 * Aplica a diretiva `ludsPopoverTrigger` a um elemento que aciona a exibição do popover.
 */
@Directive({
  selector: "[ludsPopoverTrigger]",
  exportAs: "ludsPopoverTrigger",
  providers: [providePopoverTriggerState({ inherit: false })],
  host: {
    "[attr.aria-expanded]": 'open() ? "true" : "false"',
    "[attr.data-open]": 'open() ? "" : null',
    "[attr.data-placement]": "state.placement()",
    "[attr.data-disabled]": 'state.disabled() ? "" : null',
    "[attr.aria-describedby]": "overlay()?.ariaDescribedBy()",
    "(click)": "toggle($event)",
  },
  standalone: true,
})
export class LudsPopoverTrigger<T = null> implements OnDestroy {
  /**
   * Acessa o elemento trigger
   */
  private readonly trigger = injectElementRef();

  /**
   * Acessa o injetor.
   */
  private readonly injector = inject(Injector);

  /**
   * Acessa a referência do container de view.
   */
  private readonly viewContainerRef = inject(ViewContainerRef);

  /**
   * Acessa a configuração global do popover.
   */
  private readonly config = injectPopoverConfig();

  /**
   * Acessa a referência do template do popover.
   */
  readonly popover = input<LudsOverlayContent<T>>(undefined as unknown as LudsOverlayContent<T>, {
    alias: "ludsPopoverTrigger",
  });

  /**
   * Define se o trigger deve estar desabilitado.
   * @default false
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: "ludsPopoverTriggerDisabled",
    transform: booleanAttribute,
  });

  /**
   * Define o posicionamento do popover relativo ao trigger.
   * @default 'top'
   */
  readonly placement = input<Placement>(this.config.placement, {
    alias: "ludsPopoverTriggerPlacement",
  });

  /**
   * Define o deslocamento do popover relativo ao trigger.
   * @default 0
   */
  readonly offset = input<number, NumberInput>(this.config.offset, {
    alias: "ludsPopoverTriggerOffset",
    transform: numberAttribute,
  });

  /**
   * Define o atraso antes do popover ser exibido.
   * @default 0
   */
  readonly showDelay = input<number, NumberInput>(this.config.showDelay, {
    alias: "ludsPopoverTriggerShowDelay",
    transform: numberAttribute,
  });

  /**
   * Define o atraso antes do popover ser ocultado.
   * @default 0
   */
  readonly hideDelay = input<number, NumberInput>(this.config.hideDelay, {
    alias: "ludsPopoverTriggerHideDelay",
    transform: numberAttribute,
  });

  /**
   * Define se o popover deve virar quando não há espaço suficiente para o popover.
   * @default true
   */
  readonly flip = input<boolean, BooleanInput>(this.config.flip, {
    alias: "ludsPopoverTriggerFlip",
    transform: booleanAttribute,
  });

  /**
   * Define se o popover deve deslocar o elemento flutuante para mantê-lo visível.
   * @default true
   */
  readonly shift = input<boolean, BooleanInput>(this.config.shift, {
    alias: "ludsPopoverTriggerShift",
    transform: booleanAttribute,
  });

  /**
   * Define se deve usar autoPlacement ao invés de flip - considera todos os lados para melhor posicionamento.
   * @default true
   */
  readonly autoPlacement = input<boolean, BooleanInput>(this.config.autoplacement, {
    alias: "ludsPopoverTriggerAutoPlacement",
    transform: booleanAttribute,
  });

  /**
   * Define o container no qual o popover deve ser anexado.
   * @default document.body
   */
  readonly container = input<HTMLElement | null>(this.config.container, {
    alias: "ludsPopoverTriggerContainer",
  });

  /**
   * Define se o popover deve fechar quando clicar fora dele.
   * @default true
   */
  readonly closeOnOutsideClick = input<boolean, BooleanInput>(this.config.closeOnOutsideClick, {
    alias: "ludsPopoverTriggerCloseOnOutsideClick",
    transform: booleanAttribute,
  });

  /**
   * Define se o popover deve fechar quando a tecla escape for pressionada.
   * @default true
   */
  readonly closeOnEscape = input<boolean, BooleanInput>(this.config.closeOnEscape, {
    alias: "ludsPopoverTriggerCloseOnEscape",
    transform: booleanAttribute,
  });

  /**
   * Define como o popover se comporta quando a janela é rolada.
   * @default 'reposition'
   */
  readonly scrollBehavior = input<"reposition" | "block">(this.config.scrollBehavior, {
    alias: "ludsPopoverTriggerScrollBehavior",
  });

  /**
   * Define o espaçamento entre a seta e as bordas do popover.
   * @default 16
   */
  readonly arrowPadding = input<number, NumberInput>(this.config.arrowPadding, {
    alias: "ludsPopoverTriggerArrowPadding",
    transform: numberAttribute,
  });

  /**
   * Fornece contexto para o popover. Isso pode ser usado para passar dados para o conteúdo do popover.
   */
  readonly context = input<T>(undefined as unknown as T, {
    alias: "ludsPopoverTriggerContext",
  });

  /**
   * O overlay que gerencia o popover
   * @internal
   */
  readonly overlay = signal<LudsOverlay<T> | null>(null);

  /**
   * O estado de abertura do popover.
   * @internal
   */
  readonly open = computed(() => this.overlay()?.isOpen() ?? false);

  /**
   * Evento emitido quando o estado de abertura do popover muda.
   */
  readonly openChange = output<boolean>({
    alias: "ludsPopoverTriggerOpenChange",
  });

  /**
   * O estado do trigger do popover.
   */
  readonly state = popoverTriggerState<LudsPopoverTrigger<T>>(this);

  ngOnDestroy(): void {
    this.overlay()?.destroy();
  }

  protected toggle(event: MouseEvent): void {
    // se o trigger está desabilitado, então não alterna o popover
    if (this.state.disabled()) {
      return;
    }

    // determina a origem do evento, 0 é teclado, 1 é mouse
    const origin: FocusOrigin = event.detail === 0 ? "keyboard" : "mouse";

    // se o popover está aberto, então o oculta
    if (this.open()) {
      this.hide(origin);
    } else {
      this.show();
    }
  }

  /**
   * Exibe o popover.
   * @returns Uma promise que resolve quando o popover foi exibido
   */
  async show(): Promise<void> {
    // Se o trigger está desabilitado, não exibe o popover
    if (this.state.disabled()) {
      return;
    }

    // Cria o overlay se ainda não existe
    if (!this.overlay()) {
      this.createOverlay();
    }

    // Exibe o overlay
    await this.overlay()?.show();

    if (this.open()) {
      this.openChange.emit(true);
    }
  }

  /**
   * @internal
   * Oculta o popover.
   * @returns Uma promise que resolve quando o popover foi ocultado
   */
  async hide(origin: FocusOrigin = "program"): Promise<void> {
    // Se o trigger está desabilitado ou o popover não está aberto, não faz nada
    if (this.state.disabled() || !this.open()) {
      return;
    }

    // Oculta o overlay
    await this.overlay()?.hide({ origin });

    this.openChange.emit(false);
  }

  /**
   * Cria o overlay que conterá o popover
   */
  private createOverlay(): void {
    const popover = this.state.popover();

    if (!popover) {
      throw new Error("Popover must be either a TemplateRef or a ComponentType");
    }

    // Cria a configuração para o overlay
    const config: LudsOverlayConfig<T> = {
      content: popover,
      triggerElement: this.trigger.nativeElement,
      injector: this.injector,
      context: this.state.context,
      container: this.state.container(),
      placement: this.state.placement(),
      offset: this.state.offset(),
      flip: this.state.flip(),
      shift: this.state.shift(),
      arrowPadding: this.state.arrowPadding(),
      autoPlacement: this.state.autoPlacement(),
      showDelay: this.state.showDelay(),
      hideDelay: this.state.hideDelay(),
      closeOnOutsideClick: this.state.closeOnOutsideClick(),
      closeOnEscape: this.state.closeOnEscape(),
      restoreFocus: true,
      scrollBehaviour: this.state.scrollBehavior(),
      viewContainerRef: this.viewContainerRef,
    };

    this.overlay.set(createOverlay(config));
  }
}
