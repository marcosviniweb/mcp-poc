import { render } from '@testing-library/angular';
import { LudsPopoverTrigger } from './popover-trigger';

describe('LudsPopoverTrigger', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsPopoverTrigger></div>`, {
      imports: [LudsPopoverTrigger],
    });
  });
});