import { Directive, input } from '@angular/core';
import { LudsFocusTrap } from '@luds/ui/blocks/focus-trap';
import { explicitEffect } from '@luds/ui/blocks/internal';
import { injectOverlay } from '@luds/ui/blocks/portal';

/**
 * Aplica a diretiva `ludsPopover` a um elemento que representa o popover. Isso normalmente seria uma `div` dentro de um `ng-template`.
 */
@Directive({
  selector: '[ludsPopover]',
  exportAs: 'ludsPopover',
  hostDirectives: [LudsFocusTrap],
  host: {
    role: 'dialog',
    '[id]': 'id()',
    '[style.left.px]': 'overlay.position().x',
    '[style.top.px]': 'overlay.position().y',
    '[style.--luds-popover-trigger-width.px]': 'overlay.triggerWidth()',
    '[style.--luds-popover-transform-origin]': 'overlay.transformOrigin()',
    '[attr.data-placement]': 'overlay.finalPlacement()',
    'data-overlay': '',
  },
  standalone: true
})
export class LudsPopover {
  /**
   * Acessa o overlay.
   */
  protected readonly overlay = injectOverlay();

  /**
   * O id único do tooltip.
   */
  readonly id = input(this.overlay.id());

  constructor() {
    explicitEffect([this.id], ([id]) => this.overlay.id.set(id));
  }
}
