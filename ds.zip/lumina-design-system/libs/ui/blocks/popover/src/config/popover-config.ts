import { InjectionToken, Provider, inject } from "@angular/core";
import { type Placement } from "@floating-ui/dom";

export interface LudsPopoverConfig {
  /**
   * Define o deslocamento do popover relativo ao trigger.
   * @default 16
   */
  offset: number;

  /**
   * Define o posicionamento do popover relativo ao trigger.
   * @default 'bottom'
   */
  placement: Placement;

  /**
   * Define o atraso antes do popover ser exibido.
   * @default 0
   */
  showDelay: number;

  /**
   * Define o atraso antes do popover ser ocultado.
   * @default 0
   */
  hideDelay: number;

  /**
   * Define se o popover deve virar quando não há espaço suficiente para o popover.
   * @default true
   */
  flip: boolean;

  /**
   * Define se o popover deve deslocar o elemento flutuante para mantê-lo na visualização.
   * @default true
   */
  shift: boolean;

  /**
   * Define se deve usar autoPlacement ao invés de flip - considera todos os lados para melhor posicionamento.
   * @default true
   */
  autoplacement: boolean;

  /**
   * Define o container no qual o popover deve ser anexado.
   * @default document.body
   */
  container: HTMLElement | null;

  /**
   * Define se o popover deve fechar quando clicar fora dele.
   * @default true
   */
  closeOnOutsideClick: boolean;

  /**
   * Define se o popover deve fechar quando a tecla escape for pressionada.
   * @default true
   */
  closeOnEscape: boolean;

  /**
   * Define como o popover se comporta quando a janela é rolada.
   * @default scroll
   */
  scrollBehavior: "reposition" | "block";

  /**
   * Define o espaçamento entre a seta e as bordas do popover.
   * @default 16
   */
  arrowPadding: number;
}

export const defaultPopoverConfig: LudsPopoverConfig = {
  offset: 16,
  autoplacement: true,
  arrowPadding: 16,
  placement: "bottom",
  showDelay: 0,
  hideDelay: 0,
  flip: true,
  shift: true,
  container: null,
  closeOnOutsideClick: true,
  closeOnEscape: true,
  scrollBehavior: "reposition",
};

export const ludsPopoverConfigToken = new InjectionToken<LudsPopoverConfig>("ludsPopoverConfigToken");

/**
 * Fornece a configuração padrão do Popover
 * @param config A configuração do Popover
 * @returns O provider
 */
export function providePopoverConfig(config: Partial<LudsPopoverConfig>): Provider[] {
  return [
    {
      provide: ludsPopoverConfigToken,
      useValue: { ...defaultPopoverConfig, ...config },
    },
  ];
}

/**
 * Injeta a configuração do Popover
 * @returns A configuração global do Popover
 */
export function injectPopoverConfig(): LudsPopoverConfig {
  return inject(ludsPopoverConfigToken, { optional: true }) ?? defaultPopoverConfig;
}
