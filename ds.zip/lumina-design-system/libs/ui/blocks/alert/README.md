# @luds/ui/blocks/alert

Secondary entry point of `@luds/ui`. It can be used by importing from `@luds/ui/blocks/alert`.
