import {
  createState,
  createStateInjector,
  createStateProvider,
  createStateToken,
} from '@luds/ui/blocks/state';
import type { LudsAlert } from './alert';

/**
 * O token de estado para o componente Alert.
 */
export const ludsAlertStateToken = createStateToken<LudsAlert>('Alert');

/**
 * Fornece o estado do Alert.
 */
export const provideAlertState = createStateProvider(ludsAlertStateToken);

/**
 * Injeta o estado do Alert.
 */
export const injectAlertState = createStateInjector<LudsAlert>(ludsAlertStateToken);

/**
 * Função de registro de estado do Alert.
 */
export const alertState = createState(ludsAlertStateToken);