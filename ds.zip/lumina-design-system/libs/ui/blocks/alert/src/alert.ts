import { Directive, input } from '@angular/core';
import { provideAlertState, alertState } from './alert-state';

/**
 * Variantes de alert disponíveis que determinam o estilo visual.
 */
export type LudsAlertType = 'success' | 'warning' | 'info' | 'error';

/**
 * Tamanhos de alert disponíveis que controlam o tamanho vertical, o tamanho da fonte e ícone.
 */
export type LudsAlertSize = 'default' | 'small';

/**
 * Fundos de alert disponíveis que controlam se o fundo contém cor de fundo ou não.
 */
export type LudsAlertBackground = 'solid' | 'soft' | 'flat';

/**
 * Diretiva `ludsAlert` para exibir alertas informativos com variantes de cor, tamanho e fundo.
 * 
 * Esta diretiva é utilizada em conjunto com uma das quatro opções de ícones da biblioteca `Phosphor Icons` para compor a interface visual.
 */
@Directive({
  selector: 'div[ludsAlert]',
  standalone: true,
  exportAs: 'ludsAlert',
  providers: [provideAlertState()],
  host: {
    '[attr.data-size]': 'size()',
    '[attr.data-type]': 'type()',
    '[attr.data-background]': 'background()',
    '[attr.role]' : '"alert"'
  }
})
export class LudsAlert {
  /** Tipo da Alert: controla cor e ícone */
  type = input<LudsAlertType>('info');

  /** Tamanho da Alert */
  size = input<LudsAlertSize>('default');

  /** Fundo da Alert */
  background = input<LudsAlertBackground>('solid');

  /** O estado da Alert */
  protected readonly state = alertState<LudsAlert>(this);
}
