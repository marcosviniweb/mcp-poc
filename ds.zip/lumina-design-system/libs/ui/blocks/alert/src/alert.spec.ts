import { render } from "@testing-library/angular";
import { LudsAlert } from "./alert";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorCheckCircle } from "@ng-icons/phosphor-icons/regular";

describe("LudsAlert", () => {
  it("should create an instance", async () => {
    const { getByTestId } = await render(
      `<span ludsAlert type='success' size='small' background='solid' data-testid="alert" aria-label="Alerta do tipo sucesso">
    <ng-icon name="phosphorCheckCircle" alt="Ícone de sucesso"></ng-icon>
    <span ludsAlertTextContainer>
      <p ludsAlertTitle class="luds-label-small-bold">Title</p>
      <p ludsAlertContent class="luds-label-small-default">Content</p>
    </span>
</span>`,
      {
        imports: [LudsAlert, NgIcon],
        providers: [provideIcons({ phosphorCheckCircle })],
      },
    );
    const alert = getByTestId("alert");
    expect(alert).toBeTruthy();
  });
});
