import { InjectionToken, Provider, inject } from '@angular/core';
import { Placement } from '@floating-ui/dom';

export interface LudsMenuConfig {
  /**
   * Define o offset do menu em relação ao gatilho.
   * @default 16
   */
  offset: number;

  /**
   * Define a posição do menu em relação ao gatilho.
   * @default 'bottom-end'
   */
  placement: Placement;

  /**
   * Define se o menu deve ser invertido quando não há espaço suficiente para o menu.
   * @default false
   */
  flip: boolean;

  /**
 * Define se o popover deve deslocar o elemento flutuante para mantê-lo na visualização.
 * @default true
 */
  shift: boolean;

  /**
   * Define se deve usar autoPlacement ao invés de flip - considera todos os lados para melhor posicionamento.
   * @default false
   */
  autoplacement: boolean;

  /**
   * Define o elemento ou seletor do contêiner no qual o menu deve ser anexado.
   * @default 'body'
   */
  container: HTMLElement | string | null;

  /**
   * Define como o menu se comporta quando a janela é rolada.
   * @default scroll
   */
  scrollBehavior: 'reposition' | 'block';

  /**
   * Define o espaçamento entre a seta e as bordas do popover.
   * @default 24
   */
  arrowPadding: number;
}

export const defaultMenuConfig: LudsMenuConfig = {
  offset: 16,
  autoplacement: false,
  arrowPadding: 24,
  shift: true,
  placement: 'bottom-end',
  flip: false,
  container: null,
  scrollBehavior: 'reposition',
};

export const LudsMenuConfigToken = new InjectionToken<LudsMenuConfig>('LudsMenuConfigToken');

/**
 * Provê a configuração padrão do Menu
 * @param config A configuração do Menu
 * @returns O provedor
 */
export function provideMenuConfig(config: Partial<LudsMenuConfig>): Provider[] {
  return [
    {
      provide: LudsMenuConfigToken,
      useValue: { ...defaultMenuConfig, ...config },
    },
  ];
}

/**
 * Injeta a configuração do Menu
 * @returns A configuração global do Menu
 */
export function injectMenuConfig(): LudsMenuConfig {
  return inject(LudsMenuConfigToken, { optional: true }) ?? defaultMenuConfig;
}
