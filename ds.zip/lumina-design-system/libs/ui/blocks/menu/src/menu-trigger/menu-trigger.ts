import { FocusOrigin } from '@angular/cdk/a11y';
import { BooleanInput, NumberInput } from '@angular/cdk/coercion';
import {
  booleanAttribute,
  computed,
  Directive,
  inject,
  Injector,
  input,
  numberAttribute,
  OnDestroy,
  signal,
  ViewContainerRef,
} from '@angular/core';
import { Placement } from '@floating-ui/dom';
import { injectElementRef } from '@luds/ui/blocks/internal';
import {
  createOverlay,
  LudsOverlay,
  LudsOverlayConfig,
  LudsOverlayContent,
} from '@luds/ui/blocks/portal';
import { injectMenuConfig } from '../config/menu-config';
import { menuTriggerState, provideMenuTriggerState } from './menu-trigger-state';

/**
 * A diretiva `LudsMenuTrigger` permite transformar um elemento em um gatilho de menu.
 */
@Directive({
  selector: '[ludsMenuTrigger]',
  exportAs: 'ludsMenuTrigger',
  standalone: true,
  providers: [provideMenuTriggerState({ inherit: false })],
  host: {
    'aria-haspopup': 'true',
    '[attr.aria-expanded]': 'open() ? "true" : "false"',
    '[attr.data-open]': 'open() ? "" : null',
    '[attr.data-placement]': 'state.placement()',
    '(click)': 'toggle($event)',
  },
})
export class LudsMenuTrigger<T = unknown> implements OnDestroy {
  /**
   * Accessa o elemento do gatilho
   */
  private readonly trigger = injectElementRef();

  /**
   * Accessa o injector.
   */
  private readonly injector = inject(Injector);

  /**
   * Accessa a referência do contêiner de visualização.
   */
  private readonly viewContainerRef = inject(ViewContainerRef);

  /**
   * Accessa a configuração global do menu.
   */
  private readonly config = injectMenuConfig();

  /**
   * Accessa a referência do template do menu.
   */
  readonly menu = input<LudsOverlayContent<T>>(undefined as unknown as LudsOverlayContent<T>, {
    alias: 'ludsMenuTrigger',
  });

  /**
   * Define se o gatilho deve ser desativado.
   * @default false
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsMenuTriggerDisabled',
    transform: booleanAttribute,
  });

  /**
   * Define o posicionamento do menu em relação ao gatilho.
   * @default 'bottom-end'
   */
  readonly placement = input<Placement>(this.config.placement, {
    alias: 'ludsMenuTriggerPlacement',
  });

  /**
   * Define o deslocamento do menu em relação ao gatilho.
   * @default 16
   */
  readonly offset = input<number, NumberInput>(this.config.offset, {
    alias: 'ludsMenuTriggerOffset',
    transform: numberAttribute,
  });

  /**
   * Define se o menu deve ser invertido quando não houver espaço suficiente para o menu.
   * @default true
   */
  readonly flip = input<boolean, BooleanInput>(this.config.flip, {
    alias: 'ludsMenuTriggerFlip',
    transform: booleanAttribute,
  });

  /**
 * Define se o popover deve deslocar o elemento flutuante para mantê-lo visível.
 * @default true
 */
  readonly shift = input<boolean, BooleanInput>(this.config.shift, {
    alias: "ludsMenuTriggerShift",
    transform: booleanAttribute,
  });

  /**
   * Define se deve usar autoPlacement ao invés de flip - considera todos os lados para melhor posicionamento.
   * @default false
   */
  readonly autoPlacement = input<boolean, BooleanInput>(this.config.autoplacement, {
    alias: "ludsMenuTriggerAutoPlacement",
    transform: booleanAttribute,
  });

  /**
   * Define o contêiner no qual o menu deve ser anexado.
   * @default document.body
   */
  readonly container = input<HTMLElement | string | null>(this.config.container, {
    alias: 'ludsMenuTriggerContainer',
  });

  /**
   * Define como o menu se comporta quando a janela é rolada.
   * @default 'block'
   */
  readonly scrollBehavior = input<'reposition' | 'block'>(this.config.scrollBehavior, {
    alias: 'ludsMenuTriggerScrollBehavior',
  });

  /**
   * Define o espaçamento entre a seta e as bordas do popover.
   * @default 24
   */
  readonly arrowPadding = input<number, NumberInput>(this.config.arrowPadding, {
    alias: "ludsMenuTriggerArrowPadding",
    transform: numberAttribute,
  });

  /**
   * Provê contexto para o menu. Isso pode ser usado para passar dados para o conteúdo do menu.
   */
  readonly context = input<T>(undefined as unknown as T, {
    alias: 'ludsMenuTriggerContext',
  });

  /**
   * O overlay que gerencia o menu
   * @internal
   */
  readonly overlay = signal<LudsOverlay<T> | null>(null);

  /**
   * O estado de abertura do menu.
   * @internal
   */
  readonly open = computed(() => this.overlay()?.isOpen() ?? false);

  /**
   * O estado do gatilho do menu.
   */
  readonly state = menuTriggerState<LudsMenuTrigger<T>>(this);

  ngOnDestroy(): void {
    this.overlay()?.destroy();
  }

  protected toggle(event: MouseEvent): void {
    // se o gatilho está desativado, não alternar o menu
    if (this.state.disabled()) {
      return;
    }

    // determina a origem do evento, 0 é teclado, 1 é mouse
    const origin: FocusOrigin = event.detail === 0 ? 'keyboard' : 'mouse';

    // se o menu está aberto, então esconda-o
    if (this.open()) {
      this.hide(origin);
    } else {
      this.show();
    }
  }

  /**
   * Mostra o menu.
   */
  show(): void {
    // Se o gatilho está desativado, não mostre o menu
    if (this.state.disabled()) {
      return;
    }

    // Cria o overlay se ainda não existir
    if (!this.overlay()) {
      this.createOverlay();
    }

    // Mostra o overlay
    this.overlay()?.show();
  }

  /**
   * @internal
   * Oculta o menu.
   */
  hide(origin: FocusOrigin = 'program'): void {
    // Se o gatilho está desativado ou o menu não está aberto, não faça nada
    if (this.state.disabled() || !this.open()) {
      return;
    }

    // Oculta o overlay
    this.overlay()?.hide({ origin });
  }

  /**
   * Cria o overlay que conterá o menu
   */
  private createOverlay(): void {
    const menu = this.state.menu();

    if (!menu) {
      throw new Error('Menu deve ser um TemplateRef ou um ComponentType');
    }

    // Cria a configuração para o overlay
    const config: LudsOverlayConfig<T> = {
      content: menu,
      triggerElement: this.trigger.nativeElement,
      viewContainerRef: this.viewContainerRef,
      injector: this.injector,
      context: this.state.context,
      container: this.state.container(),
      placement: this.state.placement(),
      offset: this.state.offset(),
      flip: this.state.flip(),
      shift: this.state.shift(),
      arrowPadding: this.state.arrowPadding(),
      autoPlacement: this.state.autoPlacement(),
      closeOnOutsideClick: true,
      closeOnEscape: true,
      restoreFocus: true,
      scrollBehaviour: this.state.scrollBehavior(),
    };

    this.overlay.set(createOverlay(config));
  }
}
