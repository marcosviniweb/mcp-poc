import {
  createState,
  createStateInjector,
  createStateProvider,
  createStateToken,
} from '@luds/ui/blocks/state';
import type { LudsMenuTrigger } from './menu-trigger';

/**
 * O token de estado para o MenuTrigger primitive.
 */
export const LudsMenuTriggerStateToken = createStateToken<LudsMenuTrigger>('MenuTrigger');

/**
 * Provê o estado do MenuTrigger.
 */
export const provideMenuTriggerState = createStateProvider(LudsMenuTriggerStateToken);

/**
 * Injecta o estado do MenuTrigger.
 */
export const injectMenuTriggerState = createStateInjector<LudsMenuTrigger>(LudsMenuTriggerStateToken);

/**
 * A função de registro do estado do MenuTrigger.
 */
export const menuTriggerState = createState(LudsMenuTriggerStateToken);
