import { FocusOrigin } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import { booleanAttribute, Directive, HostListener, inject, Injector, input } from '@angular/core';
import { setupButton } from '@luds/ui/blocks/internal';
import { injectElementRef } from '@luds/ui/blocks/internal';
import { LudsRovingFocusItem } from '@luds/ui/blocks/roving-focus';
import { injectMenu } from '../menu/menu-token';
import { LudsSubmenuTrigger } from '../submenu-trigger/submenu-trigger';

/**
 * A diretiva `LudsMenuItem` representa um item de menu.
 */
@Directive({
  selector: '[ludsMenuItem]',
  exportAs: 'ludsMenuItem',
  standalone: true,
  hostDirectives: [
    { directive: LudsRovingFocusItem, inputs: ['ludsRovingFocusItemDisabled: ludsMenuItemDisabled'] },
  ],
  host: {
    role: 'menuitem',
    '(click)': 'onClick($event)',
    '(keydown.ArrowLeft)': 'handleArrowKey($event)',
    '(keydown.ArrowRight)': 'handleArrowKey($event)',
  },
})
export class LudsMenuItem {
  /** Accessa o injector */
  private readonly injector = inject(Injector);
  /** Accessa o elemento do botão */
  private readonly elementRef = injectElementRef();

  /** Accessa o menu pai */
  private readonly parentMenu = injectMenu();

  /** Se o item do menu está desativado */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsMenuItemDisabled',
    transform: booleanAttribute,
  });

  constructor() {
    setupButton({ disabled: this.disabled });
  }

  /** Fecha o menu quando o item é clicado */
  protected onClick(event: MouseEvent): void {
    // fazemos isso aqui para evitar problemas de dependência circular
    const trigger = this.injector.get(LudsSubmenuTrigger, null, { self: true, optional: true });

    const origin: FocusOrigin = event.detail === 0 ? 'keyboard' : 'mouse';

    // se este é um gatilho de submenu, não queremos fechar o menu, queremos abrir o submenu
    if (!trigger) {
      this.parentMenu?.closeAllMenus(origin);
    }
  }

  /**
   * Se o usuário pressionar a tecla de seta para a esquerda (em LTR) e houver um menu pai,
   * queremos fechar o menu e focar no item do menu pai.
   */
  protected handleArrowKey(event: KeyboardEvent): void {
    // se não houver menu pai, não queremos fazer nada
    const trigger = this.injector.get(LudsSubmenuTrigger, null, { optional: true });

    if (!trigger) {
      return;
    }

    const direction = getComputedStyle(this.elementRef.nativeElement).direction;
    const isRtl = direction === 'rtl';

    const isLeftArrow = event.key === 'ArrowLeft';
    const isRightArrow = event.key === 'ArrowRight';

    if ((isLeftArrow && !isRtl) || (isRightArrow && isRtl)) {
      event.preventDefault();

      if (trigger) {
        trigger.hide('keyboard');
      }
    }
  }

  /**
   * Se o usuário passar o mouse sobre o gatilho, queremos abrir o submenu
   */
  @HostListener('mouseenter')
  protected showSubmenuOnHover(): void {
    this.parentMenu?.closeSubmenus.next(this.elementRef.nativeElement);
  }
}
