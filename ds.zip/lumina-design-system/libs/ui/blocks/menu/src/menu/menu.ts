import { FocusOrigin } from '@angular/cdk/a11y';
import { Directive, inject, input } from '@angular/core';
import { LudsFocusTrap } from '@luds/ui/blocks/focus-trap';
import { injectOverlay } from '@luds/ui/blocks/portal';
import { LudsRovingFocusGroup, provideRovingFocusGroup, injectRovingFocusGroupState } from '@luds/ui/blocks/roving-focus';
import { Subject } from 'rxjs';
import { injectMenuTriggerState } from '../menu-trigger/menu-trigger-state';
import { LudsMenuToken, provideMenu } from './menu-token';
import { LudsOrientation } from '@luds/ui/blocks/common';

/**
 * O `LudsMenu` é um contêiner para itens de menu que oferece navegação intuitiva por teclado
 * e posicionamento automático. Permite que o usuário navegue entre as opções usando as setas
 * do teclado, voltando ao início quando chega ao final da lista, e se integra com submenus.
 */
@Directive({
  selector: '[ludsMenu]',
  exportAs: 'ludsMenu',
  standalone: true,
  hostDirectives: [{
    directive: LudsRovingFocusGroup,
    inputs: ['ludsRovingFocusGroupOrientation:orientation']
  },
    LudsFocusTrap
  ],
  providers: [
    // garante que não herdamos o grupo de foco do menu pai, se houver um
    provideRovingFocusGroup(LudsRovingFocusGroup, { inherit: false }),
    provideMenu(LudsMenu),
  ],
  host: {
    role: 'menu',
    '[style.left.px]': 'overlay.position().x',
    '[style.top.px]': 'overlay.position().y',
    '[style.--luds-menu-trigger-width.px]': 'overlay.triggerWidth()',
    '[style.--luds-menu-transform-origin]': 'overlay.transformOrigin()',
    '[attr.data-placement]': 'overlay.finalPlacement()',
    'data-overlay': '',
  },
})
export class LudsMenu {
  /**
   * Accessa o estado de grupo do roving focus.
   */
  private readonly rovingFocusGroupState = injectRovingFocusGroupState();

  /** Accessa o overlay. */
  protected readonly overlay = injectOverlay();

  /** Accessa o estado do gatilho do menu */
  private readonly menuTrigger = injectMenuTriggerState();

  /** Accessa qualquer menu pai */
  private readonly parentMenu = inject(LudsMenuToken, { optional: true, skipSelf: true });

  /** @internal Se devemos fechar submenus */
  readonly closeSubmenus = new Subject<HTMLElement>();

  /**
   * A orientação do menu.
   * @default 'vertical'
   */
  readonly orientation = input<LudsOrientation>('vertical', {
    alias: 'ludsMenuOrientation',
  });


  /** @internal Fecha o menu e qualquer menu pai */
  closeAllMenus(origin: FocusOrigin): void {
    this.menuTrigger().hide(origin);
    this.parentMenu?.closeAllMenus(origin);
  }

  ngOnInit(): void {
    // the roving focus group defaults to vertical orientation whereas we want to default to vertical
    this.rovingFocusGroupState().orientation.set(this.orientation());
  }
}
