import { ExistingProvider, inject, InjectionToken, Type } from '@angular/core';
import type { LudsMenu } from './menu';

export const LudsMenuToken = new InjectionToken<LudsMenu>('LudsMenuToken');

/**
 * Injeta a instância da diretiva Menu
 */
export function injectMenu(): LudsMenu {
  return inject(LudsMenuToken);
}

/**
 * Provê a instância da diretiva Menu
 */
export function provideMenu(type: Type<LudsMenu>): ExistingProvider {
  return { provide: LudsMenuToken, useExisting: type };
}
