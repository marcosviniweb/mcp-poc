import { FocusOrigin } from '@angular/cdk/a11y';
import { BooleanInput, NumberInput } from '@angular/cdk/coercion';
import {
  booleanAttribute,
  computed,
  Directive,
  HostListener,
  inject,
  Injector,
  input,
  numberAttribute,
  signal,
  ViewContainerRef,
} from '@angular/core';
import { Placement } from '@floating-ui/dom';
import { injectElementRef } from '@luds/ui/blocks/internal';
import {
  createOverlay,
  LudsOverlay,
  LudsOverlayConfig,
  LudsOverlayContent,
} from '@luds/ui/blocks/portal';
import { safeTakeUntilDestroyed } from '@luds/ui/blocks/utils';
import { LudsMenuToken } from '../menu/menu-token';
import { provideSubmenuTriggerState, submenuTriggerState } from './submenu-trigger-state';

@Directive({
  selector: '[ludsSubmenuTrigger]',
  exportAs: 'ludsSubmenuTrigger',
  standalone: true,
  providers: [provideSubmenuTriggerState({ inherit: false })],
  host: {
    'aria-haspopup': 'true',
    '[attr.aria-expanded]': 'open() ? "true" : "false"',
    '[attr.data-open]': 'open() ? "" : null',
    '(click)': 'toggle($event)',
  },
})
export class LudsSubmenuTrigger<T = unknown> {
  /**
   * Accessa o elemento do gatilho do submenu.
   */
  private readonly trigger = injectElementRef();

  /**
   * Accessa o injector.
   */
  private readonly injector = inject(Injector);

  /**
   * Accessa a referência do contêiner de visualização.
   */
  private readonly viewContainerRef = inject(ViewContainerRef);

  /** Accessa o menu pai */
  private readonly parentMenu = inject(LudsMenuToken, { optional: true });

  /**
   * Accessa a referência do template do submenu.
   */
  readonly menu = input<LudsOverlayContent<T>>(undefined as unknown as LudsOverlayContent<T>, {
    alias: 'ludsSubmenuTrigger',
  });

  /**
   * Define se o gatilho deve ser desativado.
   * @default false
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsSubmenuTriggerDisabled',
    transform: booleanAttribute,
  });

  /**
   * Define o posicionamento do menu em relação ao gatilho.
   * @default 'right-start'
   */
  readonly placement = input<Placement>('right-start', {
    alias: 'ludsSubmenuTriggerPlacement',
  });

  /**
   * Define o deslocamento do menu em relação ao gatilho.
   * @default 0
   */
  readonly offset = input<number, NumberInput>(0, {
    alias: 'ludsSubmenuTriggerOffset',
    transform: numberAttribute,
  });

  /**
   * Define se o menu deve ser invertido quando não houver espaço suficiente para o menu.
   * @default true
   */
  readonly flip = input<boolean, BooleanInput>(true, {
    alias: 'ludsSubmenuTriggerFlip',
    transform: booleanAttribute,
  });

  /**
   * O overlay que gerencia o menu
   * @internal
   */
  readonly overlay = signal<LudsOverlay<T> | null>(null);

  /**
   * O estado de abertura do menu.
   * @internal
   */
  readonly open = computed(() => this.overlay()?.isOpen() ?? false);

  /**
   * Accessa o estado do gatilho do menu.
   */
  readonly state = submenuTriggerState<LudsSubmenuTrigger<T>>(this);

  constructor() {
    this.parentMenu?.closeSubmenus.pipe(safeTakeUntilDestroyed()).subscribe(element => {
      // se o elemento não for o gatilho, queremos fechar o menu
      if (element === this.trigger.nativeElement) {
        return;
      }

      this.hide('mouse');
    });
  }

  protected toggle(event: MouseEvent): void {
    // se o gatilho estiver desativado, não altere o menu
    if (this.state.disabled()) {
      return;
    }

    // determina a origem do evento, 0 é teclado, 1 é mouse
    const origin: FocusOrigin = event.detail === 0 ? 'keyboard' : 'mouse';

    // se o menu estiver aberto, então oculte-o
    if (this.open()) {
      this.hide(origin);
    } else {
      this.show();
    }
  }

  /**
   * Mostra o menu.
   */
  show(): void {
    // Se o gatilho estiver desativado, não mostra o menu
    if (this.state.disabled()) {
      return;
    }

    // Cria o overlay se ele ainda não existir
    if (!this.overlay()) {
      this.createOverlay();
    }

    // Mostra o overlay
    this.overlay()?.show();
  }

  /**
   * @internal
   * Oculta o menu.
   */
  hide(origin: FocusOrigin = 'program'): void {
    // Se o gatilho estiver desativado ou o menu não estiver aberto, não faça nada
    if (this.state.disabled() || !this.open()) {
      return;
    }

    // Oculta o overlay
    this.overlay()?.hide({ origin });
  }

  /**
   * Cria o overlay que conterá o menu
   */
  private createOverlay(): void {
    const menu = this.state.menu();

    if (!menu) {
      throw new Error('Menu deve ser um TemplateRef ou um ComponentType');
    }

    // Cria a configuração para o overlay
    const config: LudsOverlayConfig<T> = {
      content: menu,
      triggerElement: this.trigger.nativeElement,
      injector: this.injector,
      placement: this.state.placement(),
      offset: this.state.offset(),
      flip: this.state.flip(),
      closeOnOutsideClick: true,
      closeOnEscape: true,
      restoreFocus: true,
      viewContainerRef: this.viewContainerRef,
    };

    this.overlay.set(createOverlay(config));
  }

  /**
   * Se o usuário pressionar a tecla de seta para a direita, queremos abrir o submenu
   * e focar o primeiro item no submenu.
   * Esse comportamento será invertido se a direção for RTL.
   * @param event
   */
  @HostListener('keydown.ArrowRight', ['$event'])
  @HostListener('keydown.ArrowLeft', ['$event'])
  protected showSubmenuOnArrow(event: KeyboardEvent): void {
    const direction = getComputedStyle(this.trigger.nativeElement).direction;

    const isRtl = direction === 'rtl';

    const isRightArrow = event.key === 'ArrowRight';
    const isLeftArrow = event.key === 'ArrowLeft';

    if ((isRightArrow && !isRtl) || (isLeftArrow && isRtl)) {
      event.preventDefault();
      this.show();
    }
  }

  /**
   * Se o usuário passar o mouse sobre o gatilho, queremos abrir o submenu
   */
  @HostListener('pointerenter', ['$event'])
  protected showSubmenuOnHover(event: PointerEvent): void {
    // se isso foi acionado por um evento de toque, não queremos mostrar o submenu
    // pois ele será mostrado pelo evento de clique - isso impede que o submenu seja alternado
    if (event.pointerType === 'touch') {
      return;
    }

    this.show();
  }
}
