import {
  createState,
  createStateInjector,
  createStateProvider,
  createStateToken,
} from '@luds/ui/blocks/state';
import type { LudsSubmenuTrigger } from './submenu-trigger';

/**
 * O token de estado para o SubmenuTrigger primitive.
 */
export const LudsSubmenuTriggerStateToken = createStateToken<LudsSubmenuTrigger>('SubmenuTrigger');

/**
 * Provê o estado do SubmenuTrigger.
 */
export const provideSubmenuTriggerState = createStateProvider(LudsSubmenuTriggerStateToken);

/**
 * Injeta o estado do SubmenuTrigger.
 */
export const injectSubmenuTriggerState = createStateInjector<LudsSubmenuTrigger>(
  LudsSubmenuTriggerStateToken,
);

/**
 * A função de registro de estado do SubmenuTrigger.
 */
export const submenuTriggerState = createState(LudsSubmenuTriggerStateToken);
