import { Directive } from '@angular/core';
import { setupOverlayArrow } from '@luds/ui/blocks/portal';

/**
 * Diretiva que adiciona uma seta ao popover para indicar sua relação com o elemento trigger.
 * Aplique esta diretiva a um elemento dentro do popover que deve ser renderizado como uma seta.
 */
@Directive({
  selector: '[ludsMenuArrow]',
  exportAs: 'ludsMenuArrow',
  standalone: true
})
export class LudsMenuArrow {
  constructor() {
    setupOverlayArrow();
  }
}
