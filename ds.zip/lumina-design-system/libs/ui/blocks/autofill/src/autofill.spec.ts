import { render } from '@testing-library/angular';
import { LudsAutofill } from './autofill';

describe('LudsAutofill', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsAutofill></div>`, {
      imports: [LudsAutofill],
    });
  });
});