import { ElementRef } from '@angular/core';
import { Component } from '@angular/core';
import { render } from '@testing-library/angular';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { LudsChip, LudsChipVariant, LudsChipSize } from './chip';

function generateChipWrapperComponent(variant: LudsChipVariant = 'positive', size: LudsChipSize = 'default', closeable: boolean = false) {
  @Component({
    selector: 'app-chip-wrapper',
    imports: [LudsChip],
    template: `<span ludsChip [variant]="variant" [size]="size" [closeable]="closeable" (closed)="onClosed()">Chip Text</span>`,
    standalone: true,
  })
  class TestChipWrapperComponent {
    variant = variant;
    size = size;
    closeable = closeable;
    onClosed = vi.fn();
  }
  return TestChipWrapperComponent;
}

describe('LudsChip Directive', () => {
  beforeEach(() => {
    vi.spyOn(console, 'warn').mockImplementation(() => {});
  });

  describe('Attribute bindings', () => {
    it('should set data-variant attribute according to the variant input', async () => {
      const component = generateChipWrapperComponent('negative', 'default');
      const { container } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      expect(chip).toHaveAttribute('data-variant', 'negative');
    });

    it('should set data-size attribute according to the size input', async () => {
      const component = generateChipWrapperComponent('positive', 'small');
      const { container } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      expect(chip).toHaveAttribute('data-size', 'small');
    });

    it('should set data-closeable attribute when closeable is true', async () => {
      const component = generateChipWrapperComponent('positive', 'default', true);
      const { container } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      expect(chip).toHaveAttribute('data-closeable', '');
    });

    it('should not set data-closeable attribute when closeable is false', async () => {
      const component = generateChipWrapperComponent('positive', 'default', false);
      const { container } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      expect(chip?.hasAttribute('data-closeable')).toBe(false);
    });

    it('should have tabindex attribute set to 0', async () => {
      const component = generateChipWrapperComponent();
      const { container } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      expect(chip).toHaveAttribute('tabindex', '0');
    });
  });

  describe('Content behavior', () => {
    it('should keep content for any size', async () => {
      const component = generateChipWrapperComponent('positive', 'default');
      const { container } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      expect(chip?.textContent).toBe('Chip Text');
    });

    it('should keep content when size is small', async () => {
      const component = generateChipWrapperComponent('positive', 'small');
      const { container } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      expect(chip?.textContent).toBe('Chip Text');
    });
  });

  describe('Dynamic changes', () => {
    it('should update data-variant when variant changes', async () => {
      const { container, rerender } = await render(`<span ludsChip [variant]="variant" [size]="size">Chip</span>`, {
        imports: [LudsChip],
        componentProperties: {
          variant: 'positive' as LudsChipVariant,
          size: 'default' as LudsChipSize,
        },
      });
      const chip = container.querySelector('[ludsChip]');
      expect(chip).toHaveAttribute('data-variant', 'positive');
      await rerender({ componentProperties: { variant: 'negative', size: 'default' } });
      expect(chip).toHaveAttribute('data-variant', 'negative');
    });

    it('should update data-size when size changes', async () => {
      const { container, rerender } = await render(`<span ludsChip [variant]="variant" [size]="size">Chip</span>`, {
        imports: [LudsChip],
        componentProperties: {
          variant: 'positive' as LudsChipVariant,
          size: 'default' as LudsChipSize,
        },
      });
      const chip = container.querySelector('[ludsChip]');
      expect(chip).toHaveAttribute('data-size', 'default');
      await rerender({ componentProperties: { variant: 'positive', size: 'small' } });
      expect(chip).toHaveAttribute('data-size', 'small');
    });

    it('should update data-closeable when closeable changes', async () => {
      const { container, rerender } = await render(`<span ludsChip [variant]="variant" [size]="size" [closeable]="closeable">Chip</span>`, {
        imports: [LudsChip],
        componentProperties: {
          variant: 'positive' as LudsChipVariant,
          size: 'default' as LudsChipSize,
          closeable: false,
        },
      });
      const chip = container.querySelector('[ludsChip]');
      expect(chip?.hasAttribute('data-closeable')).toBe(false);
      await rerender({ componentProperties: { closeable: true } });
      expect(chip).toHaveAttribute('data-closeable', '');
    });
  });

  describe('Event behavior', () => {
    it('should emit closed when closeable and clicked', async () => {
      const component = generateChipWrapperComponent('positive', 'default', true);
      const { container, fixture } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      chip?.dispatchEvent(new MouseEvent('click'));
      expect(fixture.componentInstance.onClosed).toHaveBeenCalledTimes(1);
    });

    it('should not emit closed when not closeable and clicked', async () => {
      const component = generateChipWrapperComponent('positive', 'default', false);
      const { container, fixture } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      chip?.dispatchEvent(new MouseEvent('click'));
      expect(fixture.componentInstance.onClosed).not.toHaveBeenCalled();
    });

    it('should emit closed when closeable and space key pressed', async () => {
      const component = generateChipWrapperComponent('positive', 'default', true);
      const { container, fixture } = await render(component);
      const chip = container.querySelector('[ludsChip]');
      chip?.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space', key: ' ' }));
      expect(fixture.componentInstance.onClosed).toHaveBeenCalledTimes(1);
    });
  });
});
