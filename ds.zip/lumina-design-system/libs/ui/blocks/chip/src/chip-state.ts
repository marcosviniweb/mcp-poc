import { createState, createStateInjector, createStateProvider, createStateToken } from '@luds/ui/blocks/state';
import { LudsChip } from './chip';

/**
 * O token de estado para o componente Chip.
 */
export const ludsChipStateToken = createStateToken<LudsChip>('Chip');

/**
 * Fornece o estado do Chip.
 */
export const provideChipState = createStateProvider(ludsChipStateToken);

/**
 * Injeta o estado do Chip.
 */
export const injectChipState = createStateInjector<LudsChip>(ludsChipStateToken);

/**
 * Função de registro de estado do Chip.
 */
export const ChipState = createState(ludsChipStateToken);
