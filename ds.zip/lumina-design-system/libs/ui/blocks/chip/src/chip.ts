import { Directive, HostListener, input, output } from '@angular/core';
import { setupInteractions } from '@luds/ui/blocks/internal';
import { provideChipState } from './chip-state';

/**
 * Variantes visuais disponíveis para o chip.
 */
export type LudsChipVariant = 'positive' | 'negative';

/**
 * Tamanhos disponíveis para o chip.
 */
export type LudsChipSize = 'default' | 'small';

/**
 * Diretiva que aplica estilos e comportamentos de chip a qualquer elemento.
 * Permite customizar variante visual e tamanho, além de garantir acessibilidade.
 */

@Directive({
  selector: '[ludsChip]',
  standalone: true,
  exportAs: 'ludsChip',
  providers: [provideChipState()],

  host: {
    '[attr.data-variant]': 'variant()',
    '[attr.data-size]': 'size()',
    '[attr.data-closeable]': 'closeable() ? "" : null',
    '[attr.tabindex]': '0',
  },
})

/**
 * A diretiva `dsChip` aplica estilos e comportamentos de chip a qualquer elemento.
 * Permite customizar variante visual e tamanho, além de garantir acessibilidade.
 */
export class LudsChip {
  /**
   * Variante visual do chip.
   */
  public readonly variant = input<LudsChipVariant>('positive');

  /**
   * Tamanho do chip.
   */
  public readonly size = input<LudsChipSize>('default');

  /**
   * Define se o chip é fechável.
   */
  public readonly closeable = input<boolean>(false);

  /**
   * Evento emitido quando o chip é fechado.
   */
  public readonly closed = output();

  /**
   * @internal
   */
  constructor() {
    setupInteractions({
      focusVisible: true,
    });
  }

  @HostListener('click', ['$event'])
  @HostListener('keydown.space', ['$event'])
  close(event?: Event): void {
    if (this.closeable()) {
      this.closed.emit();
    }
  }
}
