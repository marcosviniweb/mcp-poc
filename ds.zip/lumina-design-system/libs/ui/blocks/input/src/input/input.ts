import { BooleanInput } from '@angular/cdk/coercion';
import { booleanAttribute, Directive, input, Signal } from '@angular/core';
import { LudsAutofill } from '@luds/ui/blocks/autofill';
import { setupFormControl } from '@luds/ui/blocks/form-field';
import { injectElementRef, setupInteractions } from '@luds/ui/blocks/internal';
import { injectSearchState } from '@luds/ui/blocks/search';
import { LudsControlStatus, uniqueId } from '@luds/ui/blocks/utils';
import { inputState, provideInputState } from './input-state';

/**
 * Variantes disponíveis de input que determinam o estilo visual.
 */
export type LudsInputVariant =
  | 'default'
  | 'white';
/**
 * Aplique a diretiva `ludsInput` a campos de entrada para criar inputs estilizados e acessíveis.
 * Esta diretiva fornece recursos consistentes de estilo, gerenciamento de estado, integração com formulários e acessibilidade.
 * Permite a personalização de variantes visuais, controle de estado e integração opcional com campos de busca.
 */
@Directive({
  selector: 'input[ludsInput]',
  exportAs: 'ludsInput',
  providers: [provideInputState()],
  hostDirectives: [LudsAutofill],
  host: {
    '[attr.id]': 'id()',
    '[attr.disabled]': 'status().disabled ? "" : null',
    '[attr.data-variant]': 'variant()',
    'placeholder': ''
  },
  standalone: true
})
export class LudsInput {
  /**
   * O id do input.
   */
  readonly id = input(uniqueId('luds-input'));

  /**
   * O estilo de variante do input.
   */
  public variant = input<LudsInputVariant>('default');

  /**
   * O input pode ser usado dentro de um campo de busca, se for o caso precisamos registrá-lo.
   */
  private readonly searchState = injectSearchState({ optional: true });

  /**
   * Acessa a referência do elemento.
   */
  private readonly elementRef = injectElementRef<HTMLInputElement>();

  /**
   * Indica se o elemento está desabilitado.
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    transform: booleanAttribute,
  });

    /**
   * O status do controle de formulário.
   */
  protected readonly status: Signal<LudsControlStatus>;

  /**
   * O estado do input.
   */
  protected readonly state = inputState<LudsInput>(this);

  constructor() {
    setupInteractions({
      hover: false,
      press: false,
      focus: true,
      disabled: this.state.disabled,
    });
    
    this.status = setupFormControl({ id: this.state.id, disabled: this.state.disabled });

    this.searchState()?.registerInput(this.elementRef.nativeElement);
  }
}