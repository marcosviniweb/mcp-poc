import {
    createState,
    createStateInjector,
    createStateProvider,
    createStateToken,
  } from '@luds/ui/blocks/state';
  import type { LudsInput } from './input';
  
  /**
   * The state token  for the Input primitive.
   */
  export const LudsInputStateToken = createStateToken<LudsInput>('Input');
  
  /**
   * Provides the Input state.
   */
  export const provideInputState = createStateProvider(LudsInputStateToken);
  
  /**
   * Injects the Input state.
   */
  export const injectInputState = createStateInjector<LudsInput>(LudsInputStateToken);
  
  /**
   * The Input state registration function.
   */
  export const inputState = createState(LudsInputStateToken);