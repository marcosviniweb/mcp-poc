import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { fireEvent, render } from '@testing-library/angular';
import userEvent from '@testing-library/user-event';
import { LudsFormField, LudsLabel } from '@luds/ui/blocks/form-field';
import { LudsInput } from './input';

describe('ludsInput', () => {
  it.skip('should not add the data-hover attribute on hover', async () => {
    const { getByTestId } = await render(`<input ludsInput data-testid="input" />`, {
      imports: [LudsInput],
    });

    const input = getByTestId('input');
    fireEvent.mouseEnter(input);
    expect(input).not.toHaveAttribute('data-hover');
    fireEvent.mouseLeave(input);
    expect(input).not.toHaveAttribute('data-hover');
  });

  it.skip('should not add the data-pressed attribute on press', async () => {
    const { getByTestId } = await render(`<input ludsInput data-testid="input" />`, {
      imports: [LudsInput],
    });
    const input = getByTestId('input');
    fireEvent.pointerDown(input);
    expect(input).not.toHaveAttribute('data-press');
    fireEvent.pointerUp(input);
    expect(input).not.toHaveAttribute('data-press');
  });

  it.skip('should add data attributes for form control status when ngModel is used', async () => {
    const { getByTestId } = await render(
      `<input ludsInput data-testid="input" [(ngModel)]="value" />`,
      {
        imports: [LudsInput, FormsModule],
        componentProperties: { value: '' },
      },
    );

    const input = getByTestId('input');
    expect(input).toHaveAttribute('data-valid');
    expect(input).not.toHaveAttribute('data-invalid');
    expect(input).toHaveAttribute('data-pristine');
    expect(input).not.toHaveAttribute('data-dirty');
    expect(input).not.toHaveAttribute('data-touched');

    fireEvent.focus(input);
    fireEvent.input(input, { target: { value: '' } });
    fireEvent.blur(input);

    expect(input).not.toHaveAttribute('data-pristine');
    expect(input).toHaveAttribute('data-dirty');
  });

  it.skip('should not allow text entering when disabled', async () => {
    const { getByTestId } = await render(`<input ludsInput data-testid="input" disabled="true" />`, {
      imports: [LudsInput],
    });

    const input = getByTestId('input');
    fireEvent.focus(input);
    userEvent.type(input, 'Hello World');
    expect(input).toHaveValue('');
  });

  it.skip('should set the id attribute', async () => {
    const { getByTestId } = await render(`<input ludsInput data-testid="input" />`, {
      imports: [LudsInput],
    });

    const input = getByTestId('input');
    expect(input).toHaveAttribute('id');
    expect(input.id).toMatch(/^ds-input-\d+$/);
  });

  it.skip('should allow th user to set a custom id', async () => {
    const customId = 'custom-input-id';
    const { getByTestId } = await render(
      `<input ludsInput id="${customId}" data-testid="input" />`,
      {
        imports: [LudsInput],
      },
    );

    const input = getByTestId('input');
    expect(input).toHaveAttribute('id', customId);
  });

  it.skip('should add the disabled attribute when disabled is true', async () => {
    const { getByTestId } = await render(`<input ludsInput data-testid="input" disabled />`, {
      imports: [LudsInput],
    });

    const input = getByTestId('input');
    expect(input).toHaveAttribute('disabled');
    expect(input).toBeDisabled();
  });

  it.skip('should connect the label with the input', async () => {
    const { getByTestId, detectChanges } = await render(
      `<div ludsFormField>
        <label ludsLabel id="label-id" data-testid="label">Custom Label</label>
        <input ludsInput data-testid="input" id="custom-id" />
      </div>`,
      {
        imports: [LudsInput, LudsFormField, LudsLabel],
      },
    );

    detectChanges();

    const input = getByTestId('input');
    const label = getByTestId('label');
    expect(label).toHaveAttribute('for', 'custom-id');
    expect(input).toHaveAttribute('id', 'custom-id');
    expect(input).toHaveAttribute('aria-labelledby', 'label-id');
  });

  it('should add the disabled attribute when the form control is disabled via ReactiveForms', async () => {
    const control = new FormControl('');
    
    const { getByTestId, detectChanges } = await render(
      `<input ludsInput data-testid="input" [formControl]="control" />`,
      {
        imports: [LudsInput, ReactiveFormsModule],
        componentProperties: {
          control
        },
      }
    );

    control.disable();
    detectChanges();

    const input = getByTestId('input');
    expect(input).toHaveAttribute('disabled');
    expect(input).toBeDisabled();
  });
});