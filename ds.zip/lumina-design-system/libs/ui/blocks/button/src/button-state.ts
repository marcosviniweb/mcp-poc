import { Signal } from '@angular/core';
import { syncState } from '@luds/ui/blocks/internal';
import {
  createState,
  createStateInjector,
  createStateProvider,
  createStateToken,
} from '@luds/ui/blocks/state';
import type { LudsButton } from './button';

/**
 * O token de estado para o componente Button.
 */
export const LudsButtonStateToken = createStateToken<LudsButton>('Button');

/**
 * Fornece o estado do Button.
 */
export const provideButtonState = createStateProvider(LudsButtonStateToken);

/**
 * Injeta o estado do Button.
 */
export const injectButtonState = createStateInjector<LudsButton>(LudsButtonStateToken);

/**
 * Função de registro de estado do Button.
 */
export const buttonState = createState(LudsButtonStateToken);

interface SyncButton {
  disabled: Signal<boolean>;
}

/**
 * Sincroniza o estado do botão com o estado do controle.
 * @param disabled O estado desabilitado do controle.
 */
export function syncButton({ disabled }: SyncButton) {
  const button = injectButtonState();
  syncState(disabled, button().disabled);
}