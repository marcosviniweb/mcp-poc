import { BooleanInput } from '@angular/cdk/coercion';
import {
  booleanAttribute,
  Directive,
  HOST_TAG_NAME,
  inject,
  input,
} from '@angular/core';
import { setupButton } from '@luds/ui/blocks/internal';
import { buttonState, provideButtonState } from './button-state';

/**
 * Variantes de botão disponíveis que determinam o estilo visual e a hierarquia.
 */
export type LudsButtonVariant = 'primary' | 'secondary' | 'tertiary';

/**
 * Tamanhos de botão disponíveis que controlam o espaçamento interno (padding) e o tamanho da fonte.
 */
export type LudsButtonSize = 'default' | 'small';

/**
 * Tipos de botões disponíveis que definem se o botão é um botão convencional ou um botão apenas com ícone
 */
export type LudsButtonType = 'button' | 'icon-button';

/**
 * Aplique a diretiva `ludsButton` a botões ou links para criar botões interativos estilizados.
 * Esta diretiva fornece recursos consistentes de estilo, gerenciamento de estado e acessibilidade.
 */
@Directive({
  selector: 'a[ludsButton], button[ludsButton]',
  exportAs: 'ludsButton',
  providers: [provideButtonState()],
  host: {
    '[attr.data-disabled]': 'state.disabled() ? "" : null',
    '[attr.disabled]': 'isButton && state.disabled() ? true : null',
    '[attr.data-variant]': 'variant()',
    '[attr.data-size]': 'size()',
    '[attr.data-type]': 'buttonType()',
  },
  standalone: true,
})
export class LudsButton {
  /**
   * Obtém o nome da tag do elemento.
   */
  private readonly tagName = inject(HOST_TAG_NAME);

  /**
   * Indica se o botão está desabilitado.
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    transform: booleanAttribute,
  });

  /**
   * Detecta se este é um elemento HTML button.
   */
  protected readonly isButton = this.tagName.toLowerCase() === 'button';

  /**
   * O estado do botão.
   */
  protected readonly state = buttonState<LudsButton>(this);

  /**
   * O estilo de variante do botão.
   */
  public variant = input<LudsButtonVariant>('primary');

  /**
   * O tamanho do botão.
   */
  public size = input<LudsButtonSize>('default');

  /**
   * O tipo do botão.
   */
  public buttonType = input<LudsButtonType>('button');

  /**
   * @internal
   */
  constructor() {
    setupButton({ disabled: this.state.disabled });
  }
}
