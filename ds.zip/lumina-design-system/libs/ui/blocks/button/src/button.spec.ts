import { Component } from "@angular/core";
import { render, screen } from "@testing-library/angular";
import { describe, it, expect } from "vitest";
import { LudsButton, LudsButtonSize, LudsButtonType, LudsButtonVariant } from "./button";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorArrowsClockwise } from "@ng-icons/phosphor-icons/regular";

function generateButtonWrapperComponent(
  variant: LudsButtonVariant = "primary",
  size: LudsButtonSize = "default",
  type: LudsButtonType = "button",
) {
  @Component({
    selector: "app-button-wrapper",
    imports: [LudsButton, NgIcon],
    providers: [provideIcons({ phosphorArrowsClockwise })],
    template: `<a ludsButton [variant]="${variant}" [size]="${size}" [type]="${type}">
      <ng-icon name="phosphorArrowsClockwise"></ng-icon>
    </a>`,
    standalone: true,
  })
  class TestButtonWrapperComponent {}

  return TestButtonWrapperComponent;
}

describe.skip("LudsButton Directive", () => {
  /* Tests related to icon-only button */
  it("should have padding-vertical of 12px (0.75rem) and padding-horizontal 0 when type is icon-button and size default", async () => {
    const component = generateButtonWrapperComponent("primary", "default", "icon-button");
    await render(component);

    const button = screen.getByRole("button");
    const computedStyles = window.getComputedStyle(button);

    expect(computedStyles.paddingTop).toBe("0.75rem");
    expect(computedStyles.paddingBottom).toBe("0.75rem");
    expect(computedStyles.paddingLeft).toBe("0");
    expect(computedStyles.paddingRight).toBe("0");
  });

  it("should have padding-vertical of 12px (0.75rem) and padding-horizontal 0 when type is icon-button and size small", async () => {
    const component = generateButtonWrapperComponent("primary", "small", "icon-button");
    await render(component);

    const button = screen.getByRole("button");
    const computedStyles = window.getComputedStyle(button);

    expect(computedStyles.paddingTop).toBe("0.75rem");
    expect(computedStyles.paddingBottom).toBe("0.75rem");
    expect(computedStyles.paddingLeft).toBe("0");
    expect(computedStyles.paddingRight).toBe("0");
  });

  it("should have width and height of 48px (3rem) when type is icon-button and size default", async () => {
    const component = generateButtonWrapperComponent("primary", "default", "icon-button");
    await render(component);

    const button = screen.getByRole("button");
    const computedStyles = window.getComputedStyle(button);

    expect(computedStyles.width).toBe("3rem");
    expect(computedStyles.height).toBe("3rem");
  });

  it("should have width and height of 36px (2.25rem) when type is icon-button and size default", async () => {
    const component = generateButtonWrapperComponent("primary", "small", "icon-button");
    await render(component);

    const button = screen.getByRole("button");
    const computedStyles = window.getComputedStyle(button);

    expect(computedStyles.width).toBe("2.25rem");
    expect(computedStyles.height).toBe("2.25rem");
  });
});
