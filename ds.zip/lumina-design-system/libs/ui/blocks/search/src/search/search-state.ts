import {
    createState,
    createStateInjector,
    createStateProvider,
    createStateToken,
  } from '@luds/ui/blocks/state';
  import type { LudsSearch } from './search';
  
  /**
   * The state token  for the Search primitive.
   */
  export const LudsSearchStateToken = createStateToken<LudsSearch>('Search');
  
  /**
   * Provides the Search state.
   */
  export const provideSearchState = createStateProvider(LudsSearchStateToken);
  
  /**
   * Injects the Search state.
   */
  export const injectSearchState = createStateInjector<LudsSearch>(LudsSearchStateToken);
  
  /**
   * The Search state registration function.
   */
  export const searchState = createState(LudsSearchStateToken);