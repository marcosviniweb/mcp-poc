import { BooleanInput } from '@angular/cdk/coercion';
import {
  Directive,
  HostListener,
  booleanAttribute,
  input,
  output,
} from '@angular/core';
import { setupFormControl } from '@luds/ui/blocks/form-field';
import { setupInteractions } from '@luds/ui/blocks/internal';
import { uniqueId } from '@luds/ui/blocks/utils';
import { checkboxState, provideCheckboxState } from './checkbox-state';

/**
 * `LudsCheckbox` é uma diretiva para aplicar comportamento de checkbox a elementos HTML,
 * com suporte a ReactiveForms, estados visuais e integração com formulários complexos.
 */
@Directive({
  selector: '[ludsCheckbox]',
  providers: [provideCheckboxState()],
  host: {
    role: 'checkbox',
    '[attr.aria-checked]': 'state.indeterminate() ? "mixed" : state.checked()',
    '[attr.data-checked]': 'state.checked() ? "" : null',
    '[attr.data-indeterminate]': 'state.indeterminate() ? "" : null',
    '[attr.aria-disabled]': 'state.disabled()',
    '[tabindex]': 'state.disabled() ? -1 : 0',
  },
  standalone: true,
})
export class LudsCheckbox {
  /**
   * O ID  do Checkbox.
   * @internal
   */
  readonly id = input(uniqueId('luds-checkbox'));

  /**
   * Define se o Checkbox está marcado.
   */
  readonly checked = input<boolean, BooleanInput>(false, {
    alias: 'ludsCheckboxChecked',
    transform: booleanAttribute,
  });

  /**
   * Evento emitido quando o valor do Checkbox é alterado.
   */
  readonly checkedChange = output<boolean>({
    alias: 'ludsCheckboxCheckedChange',
  });

  /**
   * Define se o Checkbox está com valor indeterminado.
   */
  readonly indeterminate = input<boolean, BooleanInput>(false, {
    alias: 'ludsCheckboxIndeterminate',
    transform: booleanAttribute,
  });

  /**
   * Evento emitido quando o valor de indeterminado é alterado.
   */
  readonly indeterminateChange = output<boolean>({
    alias: 'ludsCheckboxIndeterminateChange',
  });

  /**
   * Indica se o Checkbox é obrigatório.
   */
  readonly required = input<boolean, BooleanInput>(false, {
    alias: 'ludsCheckboxRequired',
    transform: booleanAttribute,
  });

  /**
   * Define se o Checkbox está desabilitado.
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsCheckboxDisabled',
    transform: booleanAttribute,
  });

  /**
   * O estado do Checkbox.
   */
  protected readonly state = checkboxState<LudsCheckbox>(this);

  /**
   * @internal
   */
  constructor() {
    setupFormControl({ id: this.state.id, disabled: this.state.disabled });
    setupInteractions({
      hover: true,
      press: true,
      focusVisible: true,
      disabled: this.state.disabled,
    });
  }

  /**
   * @internal
   */
  @HostListener('keydown.enter', ['$event'])
  protected onEnter(event: KeyboardEvent): void {
    // de acordo com as diretrizes  WAI-ARIA, caixas de seleção não são ativadas pela tecla Enter
    event.preventDefault();
  }

  /**
   * @internal
   */
  @HostListener('click', ['$event'])
  @HostListener('keydown.space', ['$event'])
  toggle(event?: Event): void {
    if (this.state.disabled()) {
      return;
    }

    // evita que seja acionado duas vezes nos casos em que o rótulo é clicado
    // e a caixa de seleção é ativada pelo mesmo evento
    event?.preventDefault();

    const checked = this.state.indeterminate() ? true : !this.state.checked();
    this.state.checked.set(checked);
    this.checkedChange.emit(checked);

    // se o Checkbox estava com valor indeterminado, agora não está mais.
    if (this.state.indeterminate()) {
      this.state.indeterminate.set(false);
      this.indeterminateChange.emit(false);
    }
  }
}
