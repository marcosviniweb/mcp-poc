import { Directive } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { ChangeFn, provideValueAccessor, TouchedFn } from '@luds/ui/blocks/utils';
import { injectCheckboxState } from './checkbox-state';

@Directive({
  selector: '[ludsCheckbox][formControlName],[ludsCheckbox][formControl],[ludsCheckbox][ngModel]',
  standalone: true,
  providers: [provideValueAccessor(LudsCheckboxValueAccessor)],
})

export class LudsCheckboxValueAccessor implements ControlValueAccessor {
  /**
   * The checked state of the checkbox.
   */
  protected readonly state = injectCheckboxState();

  /**
   * The onChange function for the checkbox.
   */
  protected onChangeFn?: ChangeFn<boolean>;

  /**
   * The onTouched function for the checkbox.
   */
  protected onTouchedFn?: TouchedFn;

  constructor() {
    // Whenever the user interacts with the checkbox, call the onChange function with the new value.
    this.state().checkedChange.subscribe(checked => this.onChangeFn?.(checked));
  }

  writeValue(checked: boolean): void {
    this.state().checked.set(checked);
  }

  registerOnChange(fn: ChangeFn<boolean>): void {
    this.onChangeFn = fn;
  }

  registerOnTouched(fn: TouchedFn): void {
    this.onTouchedFn = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.state().disabled.set(isDisabled);
  }
}