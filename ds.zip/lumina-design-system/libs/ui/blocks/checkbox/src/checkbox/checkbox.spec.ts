import { RenderResult, fireEvent, render } from '@testing-library/angular';
import { LudsCheckbox } from './checkbox';
import { describe, it, expect, vi, beforeEach } from 'vitest';

describe('LudsCheckbox', () => {
  let container: RenderResult<unknown, unknown>;
  let checkbox: HTMLElement;
  let checkedChange: ReturnType<typeof vi.fn>;
  let indeterminateChange: ReturnType<typeof vi.fn>;

  beforeEach(async () => {
    checkedChange = vi.fn();
    indeterminateChange = vi.fn();

    container = await render(
      `<div
        ludsCheckbox
        [(ludsCheckboxChecked)]="checked"
        [ludsCheckboxIndeterminate]="indeterminate"
        (ludsCheckboxCheckedChange)="checkedChange($event)"
        (ludsCheckboxIndeterminateChange)="indeterminateChange($event)"
        [ludsCheckboxDisabled]="disabled">
      </div>`,
      {
        imports: [LudsCheckbox],
        componentProperties: {
          checked: false,
          indeterminate: false,
          disabled: false,
          checkedChange,
          indeterminateChange,
        },
      },
    );

    checkbox = container.getByRole('checkbox');
  });

  describe('checkbox', () => {
    it.skip('should have a role of checkbox', () => {
      expect(checkbox.getAttribute('role')).toBe('checkbox');
    });

    it.skip('should have a tabindex of 0', () => {
      expect(checkbox.getAttribute('tabindex')).toBe('0');
    });

    it.skip('should set the tabindex to -1 when disabled', async () => {
      await container.rerender({ componentProperties: { disabled: true } });
      expect(checkbox.getAttribute('tabindex')).toBe('-1');
    });

    it.skip('should set the aria-checked attribute to "false" when unchecked', () => {
      expect(checkbox.getAttribute('aria-checked')).toBe('false');
    });

    it.skip('should set the aria-checked attribute to "true" when checked', async () => {
      await container.rerender({ componentProperties: { checked: true } });
      expect(checkbox.getAttribute('aria-checked')).toBe('true');
    });

    it.skip('should set the aria-checked attribute to "mixed" when indeterminate', async () => {
      await container.rerender({ componentProperties: { checked: true, indeterminate: true } });
      expect(checkbox.getAttribute('aria-checked')).toBe('mixed');
    });

    it.skip('should set the data-checked attribute when checked', async () => {
      await container.rerender({ componentProperties: { checked: true } });
      expect(checkbox.getAttribute('data-checked')).toBe('');
    });

    it.skip('should remove the data-checked attribute when unchecked', () => {
      expect(checkbox.getAttribute('data-checked')).toBeNull();
    });

    it.skip('should set the data-indeterminate when indeterminate', async () => {
      await container.rerender({ componentProperties: { indeterminate: true } });
      expect(checkbox.getAttribute('data-indeterminate')).toBe('');
    });

    it.skip('should remove the data-checked attribute when unchecked', () => {
      expect(checkbox.getAttribute('data-checked')).toBeNull();
    });

    it.skip('should set the data-disabled when disabled', async () => {
      await container.rerender({ componentProperties: { disabled: true } });
      expect(checkbox.getAttribute('data-disabled')).toBe('');
    });

    it.skip('should emit the checkedChange event when clicked', () => {
      fireEvent.click(container.getByRole('checkbox'));
      expect(checkedChange).toHaveBeenCalledWith(true);
    });

    it.skip('should not emit the checkedChange event when clicked and disabled', async () => {
      await container.rerender({ componentProperties: { disabled: true, checkedChange } });
      fireEvent.click(container.getByRole('checkbox'));
      expect(checkedChange).not.toHaveBeenCalled();
    });

    it.skip('should emit the checkedChange event when the space key is pressed', () => {
      fireEvent.keyDown(container.getByRole('checkbox'), { key: ' ' });
      expect(checkedChange).toHaveBeenCalledWith(true);
    });

    it.skip('should not emit the checkedChange event when the space key is pressed and disabled', async () => {
      await container.rerender({ componentProperties: { disabled: true } });
      fireEvent.keyDown(container.getByRole('checkbox'), { key: ' ' });
      expect(checkedChange).not.toHaveBeenCalled();
    });

    it.skip('should mark as checked when an indeterminate checkbox is clicked', async () => {
      await container.rerender({
        componentProperties: { indeterminate: true, checkedChange, indeterminateChange },
      });
      fireEvent.click(container.getByRole('checkbox'));
      expect(checkedChange).toHaveBeenCalledWith(true);
      expect(indeterminateChange).toHaveBeenCalledWith(false);
    });
  });
});
