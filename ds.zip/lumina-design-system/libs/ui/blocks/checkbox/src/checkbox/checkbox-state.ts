import {
  createState,
  createStateInjector,
  createStateProvider,
  createStateToken,
} from '@luds/ui/blocks/state';
import type { LudsCheckbox } from './checkbox';

/**
 * O token de estado para o componente primitivo de Checkbox.
 */
export const LudsCheckboxStateToken = createStateToken<LudsCheckbox>('Checkbox');

/**
 * Fornece o estado do Checkbox.
 */
export const provideCheckboxState = createStateProvider(LudsCheckboxStateToken);

/**
 * Injeta o estado do Checkbox.
 */
export const injectCheckboxState = createStateInjector<LudsCheckbox>(LudsCheckboxStateToken);

/**
 * Função de registro de estado do Checkbox.
 */
export const checkboxState = createState(LudsCheckboxStateToken);
