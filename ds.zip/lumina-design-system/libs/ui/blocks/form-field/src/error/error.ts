import { Directive, OnChanges, OnDestroy, SimpleChanges, computed, input } from '@angular/core';
import { onBooleanChange, uniqueId } from '@luds/ui/blocks/utils';
import { injectFormFieldState } from '../form-field/form-field-state';

/**
 * A diretiva `ludsError` é usada para marcar um elemento de mensagem de erro dentro de um campo de formulário. 
 * Pode haver múltiplas mensagens de erro associadas a um controle de formulário.
 */
@Directive({
  selector: '[ludsError]',
  exportAs: 'ludsError',
  host: {
    '[attr.id]': 'id()',
    '[attr.data-invalid]': 'formField()?.invalid() ? "" : null',
    '[attr.data-valid]': 'formField()?.valid() ? "" : null',
    '[attr.data-touched]': 'formField()?.touched() ? "" : null',
    '[attr.data-pristine]': 'formField()?.pristine() ? "" : null',
    '[attr.data-dirty]': 'formField()?.dirty() ? "" : null',
    '[attr.data-pending]': 'formField()?.pending() ? "" : null',
    '[attr.data-disabled]': 'formField()?.disabled() ? "" : null',
    '[attr.data-validator]': 'state()',
  },
  standalone: true
})
export class LudsError implements OnChanges, OnDestroy {
  /**
   * Acessa o campo de formulário ao qual a descrição está associada.
   */
  protected readonly formField = injectFormFieldState({ optional: true });

  /**
   * O id da mensagem de erro. Se não for fornecido, um id único será gerado.
   */
  readonly id = input<string>(uniqueId('luds-error'));

  /**
   * O validador associado à mensagem de erro.
   */
  readonly validator = input<string | null>(null, {
    alias: 'ludsErrorValidator',
  });

  /**
   * Determina se existe uma mensagem de erro.
   */
  protected readonly hasError = computed(() => {
    const errors = this.formField()?.errors() ?? [];
    const validator = this.validator();

    return validator ? errors?.includes(validator) : errors?.length > 0;
  });

  /**
   * Determina se o validador associado a este erro está falhando.
   */
  protected readonly state = computed(() => (this.hasError() ? 'fail' : 'pass'));

  constructor() {
    // adiciona ou remove a mensagem de erro quando o estado de erro muda
    onBooleanChange(
      this.hasError,
      () => this.formField()?.addDescription(this.id()),
      () => this.formField()?.removeDescription(this.id()),
    );
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('id' in changes) {
      this.formField()?.removeDescription(changes['id'].previousValue);
    }
  }

  ngOnDestroy(): void {
    this.formField()?.removeDescription(this.id());
  }
}