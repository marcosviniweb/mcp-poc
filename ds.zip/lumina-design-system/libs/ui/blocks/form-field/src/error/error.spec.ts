import { render } from '@testing-library/angular';
import { LudsError } from './error';

describe('LudsError', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsError></div>`, {
      imports: [LudsError],
    });
  });
});