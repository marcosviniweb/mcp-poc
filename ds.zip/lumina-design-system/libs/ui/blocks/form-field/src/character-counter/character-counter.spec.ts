import { render, screen } from '@testing-library/angular';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { Component } from '@angular/core';
import { LudsCharacterCounter } from './character-counter';
import { LudsFormField } from '../form-field/form-field';

describe('LudsCharacterCounter', () => {
  it('should create basic character counter', async () => {
    const { container } = await render(`<div ludsCharacterCounter data-testid="counter"></div>`, {
      imports: [LudsCharacterCounter],
    });

    const counter = container.querySelector('[data-testid="counter"]');
    expect(counter).toBeTruthy();
    expect(counter?.hasAttribute('id')).toBe(true);
    expect(counter?.getAttribute('id')).toMatch(/^luds-character-counter-\d+$/);
  });

  it('should work with form control and detect maxLength from validator', async () => {
    @Component({
      template: `
        <div ludsFormField>
          <textarea [formControl]="formControl" ludsCharacterCounter data-testid="counter"></textarea>
        </div>
      `
    })
    class TestComponent {
      formControl = new FormControl('', [Validators.maxLength(100)]);
    }

    await render(TestComponent, {
      imports: [LudsCharacterCounter, LudsFormField, ReactiveFormsModule],
    });

    const counter = screen.getByTestId('counter');
    expect(counter).toBeTruthy();
  });

  it('should work with input and detect maxLength from attribute', async () => {
    @Component({
      template: `
        <div ludsFormField>
          <input [formControl]="formControl" ludsCharacterCounter maxlength="50" data-testid="counter" />
        </div>
      `
    })
    class TestComponent {
      formControl = new FormControl('initial value');
    }

    await render(TestComponent, {
      imports: [LudsCharacterCounter, LudsFormField, ReactiveFormsModule],
    });

    const counter = screen.getByTestId('counter');
    expect(counter).toBeTruthy();
    expect(counter.getAttribute('maxlength')).toBe('50');
  });

  it('should work within form field container', async () => {
    @Component({
      template: `
        <div ludsFormField>
          <input [formControl]="formControl" />
          <div ludsCharacterCounter data-testid="counter"></div>
        </div>
      `
    })
    class TestComponent {
      formControl = new FormControl('test', [Validators.maxLength(20)]);
    }

    await render(TestComponent, {
      imports: [LudsCharacterCounter, LudsFormField, ReactiveFormsModule],
    });

    const counter = screen.getByTestId('counter');
    expect(counter).toBeTruthy();
  });

  it('should handle null form control values gracefully', async () => {
    @Component({
      template: `
        <div ludsFormField>
          <textarea [formControl]="formControl" ludsCharacterCounter data-testid="counter"></textarea>
        </div>
      `
    })
    class TestComponent {
      formControl = new FormControl(null);
    }

    await render(TestComponent, {
      imports: [LudsCharacterCounter, LudsFormField, ReactiveFormsModule],
    });

    const counter = screen.getByTestId('counter');
    expect(counter).toBeTruthy();
  });

  it('should work with standalone character counter outside form field', async () => {
    const { container } = await render(`<span ludsCharacterCounter data-testid="counter"></span>`, {
      imports: [LudsCharacterCounter],
    });

    const counter = container.querySelector('[data-testid="counter"]');
    expect(counter).toBeTruthy();
    expect(counter?.getAttribute('id')).toMatch(/^luds-character-counter-\d+$/);
  });

  it('should handle invalid maxlength attribute gracefully', async () => {
    @Component({
      template: `
        <input ludsCharacterCounter maxlength="invalid" data-testid="counter" />
      `
    })
    class TestComponent {}

    await render(TestComponent, {
      imports: [LudsCharacterCounter],
    });

    const counter = screen.getByTestId('counter');
    expect(counter).toBeTruthy();
    expect(counter.getAttribute('maxlength')).toBe('invalid');
  });

  it('should detect input element when directive is on input', async () => {
    @Component({
      template: `
        <input [formControl]="formControl" ludsCharacterCounter maxlength="25" data-testid="input" />
      `
    })
    class TestComponent {
      formControl = new FormControl('test');
    }

    await render(TestComponent, {
      imports: [LudsCharacterCounter, ReactiveFormsModule],
    });

    const input = screen.getByTestId('input');
    expect(input.tagName).toBe('INPUT');
    expect(input.getAttribute('maxlength')).toBe('25');
  });

  it('should detect textarea element when directive is on textarea', async () => {
    @Component({
      template: `
        <textarea [formControl]="formControl" ludsCharacterCounter data-testid="textarea"></textarea>
      `
    })
    class TestComponent {
      formControl = new FormControl('', [Validators.maxLength(200)]);
    }

    await render(TestComponent, {
      imports: [LudsCharacterCounter, ReactiveFormsModule],
    });

    const textarea = screen.getByTestId('textarea');
    expect(textarea.tagName).toBe('TEXTAREA');
  });
});