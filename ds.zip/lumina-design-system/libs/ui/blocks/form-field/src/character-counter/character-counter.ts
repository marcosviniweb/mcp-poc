import { computed, Directive, effect, input, signal, DestroyRef, inject, ElementRef } from "@angular/core";
import { type AbstractControl } from "@angular/forms";
import { uniqueId, safeTakeUntilDestroyed } from "@luds/ui/blocks/utils";
import { injectFormFieldState } from "../form-field/form-field-state";

/**
 * A diretiva `ludsCharacterCounter` é usado para exibir um contador de caracteres dentro de um campo de formulário.
 */
@Directive({
  selector: "[ludsCharacterCounter]",
  exportAs: "ludsCharacterCounter",
  standalone: true,
  host: {
    "[attr.id]": "id()",
    "[attr.data-invalid]": "formField()?.invalid() ? '' : null",
    "[attr.data-valid]": "formField()?.valid() ? '' : null",
    "[attr.data-touched]": "formField()?.touched() ? '' : null",
    "[attr.data-pristine]": "formField()?.pristine() ? '' : null",
    "[attr.data-dirty]": "formField()?.dirty() ? '' : null",
    "[attr.data-pending]": "formField()?.pending() ? '' : null",
    "[attr.data-disabled]": "formField()?.disabled() ? '' : null",
  },
})
export class LudsCharacterCounter {
  private readonly elementRef = inject(ElementRef);
  private readonly destroyRef = inject(DestroyRef);

  /**
   * O id do contador. Se não for fornecido, um id único será gerado.
   */
  readonly id = input<string>(uniqueId("luds-character-counter"));

  /**
   * Acessa o campo de formulário ao qual o contador está associado.
   */
  protected readonly formField = injectFormFieldState({ optional: true });

  /**
   * Signal reativo para o valor do control
   */
  private readonly controlValue = signal<string>("");

  /**
   * Conta atual de caracteres baseada no valor do form control.
   */
  readonly currentCount = computed(() => this.controlValue().length);

  /**
   * Comprimento máximo permitido do input
   */
  readonly maxLength = computed(() => {
    const control = this.formField()?.ngControl()?.control;
    if (!control) return 0;

    // Tenta obter dos validators do FormControl
    const fromValidators = this.getMaxLengthFromValidators(control);
    if (fromValidators > 0) return fromValidators;

    // Fallback: atributo nativo maxlength
    const fromNative = this.getNativeMaxLength();
    if (fromNative > 0) return fromNative;

    return 0;
  });

  constructor() {
    // Registra o contador como descrição do campo
    effect(
      (onCleanup) => {
        this.formField()?.addDescription(this.id());
        onCleanup(() => this.formField()?.removeDescription(this.id()));
      },
      { allowSignalWrites: true },
    );

    // Configura a escuta reativa do valor do control
    effect(
      () => {
        const ngControl = this.formField()?.ngControl();

        if (ngControl?.control) {
          // Define o valor inicial
          this.controlValue.set(ngControl.control.value || "");

          // Escuta mudanças no valor
          ngControl.control.valueChanges.pipe(safeTakeUntilDestroyed(this.destroyRef)).subscribe((value) => {
            this.controlValue.set(value || "");
          });
        }
      },
      { allowSignalWrites: true },
    );
  }

  /**
   * Extrai o valor maxLength dos validators do FormControl
   */
  private getMaxLengthFromValidators(control: AbstractControl): number {
    if (!control.validator) return 0;

    // Testa o validator com um valor longo para detectar maxlength
    const testValue = "x".repeat(10000);
    const testControl = {
      value: testValue,
      errors: null,
      valid: false,
      invalid: true
    } as AbstractControl;

    try {
      const result = control.validator(testControl);
      return result?.["maxlength"]?.requiredLength || 0;
    } catch {
      return 0;
    }
  }

  /**
   * Obtém o valor do atributo nativo maxlength do input
   */
  private getNativeMaxLength(): number {
    try {
      const inputElement = this.findInputElement();
      if (inputElement?.hasAttribute("maxlength")) {
        return parseInt(inputElement.getAttribute("maxlength") || "0", 10);
      }
    } catch {
      // Ignora erros
    }
    return 0;
  }

  /**
   * Encontra o elemento input/textarea associado
   */
  private findInputElement(): HTMLInputElement | HTMLTextAreaElement | null {
    const element = this.elementRef.nativeElement;

    // Se o próprio elemento é um input/textarea
    if (element.tagName === "INPUT" || element.tagName === "TEXTAREA") {
      return element;
    }

    // Busca por input/textarea dentro do form field
    return element.querySelector("input, textarea");
  }
}
