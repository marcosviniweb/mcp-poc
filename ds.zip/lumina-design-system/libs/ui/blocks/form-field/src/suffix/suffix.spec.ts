import { render } from '@testing-library/angular';
import { LudsFormFieldSuffix } from './suffix';

describe('LudsLabel', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsFormFieldSuffix></div>`, {
      imports: [LudsFormFieldSuffix],
    });
  });
});