import { Directive, ElementRef, inject, afterNextRender } from '@angular/core';
import { injectStyleInjector } from '@luds/ui/blocks/internal';
import { uniqueId } from '@luds/ui/blocks/utils';
/**
 * A diretiva `ludsFormFieldSuffix` é usada para marcar um elemento como sufixo dentro de um campo de formulário.
 */
@Directive({
    selector: '[ludsFormFieldSuffix]',
    exportAs: 'ludsFormFieldSuffix',
    standalone: true,
})
export class LudsFormFieldSuffix {
    private readonly elementRef = inject(ElementRef<HTMLElement>);
    private readonly styleInjector = injectStyleInjector();
    private readonly styleId = uniqueId('luds-form-field-suffix');

    constructor() {
        afterNextRender(() => {
            const width = this.elementRef.nativeElement.offsetWidth;
            const formFieldElement = this.findFormFieldElement();

            if (width > 0 && formFieldElement) {
                if (!formFieldElement.id) {
                    formFieldElement.id = uniqueId('luds-form-field');
                }

                const style = `
                @layer component {
                    :host,
                    :root {
                        #${formFieldElement.id} {
                            --luds-form-field-suffix-target-width: calc(${width}px + var(--luds-input-padding-right));
                        }
                    }
                }`;

                this.styleInjector.add(this.styleId, style);
            }
        });
    }

    private findFormFieldElement(): HTMLElement | null {
        let current = this.elementRef.nativeElement.parentElement;

        while (current) {
            if (current.hasAttribute('ludsFormField')) {
                return current;
            }
            current = current.parentElement;
        }

        return null;
    }
} 