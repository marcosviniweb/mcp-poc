import { render } from '@testing-library/angular';
import { LudsDescription } from './description';

describe('LudsDescription', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsDescription></div>`, {
      imports: [LudsDescription],
    });
  });
});