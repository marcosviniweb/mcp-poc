import { Directive, effect, input } from '@angular/core';
import { uniqueId } from '@luds/ui/blocks/utils';
import { injectFormFieldState } from '../form-field/form-field-state';

/**
 * A diretiva `ludsDescription` é usada para marcar um elemento de descrição dentro de um campo de formulário. Pode haver múltiplas descrições associadas a um controle de formulário.
 */
@Directive({
  selector: '[ludsDescription]',
  exportAs: 'ludsDescription',
  host: {
    '[attr.id]': 'id()',
    '[attr.data-invalid]': 'formField()?.invalid() ? "" : null',
    '[attr.data-valid]': 'formField()?.valid() ? "" : null',
    '[attr.data-touched]': 'formField()?.touched() ? "" : null',
    '[attr.data-pristine]': 'formField()?.pristine() ? "" : null',
    '[attr.data-dirty]': 'formField()?.dirty() ? "" : null',
    '[attr.data-pending]': 'formField()?.pending() ? "" : null',
    '[attr.data-disabled]': 'formField()?.disabled() ? "" : null',
  },
  standalone: true
})
export class LudsDescription {
  /**
   * O id da descrição. Se não for fornecido, um id único será gerado.
   */
  readonly id = input<string>(uniqueId('luds-description'));
  /**
   * Acessa o campo de formulário ao qual a descrição está associada.
   */
  protected readonly formField = injectFormFieldState({ optional: true });

  constructor() {
    effect(onCleanup => {
      this.formField()?.addDescription(this.id());
      onCleanup(() => this.formField()?.removeDescription(this.id()));
    }, { allowSignalWrites: true });
  }
}