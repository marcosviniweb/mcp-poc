import { render } from '@testing-library/angular';
import { LudsRule } from './rule';

describe('LudsRule', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsRule></div>`, {
      imports: [LudsRule],
    });
  });
});