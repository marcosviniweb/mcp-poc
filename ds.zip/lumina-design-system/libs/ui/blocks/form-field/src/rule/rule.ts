import { Directive, OnChanges, OnDestroy, SimpleChanges, computed, input } from '@angular/core';
import { onBooleanChange, uniqueId } from '@luds/ui/blocks/utils';
import { injectFormFieldState } from '../form-field/form-field-state';

/**
 * A diretiva `ludsRule` é usada para marcar um elemento de regra de validação dentro de um campo de formulário. 
 * Pode haver múltiplas regras de validação associadas a um controle de formulário.
 * A regra pode estar em estado de falha (erro) ou sucesso, dependendo do estado de validação do campo.
 */
@Directive({
  selector: '[ludsRule]',
  exportAs: 'ludsRule',
  host: {
    '[attr.id]': 'id()',
    '[attr.data-invalid]': 'formField()?.invalid() ? "" : null',
    '[attr.data-valid]': 'formField()?.valid() ? "" : null',
    '[attr.data-touched]': 'formField()?.touched() ? "" : null',
    '[attr.data-pristine]': 'formField()?.pristine() ? "" : null',
    '[attr.data-dirty]': 'formField()?.dirty() ? "" : null',
    '[attr.data-pending]': 'formField()?.pending() ? "" : null',
    '[attr.data-disabled]': 'formField()?.disabled() ? "" : null',
    '[attr.data-validator]': 'state()',
  },
  standalone: true
})
export class LudsRule implements OnChanges, OnDestroy {
  /**
   * Acessa o campo de formulário ao qual a regra de validação está associada.
   */
  protected readonly formField = injectFormFieldState({ optional: true });

  /**
   * O id da regra de validação. Se não for fornecido, um id único será gerado.
   */
  readonly id = input<string>(uniqueId('luds-rule'));

  /**
   * O validador específico associado à regra. Se não especificado, a regra reagirá a qualquer erro do campo.
   */
  readonly validator = input<string | null>(null, {
    alias: 'ludsRuleValidator',
  });

  /**
   * Determina se a regra de validação está em estado de erro.
   * Retorna true se o validador específico está falhando ou se há qualquer erro no campo (quando validator não é especificado).
   */
  protected readonly hasError = computed(() => {
    const errors = this.formField()?.errors() ?? [];
    const validator = this.validator();

    return validator ? errors?.includes(validator) : errors?.length > 0;
  });

  /**
   * Determina o estado atual da regra de validação.
   * Retorna 'fail' quando há erro ou 'pass' quando a validação está bem-sucedida.
   */
  protected readonly state = computed(() => (this.hasError() ? 'fail' : 'pass'));

  constructor() {
    // adiciona ou remove a regra como descrição do campo quando o estado de erro muda
    onBooleanChange(
      this.hasError,
      () => this.formField()?.addDescription(this.id()),
      () => this.formField()?.removeDescription(this.id()),
    );
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('id' in changes) {
      this.formField()?.removeDescription(changes['id'].previousValue);
    }
  }

  ngOnDestroy(): void {
    this.formField()?.removeDescription(this.id());
  }
}