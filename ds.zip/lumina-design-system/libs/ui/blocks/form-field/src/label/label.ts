import {
  computed,
  Directive,
  effect,
  ElementRef,
  HostListener,
  inject,
  input,
} from '@angular/core';
import { uniqueId } from '@luds/ui/blocks/utils';
import { injectFormFieldState } from '../form-field/form-field-state';

/**
 * A diretiva `ludsLabel` é usada para marcar um elemento label dentro de um campo de formulário. Preferencialmente, deve-se usar um elemento HTML `<label>`.
 */
@Directive({
  selector: '[ludsLabel]',
  exportAs: 'ludsLabel',
  host: {
    '[attr.id]': 'id()',
    '[attr.for]': 'htmlFor()',
    '[attr.data-invalid]': 'formField()?.invalid() ? "" : null',
    '[attr.data-valid]': 'formField()?.valid() ? "" : null',
    '[attr.data-touched]': 'formField()?.touched() ? "" : null',
    '[attr.data-pristine]': 'formField()?.pristine() ? "" : null',
    '[attr.data-dirty]': 'formField()?.dirty() ? "" : null',
    '[attr.data-pending]': 'formField()?.pending() ? "" : null',
    '[attr.data-disabled]': 'formField()?.disabled() ? "" : null',
  },
  standalone: true,
})
export class LudsLabel {
  /**
   * O id do label. Se não for fornecido, um id único será gerado.
   */
  readonly id = input<string>(uniqueId('luds-label'));
  /**
   * Acessa o campo de formulário ao qual o label está associado.
   */
  protected readonly formField = injectFormFieldState({ optional: true });
  /**
   * Obtém o valor do atributo for se o label for um elemento HTML label.
   */
  protected readonly htmlFor = computed(() => this.formField()?.formControl());
  /**
   * Acessa o elemento ao qual o label está associado.
   */
  private readonly elementRef = inject<ElementRef<HTMLElement>>(ElementRef);
  /**
   * Determina se o label é um elemento HTML label.
   */
  protected readonly isLabel =
    this.elementRef.nativeElement instanceof HTMLLabelElement;

  constructor() {
    effect(
      (onCleanup) => {
        this.formField()?.addLabel(this.id());
        onCleanup(() => this.formField()?.removeLabel(this.id()));
      },
      { allowSignalWrites: true }
    );
  }

  @HostListener('click', ['$event'])
  protected onClick(event: MouseEvent): void {
    // by default a label will perform a click on the associated form control, however
    // this only works if the associated form control is an input element which may not always
    // be the case, so we prevent the default behavior and handle the click event ourselves.
    // This was inspired by the HeadlessUI approach:
    // https://github.com/tailwindlabs/headlessui/blob/main/packages/%40headlessui-react/src/components/label/label.tsx#L58
    if (this.isLabel) {
      event.preventDefault();
    }

    // to find the associated form control we can lookup via the known id
    const targetId = this.htmlFor();

    if (!targetId) {
      return;
    }

    const target = document.getElementById(targetId);

    if (!target) {
      return;
    }

    // if the target is disabled then do nothing
    const disabled = target.getAttribute('disabled');
    const ariaDisabled = target.getAttribute('aria-disabled');

    if (disabled === '' || disabled === 'true' || ariaDisabled === 'true') {
      return;
    }

    // radio buttons, checkboxes and switches should all be clicked immediately as they require state changes
    if (
      (target instanceof HTMLInputElement &&
        (target.type === 'radio' || target.type === 'checkbox')) ||
      target.role === 'radio' ||
      target.role === 'checkbox' ||
      target.role === 'switch'
    ) {
      target.click();
    }

    // Move focus to the element, this allows you to start using keyboard shortcuts since the
    // bound element is now focused.
    target.focus({ preventScroll: true });
  }
}
