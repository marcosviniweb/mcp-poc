import { render } from '@testing-library/angular';
import { LudsLabel } from './label';

describe('LudsLabel', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsLabel></div>`, {
      imports: [LudsLabel],
    });
  });
});