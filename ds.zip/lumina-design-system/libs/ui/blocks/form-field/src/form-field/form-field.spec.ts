import { render } from '@testing-library/angular';
import { LudsFormField } from './form-field';

describe('LudsFormField', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsFormField></div>`, {
      imports: [LudsFormField],
    });
  });
});