import {
    createState,
    createStateInjector,
    createStateProvider,
    createStateToken,
  } from '@luds/ui/blocks/state';
  import type { LudsFormField } from './form-field';
  
  /**
   * The state token  for the FormField primitive.
   */
  export const LudsFormFieldStateToken = createStateToken<LudsFormField>('FormField');
  
  /**
   * Provides the FormField state.
   */
  export const provideFormFieldState = createStateProvider(LudsFormFieldStateToken);
  
  /**
   * Injects the FormField state.
   */
  export const injectFormFieldState = createStateInjector<LudsFormField>(LudsFormFieldStateToken);
  
  /**
   * The FormField state registration function.
   */
  export const formFieldState = createState(LudsFormFieldStateToken);