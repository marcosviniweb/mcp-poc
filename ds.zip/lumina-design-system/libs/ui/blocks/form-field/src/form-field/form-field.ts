import { Directive, OnDestroy, contentChild, signal } from '@angular/core';
import { NgControl } from '@angular/forms';
import { onChange } from '@luds/ui/blocks/utils';
import { Subscription } from 'rxjs';
import { formFieldState, provideFormFieldState } from './form-field-state';

/**
 * A diretiva `ludsFormField` é um contêiner para elementos de campo de formulário. Quaisquer labels, controles de formulário ou descrições devem ser colocados dentro desta diretiva.
 */
@Directive({
  selector: '[ludsFormField]',
  exportAs: 'ludsFormField',
  providers: [provideFormFieldState()],
  host: {
    '[attr.data-invalid]': 'invalid() ? "" : null',
    '[attr.data-valid]': 'valid() ? "" : null',
    '[attr.data-touched]': 'touched() ? "" : null',
    '[attr.data-pristine]': 'pristine() ? "" : null',
    '[attr.data-dirty]': 'dirty() ? "" : null',
    '[attr.data-pending]': 'pending() ? "" : null',
    '[attr.data-disabled]': 'disabled() ? "" : null',
  },
  standalone: true
})
export class LudsFormField implements OnDestroy {
  /**
   * Armazena o(s) label(s) do formulário.
   * @internal
   */
  readonly labels = signal<string[]>([]);

  /**
   * Armazena as descrições do formulário.
   * @internal
   */
  readonly descriptions = signal<string[]>([]);

  /**
   * Armazena o id do controle de formulário associado.
   * @internal
   */
  readonly formControl = signal<string | null>(null);

  /**
   * Encontra qualquer NgControl dentro do campo de formulário.
   * @internal
   */
  readonly ngControl = contentChild(NgControl);

  /**
   * Armazena as mensagens de erro de validação.
   * @internal
   */
  readonly errors = signal<string[]>([]);

  /**
   * Indica se o controle está pristine (não modificado).
   * @internal
   */
  readonly pristine = signal<boolean | null>(null);

  /**
   * Indica se o controle foi tocado.
   * @internal
   */
  readonly touched = signal<boolean | null>(null);

  /**
   * Indica se o controle está dirty (modificado).
   * @internal
   */
  readonly dirty = signal<boolean | null>(null);

  /**
   * Indica se o controle é válido.
   */
  readonly valid = signal<boolean | null>(null);

  /**
   * Indica se o controle é inválido.
   * @internal
   */
  readonly invalid = signal<boolean | null>(null);

  /**
   * Indica se o controle está pendente.
   * @internal
   */
  readonly pending = signal<boolean | null>(null);

  /**
   * Indica se o controle está desabilitado.
   * @internal
   */
  readonly disabled = signal<boolean | null>(null);

  /**
   * Armazena a assinatura de status atual.
   */
  private subscription?: Subscription;

  /**
   * O estado do campo de formulário.
   */
  protected readonly state = formFieldState<LudsFormField>(this);

  constructor() {
    // sempre que o ngControl mudar, configura as assinaturas.
    onChange(this.ngControl, this.setupSubscriptions.bind(this));
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

  /**
   * Configura um listener para o status do controle de formulário.
   * @param control
   */
  private setupSubscriptions(control: NgControl | null | undefined): void {
    // Cancela a inscrição das assinaturas anteriores.
    this.subscription?.unsubscribe();

    // Define os valores iniciais
    this.updateStatus();

    const underlyingControl = control?.control;

    // Escuta as mudanças do controle de formulário.
    this.subscription = underlyingControl?.events?.subscribe(this.updateStatus.bind(this));
  }

  private updateStatus(): void {
    const control = this.ngControl();

    if (!control) {
      return;
    }

    this.pristine.set(control.pristine);
    this.touched.set(control.touched);
    this.dirty.set(control.dirty);
    this.valid.set(control.valid);
    this.invalid.set(control.invalid);
    this.pending.set(control.pending);
    this.disabled.set(control.disabled);
    this.errors.set(control?.errors ? Object.keys(control.errors) : []);
  }

  /**
   * Registra o id do controle de formulário associado.
   * @param id
   * @internal
   */
  setFormControl(id: string): void {
    this.formControl.set(id);
  }

  /**
   * Registra um label no campo de formulário.
   * @param label
   * @internal
   */
  addLabel(label: string): void {
    this.labels.update(labels => [...labels, label]);
  }

  /**
   * Registra uma descrição no campo de formulário.
   * @param description
   * @internal
   */
  addDescription(description: string): void {
    this.descriptions.update(descriptions => [...descriptions, description]);
  }

  /**
   * Remove o controle de formulário associado.
   * @internal
   */
  removeFormControl(): void {
    this.formControl.set(null);
  }

  /**
   * Remove um label do campo de formulário.
   * @param label
   * @internal
   */
  removeLabel(label: string): void {
    this.labels.update(labels => labels.filter(l => l !== label));
  }

  /**
   * Remove uma descrição do campo de formulário.
   * @param description
   * @internal
   */
  removeDescription(description: string): void {
    this.descriptions.update(descriptions => descriptions.filter(d => d !== description));
  }
}