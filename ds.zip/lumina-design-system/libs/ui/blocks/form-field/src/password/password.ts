
import {
  Directive,
  ElementRef,
  HostListener,
  OnInit,
  contentChild,
  contentChildren,
  effect,
  inject,
  input,
  signal,
} from '@angular/core';
import { uniqueId } from '@luds/ui/blocks/utils';
import { LudsFormControl } from '..';

/**
 * Interface para elementos de visibilidade da senha
 */
export interface PasswordVisibilityElement {
  /** Se o elemento é mostrado quando a senha está visível */
  isPasswordVisible: boolean;
  /** Se o elemento está atualmente sendo mostrado */
  isShown: boolean;
}

/**
 * Diretiva para elementos mostrados quando a senha está visível
 */
@Directive({
  selector: '[ludsPasswordVisible]',
  exportAs: 'ludsPasswordVisible',
  standalone: true,
  host: {
    '[style.display]': 'isShown ? "inline-flex" : "none"',
  },
})
export class LudsPasswordVisible implements PasswordVisibilityElement {
  isPasswordVisible = true;
  isShown = false;
}

/**
 * Diretiva para elementos mostrados quando a senha está oculta
 */
@Directive({
  selector: '[ludsPasswordHidden]',
  exportAs: 'ludsPasswordHidden',
  standalone: true,
  host: {
    '[style.display]': 'isShown ? "inline-flex" : "none"',
  },
})
export class LudsPasswordHidden implements PasswordVisibilityElement {
  isPasswordVisible = false;
  isShown = true;
}

/**
 * Diretiva de alternância de senha para mostrar/ocultar o campo de entrada de senha
 */
@Directive({
  selector: '[ludsPasswordToggle]',
  exportAs: 'ludsPasswordToggle',
  standalone: true,
  host: {
    '[attr.id]': 'id()',
    '[attr.type]': '"button"',
    '[attr.aria-label]': '"Toggle password visibility"',
    '[attr.data-showing]': 'isPasswordVisible() ? "" : null',
    '[attr.disabled]': 'isInputDisabled() ? "" : null',
  },
  providers: [],
})
export class LudsPasswordToggle implements OnInit {
  /** ID único para o elemento de alternância */
  readonly id = input<string>(uniqueId('luds-password-toggle'));

  /** Se a senha está atualmente visível */
  readonly isPasswordVisible = signal<boolean>(false);

  /** Se o campo de entrada está desativado */
  readonly isInputDisabled = signal<boolean>(false);

  /** Referência ao controle de formulário no campo do formulário */
  private readonly formControl = contentChild(LudsFormControl);

  /** Elementos para mostrar quando a senha está visível */
  private readonly visibleElements = contentChildren(LudsPasswordVisible);

  /** Elementos para mostrar quando a senha está oculta */
  private readonly hiddenElements = contentChildren(LudsPasswordHidden);

  /** Referência ao elemento para acesso ao DOM */
  private readonly elementRef = inject(ElementRef);

  constructor() {
    // Configura um efeito para atualizar a visibilidade sempre que isPasswordVisible muda
    effect(
      () => {
        this.updateChildElementsVisibility(this.isPasswordVisible());
      },
      {
        allowSignalWrites: true,
      }
    );

    // Verifica o status de desativação do campo na inicialização e atualiza o estado
    effect(
      () => {
        const input = this.getPasswordInput();
        if (input) {
          this.isInputDisabled.set(input.disabled);
        }
      },
      {
        allowSignalWrites: true,
      }
    );
  }

  /**
   * Inicializa a alternância de senha
   */
  ngOnInit(): void {
    const input = this.getPasswordInput();
    if (input) {
      input.type = 'password';
      this.isInputDisabled.set(input.disabled);
    }
  }

  /**
   * Alterna a visibilidade da senha ao clicar
   */
  @HostListener('click')
  togglePassword(): void {
    const input = this.getPasswordInput();
    if (input && !input.disabled) {
      input.type = input.type === 'password' ? 'text' : 'password';
      this.isPasswordVisible.set(input.type === 'text');
    }
  }

  /**
   * Obtém o campo de entrada de senha para controlar
   */
  private getPasswordInput(): HTMLInputElement | null {
    if (this.formControl()) {
      const controlElement = this.formControl() as unknown as {
        id: () => string;
      };
      if (controlElement?.id) {
        const inputId = controlElement.id();
        const input = document.getElementById(inputId) as HTMLInputElement;
        if (input?.tagName === 'INPUT') {
          return input;
        }
      }
    }

    const toggleElement = this.elementRef.nativeElement;
    if (toggleElement) {
      const formField = toggleElement.closest('[ludsFormField]');
      if (formField) {
        const input = formField.querySelector('input') as HTMLInputElement;
        if (input) {
          return input;
        }
      }
    }

    return null;
  }

  /**
   * Atualiza o estado de visibilidade dos elementos filhos
   */
  private updateChildElementsVisibility(isVisible: boolean): void {
    this.visibleElements().forEach((element) => {
      element.isShown = isVisible;
    });

    this.hiddenElements().forEach((element) => {
      element.isShown = !isVisible;
    });
  }
}
