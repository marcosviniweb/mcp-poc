import { render } from '@testing-library/angular';
import { LudsFormFieldPrefix } from './prefix';

describe('LudsLabel', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsFormFieldPrefix></div>`, {
      imports: [LudsFormFieldPrefix],
    });
  });
});