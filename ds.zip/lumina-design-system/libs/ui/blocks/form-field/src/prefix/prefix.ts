import { Directive, ElementRef, inject, afterNextRender } from '@angular/core';
import { injectStyleInjector } from '@luds/ui/blocks/internal';
import { uniqueId } from '@luds/ui/blocks/utils';
/**
 * A diretiva `ludsFormFieldPrefix` é usada para marcar um elemento como prefixo dentro de um campo de formulário.
 */
@Directive({
    selector: '[ludsFormFieldPrefix]',
    exportAs: 'ludsFormFieldPrefix',
    standalone: true,
})
export class LudsFormFieldPrefix {
    private readonly elementRef = inject(ElementRef<HTMLElement>);
    private readonly styleInjector = injectStyleInjector();
    private readonly styleId = uniqueId('luds-form-field-prefix');

    constructor() {
        afterNextRender(() => {
            const width = this.elementRef.nativeElement.offsetWidth;
            const formFieldElement = this.findFormFieldElement();

            if (width > 0 && formFieldElement) {
                if (!formFieldElement.id) {
                    formFieldElement.id = uniqueId('luds-form-field');
                }

                const style = `
                @layer component {
                    :host,
                    :root {
                        #${formFieldElement.id} {
                            --luds-form-field-prefix-target-width: calc(${width}px + var(--luds-input-padding-left));
                        }
                    }
                }`;

                this.styleInjector.add(this.styleId, style);
            }
        });
    }

    private findFormFieldElement(): HTMLElement | null {
        let current = this.elementRef.nativeElement.parentElement;

        while (current) {
            if (current.hasAttribute('ludsFormField')) {
                return current;
            }
            current = current.parentElement;
        }

        return null;
    }
} 