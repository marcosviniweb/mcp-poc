import { render } from '@testing-library/angular';
import { LudsFormControl } from './form-control';

describe('LudsFormControl', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsFormControl></div>`, {
      imports: [LudsFormControl],
    });
  });
});