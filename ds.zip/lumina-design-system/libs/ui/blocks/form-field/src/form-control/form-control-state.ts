import {
    createState,
    createStateInjector,
    createStateProvider,
    createStateToken,
  } from '@luds/ui/blocks/state';
  import type { LudsFormControl } from './form-control';
  
  /**
   * The state token  for the FormControl primitive.
   */
  export const LudsFormControlStateToken = createStateToken<LudsFormControl>('FormControl');
  
  /**
   * Provides the FormControl state.
   */
  export const provideFormControlState = createStateProvider(LudsFormControlStateToken);
  
  /**
   * Injects the FormControl state.
   */
  export const injectFormControlState = createStateInjector<LudsFormControl>(LudsFormControlStateToken);
  
  /**
   * The FormControl state registration function.
   */
  export const formControlState = createState(LudsFormControlStateToken);