import { Component } from '@angular/core';
import { render } from '@testing-library/angular';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { LudsBadge, LudsBadgeSize, LudsBadgeVariant } from './badge';

function generateBadgeWrapperComponent(
  variant: LudsBadgeVariant = 'magenta',
  size: LudsBadgeSize = 'default'
) {
  @Component({
    selector: 'app-badge-wrapper',
    imports: [LudsBadge],
    template: `<span
      ludsBadge
      [variant]="variant"
      [size]="size"
      >Badge Text</span
    >`,
    standalone: true,
  })
  class TestBadgeWrapperComponent {
    variant = variant;
    size = size;
  }
  return TestBadgeWrapperComponent;
}

describe('LudsBadge Directive', () => {
  beforeEach(() => {
    vi.spyOn(console, 'warn').mockImplementation(() => {});
  });

  describe('Attribute bindings', () => {
    it('should set data-variant attribute according to the variant input', async () => {
      const component = generateBadgeWrapperComponent('success', 'default');
      const { container } = await render(component);
      const badge = container.querySelector('[ludsBadge]');

      expect(badge).toHaveAttribute('data-variant', 'success');
    });

    it('should set data-size attribute according to the size input', async () => {
      const component = generateBadgeWrapperComponent('magenta', 'small');
      const { container } = await render(component);
      const badge = container.querySelector('[ludsBadge]');

      expect(badge).toHaveAttribute('data-size', 'small');
    });

    it('should have tabindex attribute set to 0', async () => {
      const component = generateBadgeWrapperComponent();
      const { container } = await render(component);
      const badge = container.querySelector('[ludsBadge]');

      expect(badge).toHaveAttribute('tabindex', '0');
    });
  });

  describe('Content behavior', () => {
    it('should keep content when size is default', async () => {
      const component = generateBadgeWrapperComponent('magenta', 'default');
      const { container } = await render(component);
      const badge = container.querySelector('[ludsBadge]');

      expect(badge?.textContent).toBe('Badge Text');
    });

    it('should remove content when size is small', async () => {
      const component = generateBadgeWrapperComponent('magenta', 'small');
      const { container } = await render(component);
      const badge = container.querySelector('[ludsBadge]');

      expect(badge?.textContent).toBe('');
    });

    it('should remove content when size is dot', async () => {
      const component = generateBadgeWrapperComponent('magenta', 'dot');
      const { container } = await render(component);
      const badge = container.querySelector('[ludsBadge]');

      expect(badge?.textContent).toBe('');
    });
  });

  describe('Dynamic changes', () => {
    it('should update data-variant when variant changes', async () => {
      const { container, rerender } = await render(
        `<div ludsBadge [variant]="variant" [size]="size">Badge</div>`,
        {
          imports: [LudsBadge],
          componentProperties: {
            variant: 'magenta' as LudsBadgeVariant,
            size: 'default' as LudsBadgeSize,
          },
        }
      );

      const badge = container.querySelector('[ludsBadge]');
      expect(badge).toHaveAttribute('data-variant', 'magenta');

      await rerender({
        componentProperties: { variant: 'success', size: 'default' },
      });
      expect(badge).toHaveAttribute('data-variant', 'success');
    });

    it('should update data-size when size changes', async () => {
      const { container, rerender } = await render(
        `<div ludsBadge [variant]="variant" [size]="size">Badge</div>`,
        {
          imports: [LudsBadge],
          componentProperties: {
            variant: 'magenta' as LudsBadgeVariant,
            size: 'default' as LudsBadgeSize,
          },
        }
      );

      const badge = container.querySelector('[ludsBadge]');
      expect(badge).toHaveAttribute('data-size', 'default');

      await rerender({
        componentProperties: { variant: 'magenta', size: 'small' },
      });
      expect(badge).toHaveAttribute('data-size', 'small');
    });

    it('should remove content when size changes to small', async () => {
      const { container, rerender } = await render(
        `<div ludsBadge [variant]="variant" [size]="size">Badge</div>`,
        {
          imports: [LudsBadge],
          componentProperties: {
            variant: 'magenta' as LudsBadgeVariant,
            size: 'default' as LudsBadgeSize,
          },
        }
      );

      const badge = container.querySelector('[ludsBadge]');
      expect(badge?.textContent).toBe('Badge');

      await rerender({
        componentProperties: { variant: 'magenta', size: 'small' },
      });
      expect(badge?.textContent).toBe('');
    });
  });
});
