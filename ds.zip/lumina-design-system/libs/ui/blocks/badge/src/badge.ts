import { Directive, ElementRef, inject, input } from '@angular/core';
import { setupInteractions } from '@luds/ui/blocks/internal';

/**
 * Variantes visuais disponíveis para o badge.
 */
export type LudsBadgeVariant =
  | 'magenta-dark'
  | 'magenta'
  | 'purple'
  | 'warning'
  | 'success'
  | 'info'
  | 'error';

/**
 * Tamanhos disponíveis para o badge.
 */
export type LudsBadgeSize = 'default' | 'small' | 'dot';

@Directive({
  selector: '[ludsBadge]',
  standalone: true,
  exportAs: 'ludsBadge',
  host: {
    '[attr.data-variant]': 'variant()',
    '[attr.data-size]': 'size()',
    '[attr.tabindex]': '0',
    '[attr.role]': '"status"'
  },
})
/**
 * A diretiva `ludsBadge` aplica estilos e comportamentos de badge a qualquer elemento.
 * Permite customizar variante visual e tamanho, além de garantir acessibilidade.
 */
export class LudsBadge {
  /**
   * Variante visual do badge.
   */
  public readonly variant = input<LudsBadgeVariant>('magenta');

  /**
   * Tamanho do badge.
   */
  public readonly size = input<LudsBadgeSize>('default');

  /**
   * Referência ao elemento host.
   */
  private readonly el = inject(ElementRef);

  ngAfterViewInit() {
    this.hideContentIfNeeded();
  }

  ngOnChanges() {
    this.hideContentIfNeeded();
  }

  /**
   * Esconde o conteúdo do badge caso o tamanho seja 'small' ou 'dot'.
   */
  private hideContentIfNeeded() {
    const element = this.el.nativeElement;
    if (this.size() === 'small' || this.size() === 'dot') {
      while (element.firstChild) {
        element.removeChild(element.firstChild);
      }
    }
  }


  /**
   * @internal
   */
  constructor() {
    setupInteractions({
      focusVisible: true,
    });
  }
}
