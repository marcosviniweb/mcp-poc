# @luds/ui/blocks/common

Secondary entry point of `@luds/ui`. It can be used by importing from `@luds/ui/blocks/common`.
