export type LudsOrientation = 'horizontal' | 'vertical';
