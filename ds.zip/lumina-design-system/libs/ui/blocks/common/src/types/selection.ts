export type LudsSelectionMode = 'single' | 'multiple';
