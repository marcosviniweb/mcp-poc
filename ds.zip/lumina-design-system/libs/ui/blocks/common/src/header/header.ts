import { Directive, input } from '@angular/core';
import { uniqueId } from '@luds/ui/blocks/utils';
import { LudsHeaderToken } from './header-token';

@Directive({
  selector: '[ludsHeader]',
  exportAs: 'ludsHeader',
  providers: [{ provide: LudsHeaderToken, useExisting: LudsHeader }],
  host: {
    role: 'presentation',
    '[attr.id]': 'id()',
  },
})
export class LudsHeader {
  /**
   * O ID do cabeçalho.
   */
  readonly id = input(uniqueId('luds-header'));
}
