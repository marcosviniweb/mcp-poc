import { InjectionToken, inject } from '@angular/core';
import type { LudsHeader } from './header';

export const LudsHeaderToken = new InjectionToken<LudsHeader>('LudsHeaderToken');

/**
 * Injeta a instância da diretiva Header.
 */
export function injectHeader(): LudsHeader {
  return inject(LudsHeaderToken);
}
