import { Directive, input } from '@angular/core';

/**
 * Tamanhos disponíveis para o loader spinner, controlando seu diâmetro e proporção visual.
 */
export type LudsLoaderSpinnerSize = 'large' | 'default' | 'small';

/**
 * Variantes de cor disponíveis para o loader spinner.
 */
export type LudsLoaderSpinnerVariant = 'positive' | 'negative';

/**
 * Aplique a diretiva `ludsLoaderSpinner` para exibir um indicador de carregamento animado.
 * Esta diretiva permite customizar tamanho e variante do spinner para diferentes contextos de uso.
 */
@Directive({
  selector: '[ludsLoaderSpinner]',
  exportAs: 'ludsLoaderSpinner',
  host: {
    '[attr.data-variant]': 'variant()',
    '[attr.data-size]': 'size()',
    '[attr.role]': '"status"',
  },
  standalone: true,
})
export class LudsLoaderSpinner {
  /**
   * Variante de cor do loader spinner.
   */
  public variant = input<LudsLoaderSpinnerVariant>('positive');

  /**
   * Tamanho do loader spinner.
   */
  public size = input<LudsLoaderSpinnerSize>('default');
}
