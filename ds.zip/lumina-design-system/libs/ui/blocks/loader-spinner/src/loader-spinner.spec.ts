
import { Component } from '@angular/core';
import { render, screen } from '@testing-library/angular';
import { describe, it, expect } from 'vitest';
import { LudsLoaderSpinner, LudsLoaderSpinnerSize, LudsLoaderSpinnerVariant } from './loader-spinner';

function generateLoaderSpinnerWrapperComponent(
  variant: LudsLoaderSpinnerVariant = 'positive',
  size: LudsLoaderSpinnerSize = 'default'
) {
  @Component({
    selector: 'app-loader-spinner-wrapper',
    imports: [LudsLoaderSpinner],
    template: `<div ludsLoaderSpinner [variant]="'${variant}'" [size]="'${size}'"></div>`,
    standalone: true
  })
  class TestLoaderSpinnerWrapperComponent {}

  return TestLoaderSpinnerWrapperComponent;
}

describe('LudsLoaderSpinner Directive', () => {
  it('should render with default attributes', async () => {
    const component = generateLoaderSpinnerWrapperComponent();
    await render(component);

    const spinner = screen.getByRole('status');
    expect(spinner).toBeTruthy();
    expect(spinner.getAttribute('data-variant')).toBe('positive');
    expect(spinner.getAttribute('data-size')).toBe('default');
  });

  it('should render with variant negative', async () => {
    const component = generateLoaderSpinnerWrapperComponent('negative');
    await render(component);

    const spinner = screen.getByRole('status');
    expect(spinner.getAttribute('data-variant')).toBe('negative');
  });

  it('should render with size large', async () => {
    const component = generateLoaderSpinnerWrapperComponent('positive', 'large');
    await render(component);

    const spinner = screen.getByRole('status');
    expect(spinner.getAttribute('data-size')).toBe('large');
  });

  it('should render with size small', async () => {
    const component = generateLoaderSpinnerWrapperComponent('positive', 'small');
    await render(component);

    const spinner = screen.getByRole('status');
    expect(spinner.getAttribute('data-size')).toBe('small');
  });
});
