import { render } from "@testing-library/angular";
import { LudsFooter } from "./footer";

describe('LudsFooter', () => {
  it('should create an instance', async () => {
    const { getByTestId } = await render(`<footer ludsFooter data-testid="footer">
        <p class="luds-note-medium-default">© Serasa Experian | nome do produto</p>
        <div ludsFooterLinks>
            <a class="luds-note-medium-link" href="">Termos de uso</a>
            <a class="luds-note-medium-link" href="">Central de ajuda</a>
        </div>
      </footer>`, {
        imports: [LudsFooter],
    });
    const footer = getByTestId('footer');
    expect(footer).toBeTruthy();
  });
})