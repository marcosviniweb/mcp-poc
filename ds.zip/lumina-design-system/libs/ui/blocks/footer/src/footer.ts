import { Directive } from '@angular/core';

/**
 * Diretiva `ludsFooter` é utilizada para criar componentes de rodapé padronizados.
 * 
 * O footer é responsável por exibir informações de copyright, links de termos de uso e suporte.
 * É responsivo, adaptando-se automaticamente a diferentes tamanhos de tela.
 * 
 */
@Directive({
  selector: '[ludsFooter]',
  standalone: true,
  exportAs: 'ludsFooter',
})
export class LudsFooter {
}
