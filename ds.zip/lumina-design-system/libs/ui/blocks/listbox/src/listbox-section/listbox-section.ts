import { contentChild, Directive } from '@angular/core';
import { LudsHeaderToken } from '@luds/ui/blocks/common';

@Directive({
  selector: '[ludsListboxSection]',
  exportAs: 'ludsListboxSection',
  host: {
    role: 'group',
    '[attr.aria-labelledby]': 'header()?.id()',
  },
  standalone: true,
})
export class LudsListboxSection {
  /**
   * Accessa o cabeçalho da seção, se existir.
   */
  protected readonly header = contentChild(LudsHeaderToken, { descendants: true });
}
