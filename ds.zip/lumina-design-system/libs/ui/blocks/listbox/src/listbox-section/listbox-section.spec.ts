import { render } from '@testing-library/angular';
import { LudsListboxSection } from './listbox-section';

describe('LudsListboxSection', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsListboxSection></div>`, {
      imports: [LudsListboxSection],
    });
  });
});
