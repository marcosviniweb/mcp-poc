import { Directive } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { ChangeFn, provideValueAccessor, TouchedFn } from '@luds/ui/blocks/utils';
import { injectListboxState } from './listbox-state';
import { LudsListbox } from './listbox';

@Directive({
  selector: '[ludsListbox][formControlName],[ludsListbox][formControl],[ludsListbox][ngModel]',
  standalone: true,
  providers: [provideValueAccessor(LudsListboxValueAccessor)],
})

export class LudsListboxValueAccessor implements ControlValueAccessor {
  /**
   * Access the listbox state
   */
  protected readonly state = injectListboxState<LudsListbox<string>>();

  /**
   * The onChange callback.
   */
  protected onChange?: ChangeFn<string[]>;

  /**
   * The onTouch callback.
   */
  protected onTouch?: TouchedFn;

  writeValue(value: string[]): void {
    this.state()?.value.set(value);
  }

  registerOnChange(fn: ChangeFn<string[]>): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: TouchedFn): void {
    this.onTouch = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.state()?.disabled.set(isDisabled);
  }
}