import { ActiveDescendantKeyManager, FocusOrigin } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import {
  AfterContentInit,
  booleanAttribute,
  computed,
  DestroyRef,
  Directive,
  HostListener,
  inject,
  Injector,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { LudsSelectionMode } from '@luds/ui/blocks/common';
import { explicitEffect, setupFocusVisible } from '@luds/ui/blocks/internal';
import { injectPopoverTriggerState } from '@luds/ui/blocks/popover';
import { uniqueId } from '@luds/ui/blocks/utils';
import type { LudsListboxOption } from '../listbox-option/listbox-option';
import { listboxState, provideListboxState } from './listbox-state';

/**
 * Aplique a diretiva `ludsListbox` a containers para criar componentes de seleção interativos e acessíveis, com suporte a seleção única ou múltipla.
 *
 * A navegação por teclado é integrada, e o listbox pode ser acionado por elementos como `input`, `button` ou outros gatilhos personalizados.
 * Também é compatível com `popovers`, permitindo composições flexíveis como autocompletes, menus suspensos e outros padrões de interface.
 */
@Directive({
  selector: '[ludsListbox]',
  exportAs: 'ludsListbox',
  providers: [provideListboxState()],
  host: {
    '[id]': 'state.id()',
    role: 'listbox',
    '[attr.tabindex]': 'tabindex()',
    '[attr.aria-disabled]': 'state.disabled()',
    '[attr.aria-multiselectable]': 'state.mode() === "multiple"',
    '[attr.aria-activedescendant]': 'activeDescendant()',
    '(focusin)': 'isFocused.set(true)',
    '(focusout)': 'isFocused.set(false)',
  },
  standalone: true,
})
export class LudsListbox<T> implements AfterContentInit {
  /**
   * Accessa o injetor.
   */
  private readonly injector = inject(Injector);

  /**
   * Accessa a referência de destruição.
   */
  private readonly destroyRef = inject(DestroyRef);

  /**
   * O Listbox pode ser usado dentro de um Popover, que talvez queiramos fechar ao selecionar um item.
   */
  private readonly popoverTrigger = injectPopoverTriggerState({
    optional: true,
  });

  /**
   * O ID do Listbox.
   */
  readonly id = input(uniqueId('luds-listbox'));

  /**
   * O modo de seleção do Listbox.
   */
  readonly mode = input<LudsSelectionMode>('single', {
    alias: 'ludsListboxMode',
  });

  /**
   * A seleção do Listbox.
   */
  readonly value = input<T[]>([], {
    alias: 'ludsListboxValue',
  });

  /**
   * Emite um evento quando a seleção do Listbox é alterada.
   */
  readonly valueChange = output<T[]>({
    alias: 'ludsListboxValueChange',
  });

  /**
   * O estado desabilitado do Listbox.
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsListboxDisabled',
    transform: booleanAttribute,
  });

  /**
   * A função de comparação usada para comparar valores.
   * Se não for fornecida, será usada a igualdade estrita (===).
   */
  readonly compareWith = input<(a: T, b: T) => boolean>((a, b) => a === b, {
    alias: 'ludsListboxCompareWith',
  });

  /**
   * O tabindex do Listbox.
   */
  protected readonly tabindex = computed(() => {
    if (!this.state) return 0;
    return this.state.disabled() ? -1 : 0;
  });

  /**
   * Accessa as opções do Listbox.
   */
  protected readonly options = signal<LudsListboxOption<T>[]>([]);

  /**
   * O descendente ativo do Listbox.
   */
  protected readonly keyManager = new ActiveDescendantKeyManager(
    this.options,
    this.injector
  );

  /**
   * Obtém o descendente ativo do Listbox.
   */
  protected readonly activeDescendant = signal<string | undefined>(undefined);

  /**
   * @internal
   * Indica se o Listbox está em foco.
   */
  readonly isFocused = signal(false);

  /**
   * O estado do Listbox.
   */
  private readonly state = listboxState<LudsListbox<T>>(this);

  /**
   * @internal
   */
  constructor() {
    setupFocusVisible({ disabled: this.state.disabled });
  }

  /**
   * @internal
   */
  ngAfterContentInit(): void {
    this.keyManager.withHomeAndEnd().withTypeAhead().withVerticalOrientation();

    this.keyManager.change
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() =>
        this.activeDescendant.set(this.keyManager.activeItem?.id())
      );

    // Na inicialização, define a primeira opção selecionada como o descendente ativo, se houver uma.
    this.updateActiveItem();

    // Se as opções forem alteradas, atualize o item ativo — por exemplo, o item que estava ativo anteriormente pode ter sido removido.
    // Sempre que o valor for alterado, devemos garantir que o item ativo seja atualizado.
    explicitEffect([this.options], () => this.updateActiveItem(), {
      injector: this.injector,
    });
  }

  private updateActiveItem(): void {
    const selectedOption = this.options().find((o) => o.selected());

    if (selectedOption) {
      this.keyManager.setActiveItem(selectedOption);
    } else {
      this.keyManager.setFirstItemActive();
    }
  }

  /**
   * @internal
   */
  @HostListener('keydown', ['$event'])
  protected onKeydown(event: KeyboardEvent): void {
    this.keyManager.onKeydown(event);

    // Se a tecla pressionada for Enter ou Espaço, selecione o descendente ativo, se houver um.
    if (event.key === 'Enter' || event.key === ' ') {
      this.keyManager.activeItem?.select('keyboard');
    }

    // Se for uma tecla de seta ou de seleção, evite a ação padrão para impedir que a página role.
    if (
      event.key === 'ArrowDown' ||
      event.key === 'ArrowUp' ||
      event.key === 'Enter' ||
      event.key === ' '
    ) {
      event.preventDefault();
    }
  }

  /**
   * @internal
   * Seleciona uma opção no Listbox.
   */
  selectOption(value: T, origin: FocusOrigin): void {
    if (this.state.mode() === 'single') {
      const newValue = [value];
      this.state.value.set(newValue);
      this.valueChange.emit(newValue);
    } else {
      // Se o valor já estiver selecionado, remova-o; caso contrário, adicione-o.
      if (this.isSelected(value)) {
        const newValue = this.state
          .value()
          .filter((v) => !this.state.compareWith()(v, value));
        this.state.value.set(newValue);
        this.valueChange.emit(newValue);
      } else {
        const newValue = [...this.state.value(), value];
        this.state.value.set(newValue);
        this.valueChange.emit(newValue);
      }
    }

    // Define o descendente ativo como a opção selecionada.
    const option = this.options().find((o) =>
      this.state.compareWith()(o.value(), value)
    );

    if (option) {
      this.keyManager.setActiveItem(option);
    }

    // Se o Listbox estiver dentro de um Popover, feche o Popover ao selecionar uma opção, exceto se estiver no modo de seleção múltipla.
    if (this.state.mode() !== 'multiple') {
      this.popoverTrigger()?.hide(origin);
    }
  }

  /**
   * @internal
   * Determina se uma opção está selecionada usando a função compareWith.
   */
  isSelected(value: T): boolean {
    return this.state.value().some((v) => this.state.compareWith()(v, value));
  }

  /**
   * @internal
   * Ativa uma opção no Listbox.
   */
  activateOption(value: T) {
    const option = this.options().find((o) =>
      this.state.compareWith()(o.value(), value)
    );

    if (option) {
      this.keyManager.setActiveItem(option);
    }
  }

  /**
   * Registra uma opção no Listbox.
   * @internal
   */
  addOption(option: LudsListboxOption<T>): void {
    // Se a opção já existir, não a adicione novamente.
    if (!this.options().includes(option)) {
      this.options.update((options) => [...options, option]);
    }
  }

  /**
   * Remove o registro de uma opção no Listbox.
   * @internal
   */
  removeOption(option: LudsListboxOption<T>): void {
    this.options.update((options) => options.filter((o) => o !== option));
  }
}
