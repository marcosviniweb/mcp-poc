import {
  createState,
  createStateInjector,
  createStateProvider,
  createStateToken,
} from '@luds/ui/blocks/state';
import type { LudsListbox } from './listbox';

/**
 * O token de estado para o componente Listbox.
 */
export const LudsListboxStateToken = createStateToken<LudsListbox<unknown>>('Listbox');

/**
 * Fornece o estado do Listbox.
 */
export const provideListboxState = createStateProvider(LudsListboxStateToken);

/**
 * Injeta o estado do Listbox.
 */
export const injectListboxState = createStateInjector<LudsListbox<unknown>>(LudsListboxStateToken, {
  deferred: true,
});

/**
 * A função de registro de estado do Listbox.
 */
export const listboxState = createState(LudsListboxStateToken);
