import { render } from '@testing-library/angular';
import { LudsListbox } from './listbox';

describe('LudsListbox', () => {
  it('should initialise correctly', async () => {
    const container = await render(`<div ludsListbox></div>`, {
      imports: [LudsListbox],
    });
  });
});
