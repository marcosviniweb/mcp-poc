import { FocusOrigin } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import {
  booleanAttribute,
  computed,
  Directive,
  effect,
  input,
  OnDestroy,
  signal,
} from '@angular/core';
import {
  injectElementRef,
  onDomRemoval,
  scrollIntoViewIfNeeded,
  setupInteractions,
} from '@luds/ui/blocks/internal';
import { uniqueId } from '@luds/ui/blocks/utils';
import type { LudsListbox } from '../listbox/listbox';
import { injectListboxState } from '../listbox/listbox-state';

@Directive({
  selector: '[ludsListboxOption]',
  exportAs: 'ludsListboxOption',
  host: {
    role: 'option',
    '[attr.id]': 'id()',
    '[attr.aria-disabled]': 'optionDisabled()',
    '[attr.data-active]': 'listbox()?.isFocused() && active() ? "" : undefined',
    '[attr.data-selected]': 'selected() ? "" : undefined',
    '[attr.data-disabled]': 'optionDisabled() ? "" : undefined',
    '(click)': 'select("mouse")',
    '(mouseenter)': 'activate()',
    '(keydown.enter)': 'select("keyboard")',
    '(keydown.space)': 'select("keyboard")',
  },
  standalone: true,
})
export class LudsListboxOption<T> implements OnDestroy {
  protected readonly listbox = injectListboxState<LudsListbox<T>>();
  private readonly elementRef = injectElementRef();

  /**
   * O ID do Listbox.
   */
  readonly id = input(uniqueId('luds-listbox-option'));

  /**
   * O valor da opção.
   */
  readonly value = input.required<T>({
    alias: 'ludsListboxOptionValue',
  });

  /**
   * Indica se a opção está desabilitada.
   */
  readonly optionDisabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsListboxOptionDisabled',
    transform: booleanAttribute,
  });

  /**
   * Indica se a opção está ativa.
   */
  protected readonly active = signal<boolean>(false);

  /**
   * @internal
   * Indica se a opção está selecionada.
   */
  readonly selected = computed(() => this.listbox()?.isSelected(this.value()));

  /**
   * @internal
   * Indica se a opção está desabilitada - isso é utilizado pela interface 'HighLightable'.
   */
  get disabled(): boolean {
    return this._disabled();
  }

  /**
   * Indica se a opção está desabilitada.
   */
  protected readonly _disabled = computed(
    () => this.optionDisabled() || (this.listbox()?.disabled() ?? false)
  );

  constructor() {
    setupInteractions({
      hover: true,
      press: true,
      focusVisible: true,
      focus: true,
      disabled: this._disabled,
    });

    // O listbox pode não estar disponível quando a opção for inicializada,
    // portanto, precisamos adicionar a opção quando o Listbox estiver disponível.
    effect(() => this.listbox()?.addOption(this), { allowSignalWrites: true });

    // Sempre que o elemento for removido do DOM, precisamos remover a opção do Listbox
    // e também redefinir o estado ativo.
    onDomRemoval(this.elementRef.nativeElement, () => {
      this.listbox()?.removeOption(this);
      this.setInactiveStyles();
    });
  }

  ngOnDestroy(): void {
    this.listbox()?.removeOption(this);
  }

  /**
   * @internal
   * Define o estado ativo da opção.
   */
  setActiveStyles(): void {
    this.active.set(true);
    scrollIntoViewIfNeeded(this.elementRef.nativeElement);
  }

  /**
   * @internal
   * Define o estado inativo da opção.
   */
  setInactiveStyles(): void {
    this.active.set(false);
  }

  /**
   * @internal
   * Obtém o rótulo da opção, usado pela interface `Highlightable`.
   */
  getLabel(): string {
    return this.elementRef.nativeElement.textContent ?? '';
  }

  /**
   * @internal
   * Seleciona a opção.
   */
  select(origin: FocusOrigin): void {
    this.listbox()?.selectOption(this.value(), origin);
  }

  /**
   * @internal
   * Ativa as opções atuais.
   */
  activate(): void {
    if (this._disabled()) {
      return;
    }

    this.listbox()?.activateOption(this.value());
  }
}
