import { Directive, HostListener } from '@angular/core';
import { injectPopoverTriggerState, providePopoverConfig } from '@luds/ui/blocks/popover';

@Directive({
  selector: '[ludsListboxTrigger]',
  exportAs: 'ludsListboxTrigger',
  providers: [providePopoverConfig({
    offset: 0,
    flip: true,
    autoplacement: false,
    shift: false
  })],
  standalone: true,
})
export class LudsListboxTrigger {
  /**
   * Este elemento também deve estar associado a uma diretiva de disparo do Popover.
   */
  private readonly popoverTrigger = injectPopoverTriggerState();

  /**
   * Quando a tecla de seta para cima ou para baixo for pressionada, abre o Popover.
   */
  @HostListener('keydown', ['$event'])
  openPopover(event: KeyboardEvent) {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      this.popoverTrigger().show();
      event.preventDefault();
    }
  }
}
