import { createState, createStateInjector, createStateProvider, createStateToken, InjectedState } from "@luds/ui/blocks/state";
import { LudsRadioGroup } from "./radio-group";

/**
 * The state token  for the RadioGroup primitive.
 */
export const LudsRadioGroupStateToken = createStateToken<LudsRadioGroup<unknown>>('RadioGroup');

/**
 * Provides the RadioGroup state.
 */
export const provideRadioGroupState = createStateProvider(LudsRadioGroupStateToken);

/**
 * Injects the RadioGroup state.
 */
export const injectRadioGroupState = createStateInjector<LudsRadioGroup<unknown>>(
  LudsRadioGroupStateToken,
) as <T>() => InjectedState<LudsRadioGroup<T>>;

/**
 * The RadioGroup state registration function.
 */
export const radioGroupState = createState(LudsRadioGroupStateToken);