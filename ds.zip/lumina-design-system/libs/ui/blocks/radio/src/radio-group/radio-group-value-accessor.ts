import { Directive } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { ChangeFn, provideValueAccessor, TouchedFn } from '@luds/ui/blocks/utils';
import { injectRadioGroupState } from './radio-group-state';

@Directive({
  selector: '[ludsRadioGroup][formControlName],[ludsRadioGroup][formControl],[ludsRadioGroup][ngModel]',
  standalone: true,
  providers: [provideValueAccessor(LudsRadioGroupValueAccessor)],
})

export class LudsRadioGroupValueAccessor implements ControlValueAccessor {
/** Access the radio group state */
  protected readonly state = injectRadioGroupState<string>();

  /** The on change callback */
  private onChange?: ChangeFn<string | null>;

  /** The on touched callback */
  protected onTouched?: TouchedFn;

  constructor() {
    this.state().valueChange.subscribe(value => this.onChange?.(value));
  }

  /** Write a new value to the radio group */
  writeValue(value: string): void {
    this.state().value.set(value);
  }

  /** Register the on change callback */
  registerOnChange(onChange: ChangeFn<string | null>): void {
    this.onChange = onChange;
  }

  /** Register the on touched callback */
  registerOnTouched(onTouched: TouchedFn): void {
    this.onTouched = onTouched;
  }
}