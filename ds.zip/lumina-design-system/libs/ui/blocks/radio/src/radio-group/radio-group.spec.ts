import { render } from '@testing-library/angular';
import { LudsRadioGroup, LudsRadioItem } from '../index';
import { describe, it, expect, vi } from 'vitest';

describe('LudsRadioGroup', () => {
  it.skip('should set to horizontal orientation by default', async () => {
    const { getByRole } = await render(`
      <div ludsRadioGroup>
        <div ludsRadioItem ludsRadioItemValue="1">One</div>
        <div ludsRadioItem ludsRadioItemValue="2">Two</div>
      </div>
    `, {
      imports: [ludsRadioGroup, ludsRadioItem],
    });
    expect(getByRole('radiogroup')).toHaveAttribute('data-orientation', 'horizontal');
    expect(getByRole('radiogroup')).toHaveAttribute('aria-orientation', 'horizontal');
  });

  it.skip('should set to vertical orientation', async () => {
    const { getByRole } = await render(`
      <div ludsRadioGroup ludsRadioGroupOrientation="vertical">
        <div ludsRadioItem ludsRadioItemValue="1">One</div>
        <div ludsRadioItem ludsRadioItemValue="2">Two</div>
      </div>
    `, {
      imports: [LudsRadioGroup, LudsRadioItem],
    });

    expect(getByRole('radiogroup')).toHaveAttribute('data-orientation', 'vertical');
    expect(getByRole('radiogroup')).toHaveAttribute('aria-orientation', 'vertical');
  });

  it.skip('should set to disabled', async () => {
    const { getByRole } = await render(`
      <div ludsRadioGroup ludsRadioGroupDisabled>
        <div ludsRadioItem ludsRadioItemValue="1">One</div>
        <div ludsRadioItem ludsRadioItemValue="2">Two</div>
      </div>
    `, {
      imports: [ludsRadioGroup, ludsRadioItem],
    });
    expect(getByRole('radiogroup')).toHaveAttribute('data-disabled', '');
  });

  it.skip('should not select any item by default', async () => {
    const { getByRole } = await render(`
      <div ludsRadioGroup>
        <div ludsRadioItem ludsRadioItemValue="1">One</div>
        <div ludsRadioItem ludsRadioItemValue="2">Two</div>
      </div>
    `, {
      imports: [LudsRadioGroup, LudsRadioItem],
    });
    expect(getByRole('radio', { name: 'One' })).toHaveAttribute('aria-checked', 'false');
    expect(getByRole('radio', { name: 'One' })).not.toHaveAttribute('data-checked');
    expect(getByRole('radio', { name: 'Two' })).toHaveAttribute('aria-checked', 'false');
    expect(getByRole('radio', { name: 'Two' })).not.toHaveAttribute('data-checked');
  });

  it.skip('should select an item when clicked', async () => {
    const valueChange = vi.fn();
    const { getByRole, fixture } = await render(`
      <div ludsRadioGroup (ludsRadioGroupValueChange)="valueChange($event)">
        <div ludsRadioItem ludsRadioItemValue="1">One</div>
        <div ludsRadioItem ludsRadioItemValue="2">Two</div>
      </div>
    `, {
      imports: [LudsRadioGroup, LudsRadioItem],
      componentProperties: { valueChange },
    });
    const radioOne = getByRole('radio', { name: 'One' });
    const radioTwo = getByRole('radio', { name: 'Two' });
    radioOne.click();
    fixture.detectChanges();
    expect(radioOne).toHaveAttribute('aria-checked', 'true');
    expect(radioOne).toHaveAttribute('data-checked', '');
    expect(radioTwo).toHaveAttribute('aria-checked', 'false');
    expect(radioTwo).not.toHaveAttribute('data-checked');
    expect(valueChange).toHaveBeenCalledWith('1');
    expect(valueChange).toHaveBeenCalledTimes(1);
    expect(document.activeElement).toBe(radioOne);
    expect(document.activeElement).not.toBe(radioTwo);
  });

  it.skip('should select an item when the value is set', async () => {
    const { getByRole, fixture } = await render(`
      <div ludsRadioGroup [(ludsRadioGroupValue)]="value">
        <div ludsRadioItem ludsRadioItemValue="1">One</div>
        <div ludsRadioItem ludsRadioItemValue="2">Two</div>
      </div>
    `, {
      imports: [LudsRadioGroup, LudsRadioItem],
      componentProperties: { value: '1' },
    });
    const radioOne = getByRole('radio', { name: 'One' });
    const radioTwo = getByRole('radio', { name: 'Two' });
    fixture.detectChanges();
    expect(radioOne).toHaveAttribute('aria-checked', 'true');
    expect(radioOne).toHaveAttribute('data-checked', '');
    expect(radioTwo).toHaveAttribute('aria-checked', 'false');
    expect(radioTwo).not.toHaveAttribute('data-checked');
  });

  it.skip('should not be able to select a radio item that is in disabled state', async () => {
    const valueChange = vi.fn();
    const { getByRole, fixture } = await render(`
      <div ludsRadioGroup (ludsRadioGroupValueChange)="valueChange($event)">
        <div ludsRadioItem ludsRadioItemValue="1" [ludsRadioItemDisabled]="true">One</div>
        <div ludsRadioItem ludsRadioItemValue="2">Two</div>
      </div>
    `, {
      imports: [LudsRadioGroup, LudsRadioItem],
      componentProperties: { valueChange },
    });
    const radioOne = getByRole('radio', { name: 'One' });
    const radioTwo = getByRole('radio', { name: 'Two' });
    // Select the enabled item first
    radioTwo.click();
    fixture.detectChanges();
    expect(radioTwo).toHaveAttribute('aria-checked', 'true');
    expect(radioTwo).toHaveAttribute('data-checked', '');
    expect(valueChange).toHaveBeenCalledWith('2');
    // Try to select the disabled item
    radioOne.click();
    fixture.detectChanges();
    // Value should remain the same
    expect(radioTwo).toHaveAttribute('aria-checked', 'true');
    expect(radioTwo).toHaveAttribute('data-checked', '');
    expect(radioOne).toHaveAttribute('aria-checked', 'false');
    expect(radioOne).not.toHaveAttribute('data-checked');
    // valueChange should not be called again with '1'
    expect(valueChange).toHaveBeenCalledTimes(1);
  });

  it.skip('should not be able to select a radio item that is in error state', async () => {
    const valueChange = vi.fn();
    const { getByRole, fixture } = await render(`
      <div ludsRadioGroup (ludsRadioGroupValueChange)="valueChange($event)">
        <div ludsRadioItem ludsRadioItemValue="1" [ludsRadioItemError]=true>One</div>
        <div ludsRadioItem ludsRadioItemValue="2">Two</div>
      </div>
    `, {
      imports: [LudsRadioGroup, LudsRadioItem],
      componentProperties: { valueChange },
    });
    const radioOne = getByRole('radio', { name: 'One' });
    const radioTwo = getByRole('radio', { name: 'Two' });
    // Select the enabled item first
    radioTwo.click();
    fixture.detectChanges();
    expect(radioTwo).toHaveAttribute('aria-checked', 'true');
    expect(radioTwo).toHaveAttribute('data-checked', '');
    expect(valueChange).toHaveBeenCalledWith('2');
    // Try to select the error state item
    radioOne.click();
    fixture.detectChanges();
    // Value should remain the same
    expect(radioTwo).toHaveAttribute('aria-checked', 'true');
    expect(radioTwo).toHaveAttribute('data-checked', '');
    expect(radioOne).toHaveAttribute('aria-checked', 'false');
    expect(radioOne).not.toHaveAttribute('data-checked');
    // valueChange should not be called again with '1'
    expect(valueChange).toHaveBeenCalledTimes(1);
  });
});
