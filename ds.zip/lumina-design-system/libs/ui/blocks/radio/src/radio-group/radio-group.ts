import { BooleanInput } from '@angular/cdk/coercion';
import { Directive, OnInit, OnChanges, SimpleChanges, booleanAttribute, input, output } from '@angular/core';
import { uniqueId } from '@luds/ui/blocks/utils';
import { provideRadioGroupState, radioGroupState } from './radio-group-state';
import { setupFormControl } from '@luds/ui/blocks/form-field';
import { LudsOrientation } from '@luds/ui/blocks/common';
import { LudsRovingFocusGroup, injectRovingFocusGroupState } from '@luds/ui/blocks/roving-focus';

/**
 * Aplique a diretiva `ludsRadioGroup` para criar radio groups, permitindo ao usuário selecionar uma única opção entre várias disponíveis.
 *
 * O componente de radio group segue o padrão WAI-ARIA para acessibilidade, garantindo navegação por teclado e suporte total a leitores de tela.
 */
@Directive({
  selector: '[ludsRadioGroup]',
  providers: [provideRadioGroupState()],
  hostDirectives: [
    {
      directive: LudsRovingFocusGroup,
      inputs: [
        'ludsRovingFocusGroupOrientation:ludsRadioGroupOrientation',
        'ludsRovingFocusGroupDisabled:ludsRadioGroupDisabled',
      ],
    },
  ],
  host: {
    role: 'radiogroup',
    '[id]': 'id()',
    '[attr.aria-orientation]': 'state.orientation()',
    '[attr.data-orientation]': 'state.orientation()',
    '[attr.data-disabled]': 'state.disabled() ? "" : null',
  },
  standalone: true,
})
export class LudsRadioGroup<T> implements OnInit, OnChanges {
  /**
   * Acessa o estado do roving focus group.
   */
  private readonly rovingFocusGroupState = injectRovingFocusGroupState();

  /**
   * O id do radio group. Se não fornecido, um id único será gerado.
   */
  readonly id = input<string>(uniqueId('luds-radio-group'));

  /**
   * O valor do radio group.
   */
  readonly value = input<T | null>(null, { alias: 'ludsRadioGroupValue' });

  /**
   * Evento emitido quando o valor do radio group é alterado.
   */
  readonly valueChange = output<T | null>({
    alias: 'ludsRadioGroupValueChange',
  });

  /**
   * Indica se o radio group está desabilitado.
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsRadioGroupDisabled',
    transform: booleanAttribute,
  });

  /**
   * A orientação do radio group.
   * @default 'horizontal'
   */
  readonly orientation = input<LudsOrientation>('horizontal', {
    alias: 'ludsRadioGroupOrientation',
  });

  /**
   * Função de comparação do radio group. Útil se os valores forem objetos e você quiser compará-los por valor e não por referência.
   * @default (a, b) => a === b
   */
  readonly compareWith = input<(a: T | null, b: T | null) => boolean>((a, b) => a === b, {
    alias: 'ludsRadioGroupCompareWith',
  });

  /**
   * O estado do radio group.
   * @internal
   */
  protected readonly state = radioGroupState<LudsRadioGroup<T>>(this);

  constructor() {
    setupFormControl({ id: this.state.id, disabled: this.state.disabled });
  }

  ngOnInit(): void {
    this.rovingFocusGroupState().orientation.set(this.state.orientation());
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['orientation']) {
      this.state.orientation.set(this.orientation());
      this.rovingFocusGroupState().orientation.set(this.orientation());
    }
  }

  /**
   * Seleciona uma opção do radio group.
   * @param value O valor da opção do radio group a ser selecionado.
   */
  select(value: T): void {
    if (this.state.compareWith()(this.state.value(), value)) {
      return;
    }

    this.state.value.set(value);
    this.valueChange.emit(value);
  }
}