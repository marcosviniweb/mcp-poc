import { Directive, computed } from '@angular/core';
import { injectRadioGroupState } from '../radio-group/radio-group-state';
import { injectRadioItemState } from '../radio-item/radio-item-state';


/**
 * Aplique a diretiva `ludsRadioIndicator` a um elemento que representa o radio indicator, isto é, o pequeno círculo do rádio.
 *
 */
@Directive({
  selector: '[ludsRadioIndicator]',
  host: {
    '[attr.data-checked]': 'checked() ? "" : null',
    '[attr.data-disabled]': 'radioItemState().disabled() ? "" : null',
  },
  standalone: true
})
export class LudsRadioIndicator<T> {
  /**
   * Acessa o estado do radio group.
   */
  protected readonly radioGroupState = injectRadioGroupState<T>();

  /**
   * Acessa o estado do item do radio group.
   */
  protected readonly radioItemState = injectRadioItemState<T>();

  /**
   * Determina se o radio indicator está selecionado.
   */
  protected readonly checked = computed(
    () => this.radioGroupState().value() === this.radioItemState().value(),
  );
}