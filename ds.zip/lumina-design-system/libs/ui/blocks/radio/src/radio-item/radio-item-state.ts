import {
    createState,
    createStateInjector,
    createStateProvider,
    createStateToken,
    InjectedState,
  } from '@luds/ui/blocks/state';
import { LudsRadioItem } from './radio-item';
  
  /**
   * O token de estado para o componente Radio Item.
   */
  export const LudsRadioItemStateToken = createStateToken<LudsRadioItem<unknown>>('RadioItem');
  
  /**
   * Fornece o estado do Radio Item.
   */
  export const provideRadioItemState = createStateProvider(LudsRadioItemStateToken);
  
  /**
   * Injeta o estado do Radio Item.
   */
  export const injectRadioItemState = createStateInjector<LudsRadioItem<unknown>>(LudsRadioItemStateToken) as <T>() => InjectedState<LudsRadioItem<T>>;
  
  /**
   * Função de registro de estado do Radio Item.
   */
  export const radioItemState = createState(LudsRadioItemStateToken);