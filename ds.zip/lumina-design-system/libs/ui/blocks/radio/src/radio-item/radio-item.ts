import { BooleanInput } from '@angular/cdk/coercion';
import { Directive, HostListener, OnInit, booleanAttribute, computed, input } from '@angular/core';
import { injectRadioGroupState } from '../radio-group/radio-group-state';
import { provideRadioItemState, radioItemState } from './radio-item-state';
import { LudsRovingFocusItem } from '@luds/ui/blocks/roving-focus';


/**
 * Aplique a diretiva `ludsRadioItem` a um elemento que representa um radio item.
 *
 */
@Directive({
  selector: '[ludsRadioItem]',
  providers: [provideRadioItemState()],
  hostDirectives: [{
    directive: LudsRovingFocusItem,
    inputs: [
      'ludsRovingFocusItemDisabled:ludsRadioItemDisabled',
      'ludsRovingFocusItemError:ludsRadioItemError'
    ]
  }],
  host: {
    role: 'radio',
    '[attr.aria-checked]': 'checked() ? "true" : "false"',
    '[attr.data-disabled]': 'state.disabled() ? "" : null',
    '[attr.data-checked]': 'checked() ? "" : null',
  },
  standalone: true
})
export class LudsRadioItem<T> implements OnInit {
  /**
   * Acessa o estado do radio group.
   */
  private readonly radioGroupState = injectRadioGroupState<T>();

  /**
   * O valor do Radio Item.
   */
  readonly value = input<T>('' as T, { alias: 'ludsRadioItemValue' });

  /**
   * Indica se o Radio Item está desabilitado.
   * @default false
   */
  readonly disabled = input<boolean, BooleanInput>(false, {
    alias: 'ludsRadioItemDisabled',
    transform: booleanAttribute,
  });

  /**
   * Indica se o Radio Item está selecionado.
   */
  readonly checked = computed(() =>
    this.radioGroupState().compareWith()(this.radioGroupState().value(), this.state?.value()!),
  );

  /**
   * O estado do Radio Item.
   */
  protected readonly state = radioItemState<LudsRadioItem<T>>(this);

  ngOnInit(): void {
    if (this.state.value() === undefined) {
      throw new Error('The `ludsRadioItem` directive requires a `value` input.');
    }
  }

  /**
   * Quando o item recebe foco, seleciona-o.
   * @internal
   */
  @HostListener('focus')
  protected onFocus(): void {
    if (this.disabled()) return;
    this.radioGroupState().select(this.state.value()!);
  }

  /**
   * Quando o item recebe um clique, seleciona-o.
   * @internal
   */
  @HostListener('click')
  protected onClick(): void {
    if (this.disabled()) return;
    this.radioGroupState().select(this.state.value()!);
  }
}