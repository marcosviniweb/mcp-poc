import { BooleanInput } from '@angular/cdk/coercion';
import { booleanAttribute, Directive, HostListener, input } from '@angular/core';
import { injectDialogRef } from '../dialog/dialog-ref';
import { LudsExitAnimation } from '@luds/ui/blocks/internal';

@Directive({
  selector: '[ludsDialogOverlay]',
  standalone: true,
  exportAs: 'ludsDialogOverlay',
  hostDirectives: [LudsExitAnimation],
})
export class LudsDialogOverlay {
  /** Acessa a referência do dialog. */
  private readonly dialogRef = injectDialogRef();

  /**
   * Indica se o dialog deve ser fechado ao clicar no fundo.
   * @default `true`
   */
  readonly closeOnClick = input<boolean, BooleanInput>(true, {
    alias: 'ludsDialogOverlayCloseOnClick',
    transform: booleanAttribute,
  });

  @HostListener('click')
  protected close(): void {
    if (this.closeOnClick()) {
      this.dialogRef.close(undefined, 'mouse');
    }
  }
}