import { ScrollStrategy } from '@angular/cdk/overlay';
import { InjectionToken, Injector, Provider, ViewContainerRef, inject } from '@angular/core';

/** Papéis ARIA válidos para um dialog. */
export type LudsDialogRole = 'dialog' | 'alertdialog';

export interface LudsDialogConfig<T = any> {
  /** O contêiner de visualização ao qual o dialog será anexado. */
  viewContainerRef?: ViewContainerRef;

  /** O injetor a ser usado para o dialog. Padrão é o injetor do contêiner de visualização. */
  injector?: Injector;

  /** ID para o dialog. Se omitido, um ID único será gerado. */
  id?: string;

  /** O papel (role) do dialog. */
  role?: LudsDialogRole;

  /** Indica se este é um dialog modal. Usado para definir o atributo `aria-modal`. */
  modal?: boolean;

  /** Estratégia de rolagem a ser usada para o dialog. Determina como o dialog responde à rolagem sob o elemento do painel. */
  scrollStrategy?: ScrollStrategy;

  /**
   * Indica se o dialog deve ser fechado quando o usuário navegar para trás ou para frente no histórico do navegador.
   */
  closeOnNavigation?: boolean;

  /** Indica se o dialog deve ser fechado quando o usuário pressionar a tecla Escape. */
  closeOnEscape?: boolean;

  data?: T;
}

export const defaultDialogConfig: LudsDialogConfig = {
  role: 'dialog',
  modal: true,
  closeOnNavigation: true,
  closeOnEscape: true,
};

export const LudsDialogConfigToken = new InjectionToken<LudsDialogConfig>('LudsDialogConfigToken');

/**
 * Fornece a configuração padrão do dialog
 * @param config A configuração do dialog
 * @returns O provedor
 */
export function provideDialogConfig(config: Partial<LudsDialogConfig>): Provider[] {
  return [
    {
      provide: LudsDialogConfigToken,
      useValue: { ...defaultDialogConfig, ...config },
    },
  ];
}

/**
 * Injeta a configuração do dialog
 * @returns A configuração global do dialog
 */
export function injectDialogConfig(): LudsDialogConfig {
  return inject(LudsDialogConfigToken, { optional: true }) ?? defaultDialogConfig;
}