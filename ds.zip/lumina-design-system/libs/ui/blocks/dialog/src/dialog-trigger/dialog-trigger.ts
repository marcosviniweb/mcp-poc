import { Directive, HostListener, inject, input, TemplateRef } from '@angular/core';
import { injectDialogConfig } from '../config/dialog-config';
import { LudsDialogRef } from '../dialog/dialog-ref';
import { LudsDialogContext, LudsDialogManager } from '../dialog/dialog.service';

@Directive({
  selector: '[ludsDialogTrigger]',
  exportAs: 'ludsDialogTrigger',
  standalone: true
})
export class LudsDialogTrigger {
  /** Acessa a configuração global */
  private readonly config = injectDialogConfig();

  /** Acessa o gerenciador de dialog. */
  private readonly dialogManager = inject(LudsDialogManager);

  /** O template a ser lançado. */
  readonly template = input.required<TemplateRef<LudsDialogContext>>({
    alias: 'ludsDialogTrigger',
  });

  /**
   * Indica se o dialog deve ser fechado ao pressionar a tecla Escape.
   * @default `true`
   */
  readonly closeOnEscape = input(this.config.closeOnEscape, {
    alias: 'ludsDialogTriggerCloseOnEscape',
  });

  /**
   * Armazena a referência do dialog.
   * @internal
   */
  private dialogRef: LudsDialogRef | null = null;

  @HostListener('click')
  protected launch(): void {
    this.dialogRef = this.dialogManager.open(this.template(), {
      closeOnEscape: this.closeOnEscape(),
    });
    this.dialogRef.closed.subscribe(() => (this.dialogRef = null));
  }
}