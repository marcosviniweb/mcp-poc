import { Directive, input, OnDestroy } from '@angular/core';
import { injectDialogState } from '../dialog/dialog-state';
import { onChange, uniqueId } from '@luds/ui/blocks/utils';

@Directive({
  selector: '[ludsDialogTitle]',
  exportAs: 'ludsDialogTitle',
  standalone: true,
  host: {
    '[id]': 'id()',
  },
})
export class LudsDialogTitle implements OnDestroy {
  /** Acessa o dialog. */
  private readonly dialog = injectDialogState();

  /** O ID do título. */
  readonly id = input<string>(uniqueId('luds-dialog-title'));

  constructor() {
    onChange(this.id, (id, prevId) => {
      if (prevId) {
        this.dialog().removeLabelledBy(prevId);
      }

      if (id) {
        this.dialog().setLabelledBy(id);
      }
    });
  }

  ngOnDestroy(): void {
    this.dialog().removeLabelledBy(this.id());
  }
}