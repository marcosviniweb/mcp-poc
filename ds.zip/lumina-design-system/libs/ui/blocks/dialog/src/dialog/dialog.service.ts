import { FocusMonitor } from "@angular/cdk/a11y";
import { Overlay, OverlayConfig, OverlayContainer, ScrollStrategy } from "@angular/cdk/overlay";
import { ComponentPortal, TemplatePortal } from "@angular/cdk/portal";
import { DOCUMENT } from "@angular/common";
import {
  ApplicationRef,
  Injectable,
  Injector,
  OnDestroy,
  StaticProvider,
  TemplateRef,
  Type,
  ViewContainerRef,
  inject,
  isDevMode,
} from "@angular/core";
import { Observable, Subject, defer } from "rxjs";
import { startWith } from "rxjs/operators";
import { LudsDialogConfig, injectDialogConfig } from "../config/dialog-config";
import { LudsDialogRef } from "./dialog-ref";
import { uniqueId } from "@luds/ui/blocks/utils";
import { LudsExitAnimationManager } from "@luds/ui/blocks/internal";

/**
 * Baseado no serviço Dialog do Angular CDK.
 * https://github.com/angular/components/blob/main/src/cdk/dialog/dialog.ts
 */

@Injectable({
  providedIn: "root",
})
export class LudsDialogManager implements OnDestroy {
  private readonly applicationRef = inject(ApplicationRef);
  private readonly document = inject<Document>(DOCUMENT);
  private readonly overlay = inject(Overlay);
  private readonly focusMonitor = inject(FocusMonitor);
  private readonly defaultOptions = injectDialogConfig();
  private readonly parentDialogManager = inject(LudsDialogManager, {
    optional: true,
    skipSelf: true,
  });
  private readonly overlayContainer = inject(OverlayContainer);
  private readonly scrollStrategy: ScrollStrategy =
    this.defaultOptions.scrollStrategy ?? this.overlay.scrollStrategies.block();

  private openDialogsAtThisLevel: LudsDialogRef[] = [];
  private readonly afterAllClosedAtThisLevel = new Subject<void>();
  private readonly afterOpenedAtThisLevel = new Subject<LudsDialogRef>();
  private ariaHiddenElements = new Map<Element, string | null>();

  /** Mantém o controle dos dialogs atualmente abertos. */
  get openDialogs(): readonly LudsDialogRef[] {
    return this.parentDialogManager ? this.parentDialogManager.openDialogs : this.openDialogsAtThisLevel;
  }

  /** Stream que emite quando um dialog é aberto. */
  get afterOpened(): Subject<LudsDialogRef> {
    return this.parentDialogManager ? this.parentDialogManager.afterOpened : this.afterOpenedAtThisLevel;
  }

  /**
   * Stream que emite quando todos os dialogs abertos foram fechados.
   * Emitirá ao se inscrever se não houver dialogs abertos.
   */
  readonly afterAllClosed: Observable<void> = defer(() =>
    this.openDialogs.length ? this.getAfterAllClosed() : this.getAfterAllClosed().pipe(startWith(undefined)),
  );

  /**
   * Abre um dialog modal contendo o template fornecido.
   */
  open<T, R>(
    templateRefOrComponentType: TemplateRef<LudsDialogContext<T, R>> | Type<unknown>,
    config?: LudsDialogConfig<T>,
  ): LudsDialogRef<T, R> {
    const activeElement = this.document.activeElement;
    const viewContainerRef = this.applicationRef.components[0].injector.get(ViewContainerRef);

    const defaults = this.defaultOptions;
    config = { ...defaults, viewContainerRef, ...config };
    config.id = config.id ?? uniqueId("luds-dialog");

    if (config.id && this.getDialogById(config.id) && isDevMode()) {
      throw Error(`Dialog with id "${config.id}" exists already. The dialog id must be unique.`);
    }

    const overlayConfig = this.getOverlayConfig(config);
    const overlayRef = this.overlay.create(overlayConfig);
    const dialogRef = new LudsDialogRef<T, R>(overlayRef, config);
    const injector = this.createInjector(config, dialogRef, undefined);

    dialogRef.injector = injector;

    const context: LudsDialogContext<T, R> = {
      $implicit: dialogRef,
      close: dialogRef.close.bind(dialogRef),
    };

    if (templateRefOrComponentType instanceof TemplateRef) {
      overlayRef.attach(new TemplatePortal(templateRefOrComponentType, config.viewContainerRef!, context, injector));
    } else {
      overlayRef.attach(new ComponentPortal(templateRefOrComponentType, config.viewContainerRef!, injector));
    }

    if (!this.openDialogs.length) {
      this.hideNonDialogContentFromAssistiveTechnology();
    }

    (this.openDialogs as LudsDialogRef[]).push(dialogRef as LudsDialogRef<any, any>);
    this.afterOpened.next(dialogRef as LudsDialogRef<any, any>);

    dialogRef.closed.subscribe((closeResult) => {
      this.removeOpenDialog(dialogRef as LudsDialogRef<any, any>, true);
      if (activeElement instanceof HTMLElement && this.document.body.contains(activeElement)) {
        this.focusMonitor.focusVia(
          activeElement,
          closeResult?.focusOrigin ?? (this.focusMonitor as any)._lastFocusOrigin,
        );
      }
    });

    return dialogRef;
  }

  /**
   * Fecha todos os dialogs atualmente abertos.
   */
  closeAll(): void {
    reverseForEach(this.openDialogs, (dialog) => dialog.close());
  }

  /**
   * Encontra um dialog aberto pelo seu ID.
   * @param id ID usado para procurar o dialog.
   */
  getDialogById(id: string): LudsDialogRef | undefined {
    return this.openDialogs.find((dialog) => dialog.id === id);
  }

  ngOnDestroy(): void {
    reverseForEach(this.openDialogsAtThisLevel, (dialog) => {
      this.removeOpenDialog(dialog, false);
    });

    reverseForEach(this.openDialogsAtThisLevel, (dialog) => dialog.close());

    this.afterAllClosedAtThisLevel.complete();
    this.afterOpenedAtThisLevel.complete();
    this.openDialogsAtThisLevel = [];
  }

  /**
   * Cria uma configuração de overlay a partir de uma configuração de dialog.
   */
  private getOverlayConfig(config: LudsDialogConfig): OverlayConfig {
    const state = new OverlayConfig({
      positionStrategy: this.overlay.position().global().centerHorizontally().centerVertically(),
      scrollStrategy: config.scrollStrategy || this.scrollStrategy,
      hasBackdrop: false,
      disposeOnNavigation: config.closeOnNavigation,
    });

    return state;
  }

  /**
   * Cria um injetor personalizado para ser usado dentro do dialog.
   * Isso permite que um componente carregado dentro de um dialog feche a si mesmo e, opcionalmente, retorne um valor.
   */
  private createInjector<T, R>(
    config: LudsDialogConfig<T>,
    dialogRef: LudsDialogRef<T, R>,
    fallbackInjector: Injector | undefined,
  ): Injector {
    const userInjector = config.injector || config.viewContainerRef?.injector;
    const providers: StaticProvider[] = [
      { provide: LudsDialogRef, useValue: dialogRef },
      { provide: LudsExitAnimationManager, useClass: LudsExitAnimationManager },
    ];

    return Injector.create({ parent: userInjector || fallbackInjector, providers });
  }

  /**
   * Remove um dialog do array de dialogs abertos.
   */
  private removeOpenDialog(dialogRef: LudsDialogRef, emitEvent: boolean) {
    const index = this.openDialogs.indexOf(dialogRef);

    if (index > -1) {
      (this.openDialogs as LudsDialogRef[]).splice(index, 1);

      if (!this.openDialogs.length) {
        this.ariaHiddenElements.forEach((previousValue, element) => {
          if (previousValue) {
            element.setAttribute("aria-hidden", previousValue);
          } else {
            element.removeAttribute("aria-hidden");
          }
        });

        this.ariaHiddenElements.clear();

        if (emitEvent) {
          this.getAfterAllClosed().next();
        }
      }
    }
  }

  /** Oculta todo o conteúdo que não é um overlay da tecnologia assistiva. */
  private hideNonDialogContentFromAssistiveTechnology() {
    const overlayContainer = this.overlayContainer.getContainerElement();

    if (overlayContainer.parentElement) {
      const siblings = overlayContainer.parentElement.children;

      for (let i = siblings.length - 1; i > -1; i--) {
        const sibling = siblings[i];

        if (
          sibling !== overlayContainer &&
          sibling.nodeName !== "SCRIPT" &&
          sibling.nodeName !== "STYLE" &&
          !sibling.hasAttribute("aria-live")
        ) {
          this.ariaHiddenElements.set(sibling, sibling.getAttribute("aria-hidden"));
          sibling.setAttribute("aria-hidden", "true");
        }
      }
    }
  }

  private getAfterAllClosed(): Subject<void> {
    const parent = this.parentDialogManager;
    return parent ? parent.getAfterAllClosed() : this.afterAllClosedAtThisLevel;
  }
}

/**
 * Executa um callback em todos os elementos de um array enquanto itera em ordem reversa.
 * Útil se o array está sendo modificado enquanto é iterado.
 */
function reverseForEach<T>(items: T[] | readonly T[], callback: (current: T) => void) {
  let i = items.length;

  while (i--) {
    callback(items[i]);
  }
}

export interface LudsDialogContext<T = unknown, R = unknown> {
  $implicit: LudsDialogRef<T, R>;
  close: (result?: R) => void;
}

/**
 * Injeta o gerenciador de dialogs.
 */
export function injectDialogManager(): LudsDialogManager {
  return inject(LudsDialogManager);
}
