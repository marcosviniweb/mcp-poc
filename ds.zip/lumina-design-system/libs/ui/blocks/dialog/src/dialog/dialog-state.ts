import { createStateToken, createStateProvider, createStateInjector, createState } from "@luds/ui/blocks/state";
import type { LudsDialog } from "./dialog";

/**
 * O token de estado para o primitivo Dialog.
 */
export const LudsDialogStateToken = createStateToken<LudsDialog<any, any>>("Dialog");

/**
 * Fornece o estado do Dialog.
 */
export const provideDialogState = createStateProvider(LudsDialogStateToken);

/**
 * Injeta o estado do Dialog.
 */
export const injectDialogState = createStateInjector<LudsDialog>(LudsDialogStateToken);

/**
 * A função de registro de estado do Dialog.
 */
export const dialogState = createState(LudsDialogStateToken);
