import { BooleanInput } from '@angular/cdk/coercion';
import { booleanAttribute, Directive, HostListener, input, OnDestroy, signal } from '@angular/core';
import { LudsFocusTrap } from '@luds/ui/blocks/focus-trap';
import { LudsExitAnimation } from '@luds/ui/blocks/internal';
import { uniqueId } from '@luds/ui/blocks/utils';
import { injectDialogConfig } from '../config/dialog-config';
import { injectDialogRef } from './dialog-ref';
import { dialogState, provideDialogState } from './dialog-state';

/**
 * Aplique a diretiva `ludsDialog` para criar um container de dialog acessível e gerenciável.
 * Esta diretiva fornece recursos de acessibilidade (como foco, aria-atributos e identificação),
 * gerenciamento de estado, integração com animações de saída e suporte a dialog modais.
 * Use para encapsular o conteúdo do seu dialog, garantindo consistência visual e comportamental.
 */
@Directive({
  selector: '[ludsDialog]',
  exportAs: 'ludsDialog',
  providers: [provideDialogState()],
  hostDirectives: [LudsFocusTrap, LudsExitAnimation],
  standalone: true,
  host: {
    tabindex: '-1',
    '[id]': 'state.id()',
    '[attr.role]': 'state.role()',
    '[attr.aria-modal]': 'state.modal()',
    '[attr.aria-labelledby]': 'labelledBy().join(" ")',
    '[attr.aria-describedby]': 'describedBy().join(" ")',
  },
})
export class LudsDialog<T = unknown, R = unknown> implements OnDestroy {
  private readonly config = injectDialogConfig();

  /** Acessa a referência do diálogo */
  private readonly dialogRef = injectDialogRef<T, R>();

  /** O ID do diálogo */
  readonly id = input<string>(uniqueId('luds-dialog'));

  /** O papel (role) do diálogo. */
  readonly role = input(this.config.role, {
    alias: 'ludsDialogRole',
  });

  /** Indica se o diálogo é modal. */
  readonly modal = input<boolean, BooleanInput>(this.config.modal ?? false, {
    alias: 'ludsDialogModal',
    transform: booleanAttribute,
  });

  /** Os IDs de labelledby */
  protected readonly labelledBy = signal<string[]>([]);

  /** Os IDs de describedby */
  protected readonly describedBy = signal<string[]>([]);

  /** O estado do diálogo */
  protected readonly state = dialogState<LudsDialog<T, R>>(this);

  ngOnDestroy(): void {
    this.close();
  }

  /** Fecha o diálogo. */
  close(result?: R): void {
    this.dialogRef.close(result);
  }

  /** Impede que eventos de clique se propaguem para o overlay */
  @HostListener('click', ['$event'])
  protected onClick(event: Event): void {
    event.stopPropagation();
  }

  /** @internal registra um ID de labelledby */
  setLabelledBy(id: string): void {
    this.labelledBy.update(ids => [...ids, id]);
  }

  /** @internal registra um ID de describedby */
  setDescribedBy(id: string): void {
    this.describedBy.update(ids => [...ids, id]);
  }

  /** @internal remove um ID de labelledby */
  removeLabelledBy(id: string): void {
    this.labelledBy.update(ids => ids.filter(i => i !== id));
  }

  /** @internal remove um ID de describedby */
  removeDescribedBy(id: string): void {
    this.describedBy.update(ids => ids.filter(i => i !== id));
  }
}