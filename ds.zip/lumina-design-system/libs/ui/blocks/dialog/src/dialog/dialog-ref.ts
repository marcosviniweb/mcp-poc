import { FocusOrigin } from '@angular/cdk/a11y';
import { hasModifierKey } from '@angular/cdk/keycodes';
import { OverlayRef } from '@angular/cdk/overlay';
import { inject, Injector } from '@angular/core';
import { Observable, Subject, Subscription } from 'rxjs';
import { LudsDialogConfig } from '../config/dialog-config';
import { LudsExitAnimationManager } from '@luds/ui/blocks/internal';

/**
 * Referência para um dialog aberto via o serviço Dialog.
 */
export class LudsDialogRef<T = unknown, R = unknown> {
  /** Indica se o usuário pode fechar o dialog. */
  disableClose: boolean | undefined;

  /** Indica se a tecla Escape pode fechar o dialog. */
  closeOnEscape: boolean | undefined;

  /** Emite quando o dialog foi fechado. */
  readonly closed = new Subject<{ result?: R, focusOrigin?: FocusOrigin; } | null>();

  /** Emite eventos de teclado dentro do dialog. */
  readonly keydownEvents: Observable<KeyboardEvent>;

  /** Emite eventos de ponteiro que ocorrem fora do dialog. */
  readonly outsidePointerEvents: Observable<MouseEvent>;

  /** Dados passados pelo abridor do dialog. */
  readonly data?: T;

  /** ID único para o dialog. */
  readonly id: string;

  /** Assinatura para desligamentos externos do dialog. */
  private detachSubscription: Subscription;

  /** @internal Armazena o injetor */
  injector: Injector | undefined;

  /** Indica se o dialog está sendo fechado. */
  private closing = false;

  constructor(
    readonly overlayRef: OverlayRef,
    readonly config: LudsDialogConfig<T>,
  ) {
    this.data = config.data;
    this.keydownEvents = overlayRef.keydownEvents();
    this.outsidePointerEvents = overlayRef.outsidePointerEvents();
    this.id = config.id!;
    this.closeOnEscape = config.closeOnEscape ?? true;

    this.keydownEvents.subscribe(event => {
      if (
        event.key === 'Escape' &&
        !this.disableClose &&
        this.closeOnEscape !== false &&
        !hasModifierKey(event)
      ) {
        event.preventDefault();
        this.close(undefined, 'keyboard');
      }
    });

    this.detachSubscription = overlayRef.detachments().subscribe(() => this.close());
  }

  /**
   * Fecha o dialog.
   * @param result Resultado opcional para retornar ao abridor do dialog.
   * @param options Opções adicionais para personalizar o comportamento de fechamento.
   */
  async close(result?: R, focusOrigin?: FocusOrigin): Promise<void> {
    // Se o dialog já estiver fechado, não faça nada.
    if (this.closing) {
      return;
    }

    this.closing = true;

    const exitAnimationManager = this.injector?.get(LudsExitAnimationManager, undefined, {
      optional: true,
    });
    if (exitAnimationManager) {
      await exitAnimationManager.exit();
    }

    this.overlayRef.dispose();
    this.detachSubscription.unsubscribe();
    if (focusOrigin) {
      this.closed.next({ focusOrigin, result });
    } else {
      this.closed.next(null);
    }
    this.closed.complete();
  }

  /** Atualiza a posição do dialog com base na estratégia de posição atual. */
  updatePosition(): this {
    this.overlayRef.updatePosition();
    return this;
  }
}

/** Injeta uma referência ao dialog. */
export function injectDialogRef<T = unknown, R = unknown>(): LudsDialogRef<T, R> {
  return inject<LudsDialogRef<T, R>>(LudsDialogRef);
}

