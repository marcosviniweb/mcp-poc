
import { Directive } from '@angular/core';

@Directive({
  selector: '[ludsDialogPanel]',
  exportAs: 'ludsDialogPanel',
})
export class LudsDialogPanel {}