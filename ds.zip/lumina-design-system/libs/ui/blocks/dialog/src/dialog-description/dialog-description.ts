import { Directive, input, OnDestroy } from '@angular/core';
import { onChange, uniqueId } from '@luds/ui/blocks/utils';
import { injectDialogState } from '../dialog/dialog-state';

@Directive({
  selector: '[ludsDialogDescription]',
  exportAs: 'ludsDialogDescription',
  standalone: true,
  host: {
    '[id]': 'id()',
  },
})
export class LudsDialogDescription implements OnDestroy {
  /** Acessa o dialog */
  private readonly dialog = injectDialogState();

  /** O ID das descrições. */
  readonly id = input<string>(uniqueId('luds-dialog-description'));

  constructor() {
    onChange(this.id, (id, prevId) => {
      if (prevId) {
        this.dialog().removeDescribedBy(prevId);
      }

      if (id) {
        this.dialog().setDescribedBy(id);
      }
    });
  }

  ngOnDestroy(): void {
    this.dialog().removeDescribedBy(this.id());
  }
}