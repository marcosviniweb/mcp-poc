# @luds/ui/blocks/dialog

Secondary entry point of `@luds/ui`. It can be used by importing from `@luds/ui/blocks/dialog`.
