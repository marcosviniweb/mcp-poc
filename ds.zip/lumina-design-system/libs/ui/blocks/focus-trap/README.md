# @luds/ui/blocks/focus-trap

Secondary entry point of `@luds/ui`. It can be used by importing from `@luds/ui/blocks/focus-trap`.
