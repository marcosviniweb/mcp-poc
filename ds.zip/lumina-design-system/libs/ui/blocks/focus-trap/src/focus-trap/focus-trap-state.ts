import {
    createState,
    createStateInjector,
    createStateProvider,
    createStateToken,
  } from '@luds/ui/blocks/state';
  import type { LudsFocusTrap } from './focus-trap';
  
  /**
   * The state token  for the FocusTrap primitive.
   */
  export const LudsFocusTrapStateToken = createStateToken<LudsFocusTrap>('FocusTrap');
  
  /**
   * Provides the FocusTrap state.
   */
  export const provideFocusTrapState = createStateProvider(LudsFocusTrapStateToken);
  
  /**
   * Injects the FocusTrap state.
   */
  export const injectFocusTrapState = createStateInjector(LudsFocusTrapStateToken);
  
  /**
   * The FocusTrap state registration function.
   */
  export const focusTrapState = createState(LudsFocusTrapStateToken);