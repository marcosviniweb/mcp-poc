import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { LudsFocusTrap } from './focus-trap';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'test-component',
  standalone: true,
  imports: [LudsFocusTrap, FormsModule],
  template: `
    <div>
      <button data-testid="outside-btn" id="outside-btn">Outside Button</button>
      <div ludsFocusTrap data-testid="focus-trap-container" data-focus-trap>
        <button data-testid="first-btn" id="first-btn">First Button</button>
        <input data-testid="input" id="input" type="text" />
        <button data-testid="last-btn" id="last-btn">Last Button</button>
      </div>
      <button data-testid="outside-btn-2">Outside Button 2</button>
    </div>
  `,
})
class TestComponent {
  autoFocus = true;
}

describe('LudsFocusTrap', () => {
  let fixture: ComponentFixture<TestComponent>;
  let firstButton: HTMLButtonElement;
  let input: HTMLInputElement;
  let lastButton: HTMLButtonElement;
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TestComponent, LudsFocusTrap, FormsModule],
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    fixture.detectChanges();
    
    firstButton = fixture.debugElement.query(By.css('#first-btn')).nativeElement;
    input = fixture.debugElement.query(By.css('#input')).nativeElement;
    lastButton = fixture.debugElement.query(By.css('#last-btn')).nativeElement;
  });
  
  it('should initialize correctly', () => {
    const container = fixture.debugElement.query(By.css('[data-focus-trap]')).nativeElement;
    expect(container).toBeDefined();
    expect(container.hasAttribute('data-focus-trap')).toBeTruthy();
  });

  it('should trap focus within the container', () => {
    // Focus the first button
    firstButton.focus();
    expect(document.activeElement).toBe(firstButton);
  });

  it('should support tab navigation within the trap', () => {
    // Focus the first button
    firstButton.focus();
    expect(document.activeElement).toBe(firstButton);
    
    // Simulate tab key - normally would focus the next element
    const tabEvent = new KeyboardEvent('keydown', {
      key: 'Tab',
      code: 'Tab',
      bubbles: true
    });
    firstButton.dispatchEvent(tabEvent);
    
    // Now focus the input manually to simulate what would happen
    input.focus();
    expect(document.activeElement).toBe(input);
  });

  it('should allow focus to be returned when pressing Escape', () => {
    // Focus the input
    input.focus();
    expect(document.activeElement).toBe(input);
    
    // Simulate Escape key
    const escapeEvent = new KeyboardEvent('keydown', {
      key: 'Escape',
      code: 'Escape',
      bubbles: true
    });
    
    const container = fixture.debugElement.query(By.css('[data-focus-trap]')).nativeElement;
    container.dispatchEvent(escapeEvent);
    
    // Just verify the event was dispatched without error
    fixture.detectChanges();
  });
});
