import { ClassProvider, inject, Injectable } from '@angular/core';
import type { LudsExitAnimation } from './exit-animation';

@Injectable()
export class LudsExitAnimationManager {
  /** Store the instances of the exit animation directive. */
  private readonly instances: LudsExitAnimation[] = [];

  /** Add an instance to the manager. */
  add(instance: LudsExitAnimation): void {
    this.instances.push(instance);
  }

  /** Remove an instance from the manager. */
  remove(instance: LudsExitAnimation): void {
    const index = this.instances.indexOf(instance);
    if (index !== -1) {
      this.instances.splice(index, 1);
    }
  }

  /** Exit all instances. */
  async exit(): Promise<void> {
    await Promise.all(this.instances.map(instance => instance.exit()));
  }
}

export function provideExitAnimationManager(): ClassProvider {
  return { provide: LudsExitAnimationManager, useClass: LudsExitAnimationManager };
}

export function injectExitAnimationManager(): LudsExitAnimationManager {
  return inject(LudsExitAnimationManager);
}