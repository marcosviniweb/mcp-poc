import { Component, ElementRef, Injector, OnDestroy } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { render } from '@testing-library/angular';
import { LudsExitAnimation, setupExitAnimation } from './exit-animation';
import { LudsExitAnimationManager, injectExitAnimationManager, provideExitAnimationManager } from './exit-animation-manager';

@Component({
  selector: 'test-component',
  standalone: true,
  imports: [],
  providers: [provideExitAnimationManager()],
  template: `
    <div data-testid="exit-animation-container">Exit Animation</div>
  `,
})
class TestComponent implements OnDestroy {
  private readonly exitAnimationManager = injectExitAnimationManager();
  
  ngOnDestroy(): void {
    // Clean up
  }
}

describe('LudsExitAnimation', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LudsExitAnimation],
      providers: [provideExitAnimationManager()],
    }).compileComponents();
  });

  it('should initialize correctly', () => {
    // Create a test host component that uses the directive
    @Component({
      template: '<div ludsExitAnimation></div>',
      standalone: true,
      imports: [LudsExitAnimation],
      providers: [provideExitAnimationManager()]
    })
    class TestHostComponent {}

    // Create the component
    const fixture = TestBed.createComponent(TestHostComponent);
    fixture.detectChanges();
    
    expect(fixture.componentInstance).toBeDefined();
    // Directive should be applied
    const element = fixture.nativeElement.querySelector('[LudsExitAnimation]');
    expect(element).toBeTruthy();
  });

  it('should register with the exit animation manager', () => {
    // Create a test host component that uses the directive
    @Component({
      template: '<div ludsExitAnimation></div>',
      standalone: true,
      imports: [LudsExitAnimation],
      providers: [provideExitAnimationManager()]
    })
    class TestHostComponent {}
    
    // Create the component
    const fixture = TestBed.createComponent(TestHostComponent);
    fixture.detectChanges();
    
    // Get the manager instance
    const manager = TestBed.inject(LudsExitAnimationManager);
    
    // Verify the component has rendered
    expect(fixture.componentInstance).toBeDefined();
    
    // Verify that the manager exists
    expect(manager).toBeDefined();
  });
});

describe('setupExitAnimation', () => {
  it('should create an exit animation reference', () => {
    const element = document.createElement('div');
    const elementRef = new ElementRef(element);
    
    const exitAnimationRef = setupExitAnimation({ element: elementRef.nativeElement });
    
    expect(exitAnimationRef).toBeDefined();
    expect(typeof exitAnimationRef.exit).toBe('function');
  });
});

describe('LudsExitAnimationManager', () => {
  it('should create an instance', () => {
    const manager = new LudsExitAnimationManager();
    expect(manager).toBeDefined();
  });

  it('should provide an exit animation manager', () => {
    const provider = provideExitAnimationManager();
    expect(provider).toBeDefined();
    expect(provider.provide).toEqual(LudsExitAnimationManager);
    expect(provider.useClass).toEqual(LudsExitAnimationManager);
  });
});
