import { Component } from '@angular/core';
import { render } from '@testing-library/angular';
import { injectElementRef } from './element-ref';

@Component({
  selector: 'test-component',
  standalone: true,
  template: `<div data-testid="test-element">Test Element</div>`,
})
class TestComponent {
  element = injectElementRef<HTMLDivElement>();
}

describe('injectElementRef', () => {
  it('should inject an element reference', async () => {
    const { fixture } = await render(TestComponent);
    const component = fixture.componentInstance;
    
    // Verify the element reference was injected
    expect(component.element).toBeDefined();
    expect(component.element.nativeElement instanceof HTMLElement).toBe(true);
  });
});
