import { DestroyRef, effect, inject, Injector, signal, Signal, untracked } from '@angular/core';
import { isUndefined, safeTakeUntilDestroyed } from '@luds/ui/blocks/utils';
import { map, Observable, Subscription } from 'rxjs';
import { explicitEffect } from '../signals/explicit-effect';
import { injectElementRef } from './element-ref';

interface LudsResizeObserverOptions {
  /**
   * Se deve escutar eventos.
   */
  disabled?: Signal<boolean>;

  /**
   * O injetor a ser usado quando chamado fora do contexto do injetor.
   */
  injector?: Injector;
}

/**
 * Uma função auxiliar simples para criar um observador de redimensionamento como um Observable RxJS.
 * @param element O elemento a ser observado para eventos de redimensionamento.
 * @returns O evento de redimensionamento como um Observable.
 */
export function fromResizeEvent(
  element: HTMLElement,
  { disabled = signal(false), injector }: LudsResizeObserverOptions = {},
): Observable<Dimensions> {
  return new Observable(observable => {
    // ResizeObserver pode não estar disponível em todos os ambientes, então verifica sua existência
    if (isUndefined(window?.ResizeObserver)) {
      // ResizeObserver não está disponível (SSR ou navegador não suportado)
      // Completa o observable sem emitir valores
      observable.complete();
      return;
    }

    let observer: ResizeObserver | null = null;

    function setupOrTeardownObserver() {
      if (disabled()) {
        if (observer) {
          observer.disconnect();
          observer = null;
        }
        return;
      }

      if (!observer) {
        observer = new ResizeObserver(entries => {
          // se não há entradas, ignora o evento
          if (!entries.length) {
            return;
          }

          // caso contrário, pega a primeira entrada e emite as dimensões
          const entry = entries[0];

          if ('borderBoxSize' in entry) {
            const borderSizeEntry = entry['borderBoxSize'];
            // isso pode ser diferente entre navegadores, então normaliza
            const borderSize = Array.isArray(borderSizeEntry)
              ? borderSizeEntry[0]
              : borderSizeEntry;

            observable.next({ width: borderSize['inlineSize'], height: borderSize['blockSize'] });
          } else {
            // fallback para navegadores que não suportam borderBoxSize
            observable.next({ width: element.offsetWidth, height: element.offsetHeight });
          }
        });

        observer.observe(element);
      }
    }

    setupOrTeardownObserver();

    explicitEffect([disabled], () => setupOrTeardownObserver(), { injector });

    return () => observer?.disconnect();
  });
}

/**
 * Uma função utilitária para observar qualquer elemento para eventos de redimensionamento e retornar as dimensões como um signal.
 */
export function observeResize(elementFn: () => HTMLElement | undefined): Signal<Dimensions> {
  const dimensions = signal<Dimensions>({ width: 0, height: 0 });
  const injector = inject(Injector);
  const destroyRef = inject(DestroyRef);

  // armazena a subscription do evento de redimensionamento
  let subscription: Subscription | null = null;

  effect(() => {
    const targetElement = elementFn();

    untracked(() => {
      if (!targetElement) {
        return;
      }

      // se já temos uma subscription, cancela ela
      subscription?.unsubscribe();

      // cria uma nova subscription para o evento de redimensionamento
      subscription = fromResizeEvent(targetElement, { injector })
        .pipe(safeTakeUntilDestroyed(destroyRef))
        .subscribe(event => dimensions.set({ width: event.width, height: event.height }));
    });
  });

  return dimensions;
}

export interface Dimensions {
  width: number;
  height: number;
}

/**
 * Um utilitário simples para obter as dimensões de um elemento como um signal.
 */
export function injectDimensions(): Signal<Dimensions> {
  const elementRef = injectElementRef<HTMLElement>();
  const destroyRef = inject(DestroyRef);
  const dimensions = signal<Dimensions>({ width: 0, height: 0 });

  fromResizeEvent(elementRef.nativeElement)
    .pipe(
      safeTakeUntilDestroyed(destroyRef),
      map(({ width, height }) => ({ width, height })),
    )
    .subscribe(event => dimensions.set(event));

  return dimensions;
}
