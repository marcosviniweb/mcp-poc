import { ElementRef, Renderer2, Signal, inject, signal } from '@angular/core';
import { injectDisposables } from '@luds/ui/blocks/utils';

export interface LudsFocusOptions {
  disabled?: Signal<boolean>;
  focus?: () => void;
  blur?: () => void;
}

export interface LudsFocusState {
  isFocused: Signal<boolean>;
}

export function setupFocus({
  focus,
  blur,
  disabled = signal(false),
}: LudsFocusOptions): LudsFocusState {
  /**
   * Access the element reference.
   */
  const elementRef = inject<ElementRef<HTMLElement>>(ElementRef);

  /**
   * Access the disposables helper.
   */
  const disposables = injectDisposables();

  /**
   * Access the renderer.
   */
  const renderer = inject(Renderer2);

  /**
   * Whether the element is currently focused.
   */
  const isFocused = signal<boolean>(false);

  // setup event listeners
  disposables.addEventListener(elementRef.nativeElement, 'focus', onFocus);
  disposables.addEventListener(elementRef.nativeElement, 'blur', onBlur);

  /**
   * Listen for focus events.
   * @param event
   */
  function onFocus(event: FocusEvent): void {
    if (disabled()) {
      return;
    }

    const ownerDocument = (event.target as HTMLElement)?.ownerDocument ?? document;

    // ensure this element is still focused
    if (ownerDocument.activeElement === event.target && event.currentTarget === event.target) {
      focus?.();
      isFocused.set(true);
      // set the data-focus attribute
      renderer.setAttribute(elementRef.nativeElement, 'data-focus', '');
    }
  }

  /**
   * Listen for blur events.
   * @param event
   */
  function onBlur(event: FocusEvent): void {
    if (disabled()) {
      return;
    }

    if (event.currentTarget === event.target) {
      blur?.();
      isFocused.set(false);
      // remove the data-focus attribute
      renderer.removeAttribute(elementRef.nativeElement, 'data-focus');
    }
  }

  return {
    isFocused,
  };
}
