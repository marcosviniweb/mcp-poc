import { Signal } from '@angular/core';
import { booleanAttributeBinding } from '@luds/ui/blocks/utils';
import { injectElementRef } from '../utilities/element-ref';
import { setupInteractions } from './interactions';

export interface LudsButtonOptions {
  /**
   * Indica se o botão está desabilitado.
   * @default false
   */
  disabled?: Signal<boolean>;
}

/**
 * Configura as interações e atributos do botão.
 *
 * @param options - As opções para o botão.
 */
export function setupButton({ disabled }: LudsButtonOptions): void {
  const elementRef = injectElementRef();
  const isButton = elementRef.nativeElement.tagName.toLowerCase() === 'button';

  setupInteractions({ hover: true, press: true, focusVisible: true, disabled });

  // adiciona o atributo `data-disabled` ao elemento
  booleanAttributeBinding(elementRef.nativeElement, 'data-disabled', disabled);

  // adiciona o atributo `disabled` ao elemento se ele for um botão
  if (isButton) {
    booleanAttributeBinding(elementRef.nativeElement, 'disabled', disabled);
  }
}
