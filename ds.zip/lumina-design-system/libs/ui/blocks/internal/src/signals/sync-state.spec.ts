import { Component, signal } from '@angular/core';
import { render } from '@testing-library/angular';
import { syncState } from './sync-state';

// Create a test component that uses the syncState function directly
@Component({
  standalone: true,
  template: '<div>Test Component</div>'
})
class TestSyncStateComponent {
  // Create signals in the component constructor (injection context)
  source = signal('initial');
  target = signal('target');
  
  constructor() {
    // Use syncState in the component context (proper injection context)
    syncState(this.source, this.target);
  }
}

// Component with multiple signals
@Component({
  standalone: true,
  template: '<div>Test Multiple Signals</div>'
})
class TestMultipleSignalsComponent {
  source1 = signal('source1');
  source2 = signal('source2');
  target1 = signal('target1');
  target2 = signal('target2');
  
  constructor() {
    // Use syncState for multiple signals
    syncState(this.source1, this.target1);
    syncState(this.source2, this.target2);
  }
}

describe('syncState', () => {
  it('should synchronize source signal value to target signal', async () => {
    // Create a component with syncState already set up
    const { fixture } = await render(TestSyncStateComponent);
    const component = fixture.componentInstance;
    
    // Verify initial value was synchronized
    expect(component.target()).toBe('initial');
    
    // Update the source
    component.source.set('updated');
    
    // Run change detection to trigger effects
    fixture.detectChanges();
    
    // Verify target was updated
    expect(component.target()).toBe('updated');
  });  it('should not cause infinite loops when used with multiple signals', async () => {
    // Create a component with multiple syncState already set up
    const { fixture } = await render(TestMultipleSignalsComponent);
    const component = fixture.componentInstance;
    
    // Verify initial values were synchronized
    expect(component.target1()).toBe('source1');
    expect(component.target2()).toBe('source2');
    
    // Update the sources
    component.source1.set('updated1');
    component.source2.set('updated2');
    
    // Run change detection to trigger effects
    fixture.detectChanges();
    
    // Verify targets were updated
    expect(component.target1()).toBe('updated1');
    expect(component.target2()).toBe('updated2');
  });
});
