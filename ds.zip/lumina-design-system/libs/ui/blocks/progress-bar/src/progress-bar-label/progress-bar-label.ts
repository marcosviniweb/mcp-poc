import { Directive, input } from '@angular/core';
import { uniqueId } from '@luds/ui/blocks/utils';
import { injectProgressBarState } from '../progress-bar/progress-bar-state';

@Directive({
  selector: '[ludsProgressBarLabel]',
  exportAs: 'ludsProgressBarLabel',
  standalone: true,
  host: {
    '[attr.data-progressing]': 'state().progressing() ? "" : null',
    '[attr.data-indeterminate]': 'state().indeterminate() ? "" : null',
    '[attr.data-complete]': 'state().complete() ? "" : null',
    '[attr.data-status]': 'state().status()',
    '[attr.data-variant]': 'state().variant()',
  },
})
export class LudsProgressBarLabel {
  /**
   * Acessa o estado do progresso.
   */
  protected readonly state = injectProgressBarState();

  /**
   * O identificador único para o rótulo do progresso.
   */
  readonly id = input<string>(uniqueId('luds-progress-bar-label'));

  constructor() {
    this.state().label.set(this);
  }
}
