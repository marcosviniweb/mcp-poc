import { computed, Directive } from '@angular/core';
import { injectProgressBarState } from '../progress-bar/progress-bar-state';

/**
 * Aplica a diretiva `ludsProgressBarIndicator` a um elemento que representa o progresso atual.
 * A largura deste elemento pode ser definida para a porcentagem do valor do progresso.
 */
@Directive({
  selector: '[ludsProgressBarIndicator]',
  standalone: true,
  host: {
    '[style.width.%]': 'percentage()',
    '[attr.data-progressing]': 'state().progressing() ? "" : null',
    '[attr.data-indeterminate]': 'state().indeterminate() ? "" : null',
    '[attr.data-complete]': 'state().complete() ? "" : null',
    '[attr.data-status]': 'state().status()',
    '[attr.data-variant]': 'state().variant()',
  },
})
export class LudsProgressBarIndicator {
  /**
   * Acessa o estado do progresso.
   */
  protected readonly state = injectProgressBarState();

  /**
   * Obtém a porcentagem do valor do progresso.
   */
  protected readonly percentage = computed(() => {
    const progressBar = this.state();
    const value = progressBar.effectiveValue();
    
    return value === null
      ? null
      : ((value - progressBar.min()) / (progressBar.max() - progressBar.min())) * 100;
  });
}
