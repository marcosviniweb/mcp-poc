import {
  createState,
  createStateInjector,
  createStateProvider,
  createStateToken,
} from '@luds/ui/blocks/state';
import type { LudsProgressBar } from './progress-bar';

/**
 * O token de estado para o primitivo Progress.
 */
export const LudsProgressBarStateToken = createStateToken<LudsProgressBar>('Progress');

/**
 * Fornece o estado do Progress.
 */
export const provideProgressBarState = createStateProvider(LudsProgressBarStateToken);

/**
 * Injeta o estado do Progress.
 */
export const injectProgressBarState = createStateInjector<LudsProgressBar>(LudsProgressBarStateToken);

/**
 * A função de registro do estado do Progress.
 */
export const progressBarState = createState(LudsProgressBarStateToken);
