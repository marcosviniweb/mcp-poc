import { render } from '@testing-library/angular';
import { LudsProgressBar } from './progress-bar';

describe('LudsProgressBar', () => {
  it('should set the aria attributes', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarValue="50"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress.getAttribute('role')).toBe('progressbar');
    expect(progress.getAttribute('aria-valuemax')).toBe('100');
    expect(progress.getAttribute('aria-valuemin')).toBe('0');
    expect(progress.getAttribute('aria-valuenow')).toBe('50');
    expect(progress.getAttribute('aria-valuetext')).toBe('50%');
  });

  it('should set the data-progressing attribute when value is between min and max', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarValue="50"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress).toHaveAttribute('data-progressing');
  });

  it('should not set the data-progressing attribute when value is equal to max', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarValue="100"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress).not.toHaveAttribute('data-progressing');
  });

  it('should not set the data-progressing attribute when value is equal to min', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarValue="0"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress).not.toHaveAttribute('data-progressing');
  });

  it('should set the data-indeterminate attribute when status is indeterminate', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarStatus="indeterminate"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress).toHaveAttribute('data-indeterminate');
    expect(progress.getAttribute('data-status')).toBe('indeterminate');
  });

  it('should not set the data-indeterminate attribute when status is not indeterminate', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarStatus="in-progress"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress).not.toHaveAttribute('data-indeterminate');
  });

  it('should set the data-complete attribute when value is equal to max', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarValue="100"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress).toHaveAttribute('data-complete');
  });

  it('should set the default label position to right', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress.getAttribute('data-label-position')).toBe('right');
  });

  it('should set the label position to top when specified', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarLabelPosition="top"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress.getAttribute('data-label-position')).toBe('top');
  });

  it('should set the label position to bottom when specified', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarLabelPosition="bottom"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress.getAttribute('data-label-position')).toBe('bottom');
  });

  it('should set the default status to in-progress', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress.getAttribute('data-status')).toBe('in-progress');
  });

  it('should set the status to error when specified', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarStatus="error"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress.getAttribute('data-status')).toBe('error');
  });

  it('should set the default track color to low-contrast', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress.getAttribute('data-variant')).toBe('low-contrast');
  });

  it('should set the track color to high-contrast when specified', async () => {
    const container = await render(
      `<div data-testid="progress" ludsProgressBar ludsProgressBarVariant="high-contrast"></div>`,
      { imports: [LudsProgressBar] },
    );

    const progress = container.getByTestId('progress');
    expect(progress.getAttribute('data-variant')).toBe('high-contrast');
  });

      it('should set aria-valuenow to null when status is indeterminate', async () => {
      const container = await render(
        `<div data-testid="progress" ludsProgressBar ludsProgressBarStatus="indeterminate"></div>`,
        { imports: [LudsProgressBar] },
      );

      const progress = container.getByTestId('progress');
      expect(progress.getAttribute('aria-valuenow')).toBeNull();
    });

    it('should set aria-valuetext to empty when status is indeterminate', async () => {
      const container = await render(
        `<div data-testid="progress" ludsProgressBar ludsProgressBarStatus="indeterminate"></div>`,
        { imports: [LudsProgressBar] },
      );

      const progress = container.getByTestId('progress');
      expect(progress.getAttribute('aria-valuetext')).toBe('');
    });

    it('should not be progressing when status is indeterminate', async () => {
      const container = await render(
        `<div data-testid="progress" ludsProgressBar ludsProgressBarStatus="indeterminate" ludsProgressBarValue="50"></div>`,
        { imports: [LudsProgressBar] },
      );

      const progress = container.getByTestId('progress');
      expect(progress).not.toHaveAttribute('data-progressing');
    });

    it('should not be complete when status is indeterminate', async () => {
      const container = await render(
        `<div data-testid="progress" ludsProgressBar ludsProgressBarStatus="indeterminate" ludsProgressBarValue="100"></div>`,
        { imports: [LudsProgressBar] },
      );

      const progress = container.getByTestId('progress');
      expect(progress).not.toHaveAttribute('data-complete');
    });
});
