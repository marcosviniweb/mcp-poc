import { NumberInput } from "@angular/cdk/coercion";
import { Directive, computed, input, numberAttribute, signal } from "@angular/core";
import { LudsProgressBarLabel } from "../progress-bar-label/progress-bar-label";
import { progressBarState, provideProgressBarState } from "./progress-bar-state";

/**
 * Aplica a diretiva `ludsProgressBar` a um elemento que representa o contêiner da barra de progresso.
 * Esta diretiva fornece gerenciamento de estado para rastreamento de progresso, posicionamento de rótulo e manipulação de status.
 * Use-a com outras diretivas de progresso como `ludsProgressBarTrack`, `ludsProgressBarIndicator` e `ludsProgressBarLabel`.
 */
@Directive({
  selector: "[ludsProgressBar]",
  providers: [provideProgressBarState()],
  standalone: true,
  host: {
    role: "progressbar",
    "[attr.aria-valuemax]": "state.max()",
    "[attr.aria-valuemin]": "0",
    "[attr.aria-valuenow]": "effectiveValue()",
    "[attr.aria-valuetext]": "valueText()",
    "[attr.aria-labelledby]": "label() ? label().id : null",
    "[attr.data-progressing]": 'progressing() ? "" : null',
    "[attr.data-indeterminate]": 'indeterminate() ? "" : null',
    "[attr.data-complete]": 'complete() ? "" : null',
    "[attr.data-label-position]": "state.labelPosition()",
    "[attr.data-status]": "state.status()",
    "[attr.data-variant]": "state.variant()",
  },
})
export class LudsProgressBar {
  /**
   * Define o valor do progresso.
   */
  readonly value = input<number | null, NumberInput>(0, {
    alias: "ludsProgressBarValue",
    transform: (v) => (v == null ? null : numberAttribute(v)),
  });

  /**
   * Define o valor mínimo do progresso.
   * @default '0'
   */
  readonly min = input<number, NumberInput>(0, {
    alias: "ludsProgressBarMin",
    transform: numberAttribute,
  });

  /**
   * Define o valor máximo do progresso.
   * @default 100
   */
  readonly max = input<number, NumberInput>(100, {
    alias: "ludsProgressBarMax",
    transform: numberAttribute,
  });

  /**
   * Define a posição do label do progresso.
   * @default 'right'
   */
  readonly labelPosition = input<LudsProgressBarLabelPosition>("right", {
    alias: "ludsProgressBarLabelPosition",
  });

  /**
   * Define o status do progresso.
   * @default 'in-progress'
   */
  readonly status = input<LudsProgressBarStatus>("in-progress", {
    alias: "ludsProgressBarStatus",
  });

  /**
   * Define a variante visual do progresso.
   * @default 'low-contrast'
   */
  readonly variant = input<LudsProgressBarVariant>("low-contrast", {
    alias: "ludsProgressBarVariant",
  });

  /**
   * Define uma função que retorna o rótulo do valor do progresso.
   * @param value O valor atual
   * @param max O valor máximo
   * @returns O rótulo do valor
   */
  readonly valueLabel = input<LudsProgressBarValueTextFn>((value, max) => `${Math.round((value / max) * 100)}%`, {
    alias: "ludsProgressBarValueLabel",
  });

  /**
   * Determina se o progresso é indeterminado.
   * @internal
   */
  readonly indeterminate = computed(() => this.state.status() === "indeterminate");

  /**
   * Obtém o valor efetivo do progresso.
   * Retorna null quando o status é indeterminate, independentemente do value fornecido.
   * @internal
   */
  readonly effectiveValue = computed(() => {
    if (this.indeterminate()) {
      return null;
    }
    return this.state.value();
  });

  /**
   * Determina se o progresso está em estado de progressão.
   * @internal
   */
  readonly progressing = computed(() => {
    const value = this.effectiveValue();
    return value != null && value > 0 && value < this.state.max();
  });

  /**
   * Determina se o progresso está completo.
   * @internal
   */
  readonly complete = computed(() => {
    const value = this.effectiveValue();
    return value === this.state.max();
  });

  /**
   * Obtém o texto do valor do progresso.
   */
  protected readonly valueText = computed(() => {
    const value = this.effectiveValue();

    if (value == null) {
      return "";
    }

    return this.state.valueLabel()(value, this.state.max());
  });

  /**
   * O rótulo associado à barra de progresso.
   * @internal
   */
  readonly label = signal<LudsProgressBarLabel | null>(null);

  /**
   * O estado da barra de progresso.
   * @internal
   */
  protected readonly state = progressBarState<LudsProgressBar>(this);
}

export type LudsProgressBarValueTextFn = (value: number, max: number) => string;

/**
 * A posição do label de progresso.
 */
export type LudsProgressBarLabelPosition = "top" | "right" | "bottom";

/**
 * O status do progresso.
 */
export type LudsProgressBarStatus = "error" | "in-progress" | "indeterminate";

/**
 * A variante visual do progresso.
 */
export type LudsProgressBarVariant = "low-contrast" | "high-contrast";
