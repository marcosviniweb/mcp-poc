import { Directive } from '@angular/core';
import { injectProgressBarState } from '../progress-bar/progress-bar-state';

@Directive({
  selector: '[ludsProgressBarTrack]',
  exportAs: 'ludsProgressBarTrack',
  standalone: true,
  host: {
    '[attr.data-progressing]': 'state().progressing() ? "" : null',
    '[attr.data-indeterminate]': 'state().indeterminate() ? "" : null',
    '[attr.data-complete]': 'state().complete() ? "" : null',
    '[attr.data-status]': 'state().status()',
    '[attr.data-variant]': 'state().variant()',
  },
})
export class LudsProgressBarTrack {
  /**
   * Acessa o estado do progresso.
   */
  protected readonly state = injectProgressBarState();
}
