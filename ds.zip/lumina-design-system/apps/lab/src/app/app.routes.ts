import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';

// Component imports
import { AlertComponent } from './components/alert/alert.component';
import { BadgeComponent } from './components/badge/badge.component';
import { ButtonComponent } from './components/button/button.component';
import { CardComponent } from './components/card/card.component';
import { CheckboxComponent } from './components/checkbox/checkbox.component';
import { ChipComponent } from './components/chip/chip.component';
import { DialogComponent } from './components/dialog/dialog.component';
import { FooterComponent } from './components/footer/footer.component';
import { FormFieldComponent } from './components/form-field/form-field.component';
import { ListboxComponent } from './components/listbox/listbox.component';
import { LoaderSpinnerComponent } from './components/loader-spinner/loader-spinner.component';
import { MenuComponent } from './components/menu/menu.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { NotificationComponent } from './components/notification/notification.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { PopoverComponent } from './components/popover/popover.component';
import { ProgressBarComponent } from './components/progress-bar/progress-bar.component';
import { RadioButtonComponent } from './components/radio-button/radio-button.component';
import { SwitchComponent } from './components/switch/switch.component';
import { TableComponent } from './components/table/table.component';
import { TabsComponent } from './components/tabs/tabs.component';
import { TagComponent } from './components/tag/tag.component';
import { UserMenuComponent } from './components/user-menu/user-menu.component';
import { WorkbenchComponent } from './components/workbench/workbench.component';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'alert', component: AlertComponent },
  { path: 'badge', component: BadgeComponent },
  { path: 'button', component: ButtonComponent },
  { path: 'card', component: CardComponent },
  { path: 'checkbox', component: CheckboxComponent },
  { path: 'chip', component: ChipComponent },
  { path: 'dialog', component: DialogComponent },
  { path: 'footer', component: FooterComponent },
  { path: 'form-field', component: FormFieldComponent },
  { path: 'listbox', component: ListboxComponent },
  { path: 'loader-spinner', component: LoaderSpinnerComponent },
  { path: 'menu', component: MenuComponent },
  { path: 'notification', component: NotificationComponent },
  { path: 'pagination', component: PaginationComponent },
  { path: 'popover', component: PopoverComponent },
  { path: 'progress-bar', component: ProgressBarComponent },
  { path: 'radio-button', component: RadioButtonComponent },
  { path: 'switch', component: SwitchComponent },
  { path: 'table', component: TableComponent },
  { path: 'tabs', component: TabsComponent },
  { path: 'tag', component: TagComponent },
  { path: 'user-menu', component: UserMenuComponent },
  { path: 'workbench', component: WorkbenchComponent },
  { path: '404', component: NotFoundComponent },
  { path: '**', redirectTo: '/404' }
];
