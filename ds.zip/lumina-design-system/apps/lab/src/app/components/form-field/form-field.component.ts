import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import {
  FormFieldDemoCharacterCounterComponent,
  FormFieldDemoCharacterCounterNativeComponent,
  FormFieldDemoDescriptionComponent,
  FormFieldDemoPasswordComponent,
  FormFieldDemoPrefixSufixComponent,
  FormFieldDemoReadonlyComponent,
  FormFieldDemoSearchComponent,
  FormFieldDemoVariantComponent,
  TextareaDemoComponent
} from "@luds/docs/form-field";
import { ComponentPageComponent } from "../component-page/component-page.component";
import { WorkbenchComponent } from "../workbench/workbench.component";

@Component({
  selector: "app-form-field",
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    FormFieldDemoDescriptionComponent,
    FormFieldDemoPasswordComponent,
    FormFieldDemoPrefixSufixComponent,
    FormFieldDemoReadonlyComponent,
    FormFieldDemoSearchComponent,
    FormFieldDemoVariantComponent,
    FormFieldDemoCharacterCounterNativeComponent,
    FormFieldDemoCharacterCounterComponent,
    TextareaDemoComponent
  ],
  templateUrl: "./form-field.component.html",
})
export class FormFieldComponent {}
