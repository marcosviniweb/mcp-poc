import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  LoaderSpinnerDemoButtonComponent,
  LoaderSpinnerDemoSizeComponent,
  LoaderSpinnerDemoVariantComponent,
  LoaderSpinnerDemoVariantNegativeComponent,
  LoaderSpinnerDemoCardComponent,
} from '@luds/docs/loader-spinner';

@Component({
  selector: 'app-loader-spinner',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    LoaderSpinnerDemoButtonComponent,
    LoaderSpinnerDemoSizeComponent,
    LoaderSpinnerDemoVariantComponent,
    LoaderSpinnerDemoVariantNegativeComponent,
    LoaderSpinnerDemoCardComponent,
  ],
  templateUrl: './loader-spinner.component.html',
})
export class LoaderSpinnerComponent {}
