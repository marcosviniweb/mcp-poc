import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  PopoverDemoComponent,
  PopoverPlacementDemoComponent,
  PopoverContextDemoComponent,
  PopoverProgrammaticDemoComponent,
  PopoverDelayDemoComponent,
} from '@luds/docs/popover';

@Component({
  selector: 'app-popover',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    PopoverDemoComponent,
    PopoverPlacementDemoComponent,
    PopoverContextDemoComponent,
    PopoverProgrammaticDemoComponent,
    PopoverDelayDemoComponent,
  ],
  templateUrl: './popover.component.html',
})
export class PopoverComponent {}
