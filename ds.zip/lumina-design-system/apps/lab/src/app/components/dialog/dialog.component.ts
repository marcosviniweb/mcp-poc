import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import {
  DialogDemo1Component,
  DialogDemo2Component,
  DialogDemo3Component,
  DialogDemoTriggerComponent
} from "@luds/docs/dialog";
import { WorkbenchComponent } from "../workbench/workbench.component";
import { ComponentPageComponent } from '../component-page/component-page.component';

@Component({
  selector: "app-dialog",
  standalone: true,
  imports: [
    CommonModule,
    DialogDemo1Component,
    DialogDemo2Component,
    DialogDemo3Component,
    DialogDemoTriggerComponent,
    WorkbenchComponent,
    ComponentPageComponent,
  ],
  templateUrl: "./dialog.component.html",
})
export class DialogComponent {}
