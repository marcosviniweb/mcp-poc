import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import {
  RadioHorizontalDemoComponent,
  RadioReactiveFormDemoComponent,
  RadioTitleAndContentDemoComponent,
  RadioVerticalDemoComponent,
} from "@luds/docs/radio-button";
import { ComponentPageComponent } from "../component-page/component-page.component";
import { WorkbenchComponent } from "../workbench/workbench.component";

@Component({
  selector: "app-radio-button",
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    RadioHorizontalDemoComponent,
    RadioReactiveFormDemoComponent,
    RadioTitleAndContentDemoComponent,
    RadioVerticalDemoComponent,
  ],
  templateUrl: "./radio-button.component.html",
})
export class RadioButtonComponent {}
