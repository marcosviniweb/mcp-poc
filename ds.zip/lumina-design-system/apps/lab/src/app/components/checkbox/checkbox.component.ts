import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  CheckboxDemoComponent,
  CheckboxReactiveFormsDemoComponent,
  ErrorCheckboxDemoComponent,
  SubgroupCheckboxDemoComponent,
} from '@luds/docs/checkbox';
import { ComponentPageComponent } from '../component-page/component-page.component';
import { WorkbenchComponent } from '../workbench/workbench.component';

@Component({
  selector: 'app-checkbox',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    CheckboxDemoComponent,
    CheckboxReactiveFormsDemoComponent,
    ErrorCheckboxDemoComponent,
    SubgroupCheckboxDemoComponent,
  ],
  templateUrl: './checkbox.component.html',
})
export class CheckboxComponent {}
