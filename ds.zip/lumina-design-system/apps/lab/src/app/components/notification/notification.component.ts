import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import { NotificationDemo, EmptyNotificationDemo } from '@luds/docs/notification';

@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    NotificationDemo,
    EmptyNotificationDemo,
  ],
  templateUrl: './notification.component.html',
})
export class NotificationComponent {}
