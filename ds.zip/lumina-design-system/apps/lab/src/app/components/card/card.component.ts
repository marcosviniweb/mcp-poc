import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { WorkbenchComponent } from "../workbench/workbench.component";
import { ComponentPageComponent } from "../component-page/component-page.component";
import {
  CardDemoSmallComponent,
  CardDemoMediumComponent,
  CardDemoLargeComponent,
  CardDemoLowContrastComponent,
  CardDemoExpandableComponent,
} from "@luds/docs/card";

@Component({
  selector: "app-card",
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    CardDemoSmallComponent,
    CardDemoMediumComponent,
    CardDemoLargeComponent,
    CardDemoLowContrastComponent,
    CardDemoExpandableComponent,
  ],
  templateUrl: "./card.component.html",
})
export class CardComponent {}
