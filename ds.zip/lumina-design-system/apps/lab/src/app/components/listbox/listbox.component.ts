import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  ListboxMultipleSelectionDemoComponent,
  ListboxSingleSelectionDemoComponent,
} from '@luds/docs/listbox';

@Component({
  selector: 'app-listbox',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    ListboxMultipleSelectionDemoComponent,
    ListboxSingleSelectionDemoComponent,
  ],
  templateUrl: './listbox.component.html',
})
export class ListboxComponent {}
