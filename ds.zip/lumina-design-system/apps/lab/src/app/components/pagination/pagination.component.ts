import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import { PaginationDemoComponent } from '@luds/docs/pagination';

@Component({
  selector: 'app-pagination',
  standalone: true,
  imports: [CommonModule, WorkbenchComponent, ComponentPageComponent, PaginationDemoComponent],
  templateUrl: './pagination.component.html',
})
export class PaginationComponent {}
