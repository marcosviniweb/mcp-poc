import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import { MenuDemo, MenuWithHorizontalHeaderDemo, MenuWithVerticalHeaderDemo, MenuWithSeparatorsDemo, MenuWithoutArrowDemo } from '@luds/docs/menu';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    MenuDemo,
    MenuWithHorizontalHeaderDemo,
    MenuWithVerticalHeaderDemo,
    MenuWithSeparatorsDemo,
    MenuWithoutArrowDemo
  ],
  templateUrl: './menu.component.html',
})
export class MenuComponent { }
