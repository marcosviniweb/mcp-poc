import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import { UserMenuDemo } from '@luds/docs/user-menu';

@Component({
  selector: 'app-user-menu',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    UserMenuDemo
  ],
  templateUrl: './user-menu.component.html',
})
export class UserMenuComponent {}
