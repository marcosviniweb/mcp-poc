import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NavigationService, NavigationItem } from '../../services/navigation.service';

@Component({
  selector: 'app-navigation',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent {
  private navigationService = inject(NavigationService);
  protected router = inject(Router);

  searchTerm = '';
  navigationItems: NavigationItem[] = [];
  filteredItems: NavigationItem[] = [];

  ngOnInit() {
    this.navigationItems = this.navigationService.getNavigationItems();
    this.filteredItems = [...this.navigationItems];
  }

  filterComponents() {
    if (!this.searchTerm.trim()) {
      this.filteredItems = [...this.navigationItems];
      return;
    }

    const searchLower = this.searchTerm.toLowerCase();
    this.filteredItems = this.navigationItems.filter(item =>
      item.label.toLowerCase().includes(searchLower) ||
      item.path.toLowerCase().includes(searchLower)
    );
  }
}
