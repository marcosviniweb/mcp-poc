import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { WorkbenchComponent } from "../workbench/workbench.component";
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  ChipDemoBadgeComponent,
  ChipDemoCloseableComponent,
  ChipDemoSizeComponent,
  ChipDemoVariantComponent,
} from "@luds/docs/chip";

@Component({
  selector: "app-chip",
  standalone: true,
  imports: [
    CommonModule,
    ChipDemoBadgeComponent,
    ChipDemoCloseableComponent,
    ChipDemoSizeComponent,
    ChipDemoVariantComponent,
    WorkbenchComponent,
    ComponentPageComponent,
  ],
  templateUrl: "./chip.component.html",
})
export class ChipComponent {}
