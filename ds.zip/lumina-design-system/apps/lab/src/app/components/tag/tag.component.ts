import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  TagBackgroundsDemoComponent,
  TagSizeMaxCharactersDemoComponent,
  TagSizesDemoComponent,
  TagTypesDemoComponent,
} from '@luds/docs/tag';

@Component({
  selector: 'app-tag',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    TagBackgroundsDemoComponent,
    TagSizeMaxCharactersDemoComponent,
    TagSizesDemoComponent,
    TagTypesDemoComponent,
  ],
  templateUrl: './tag.component.html',
})
export class TagComponent {}
