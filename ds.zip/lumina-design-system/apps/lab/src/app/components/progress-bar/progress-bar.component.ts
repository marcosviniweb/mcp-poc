import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  ProgressBarHighContrastDemoComponent,
  ProgressBarLabelPositionDemoComponent,
  ProgressBarLowContrastDemoComponent,
  ProgressBarStatusDemoComponent,

} from '@luds/docs/progress-bar';

@Component({
  selector: 'app-progress-bar',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    ProgressBarHighContrastDemoComponent,
    ProgressBarLabelPositionDemoComponent,
    ProgressBarLowContrastDemoComponent,
    ProgressBarStatusDemoComponent,

  ],
  templateUrl: './progress-bar.component.html',
})
export class ProgressBarComponent {}
