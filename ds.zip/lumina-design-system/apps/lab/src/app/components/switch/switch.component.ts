import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import {
  SwitchDemoComponent,
  SwitchFormFieldDemoComponent,
  SwitchFormFieldEventEmitDemoComponent,
} from "@luds/docs/switch";
import { ComponentPageComponent } from "../component-page/component-page.component";
import { WorkbenchComponent } from "../workbench/workbench.component";

@Component({
  selector: "app-switch",
  standalone: true,
  imports: [
    CommonModule,
    ComponentPageComponent,
    WorkbenchComponent,
    SwitchDemoComponent,
    SwitchFormFieldDemoComponent,
    SwitchFormFieldEventEmitDemoComponent,
  ],
  templateUrl: "./switch.component.html",
})
export class SwitchComponent {}
