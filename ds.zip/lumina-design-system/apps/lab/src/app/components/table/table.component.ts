import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  ColumnPinningTableDemoComponent,
  ColumnResizingTableDemoComponent,
  CompleteTableDemoComponent,
  CompleteTableServerSideDemoComponent,
  RowSelectionTableDemoComponent,
  ServerSidePaginationTableDemoComponent,
  SimplePaginationTableDemoComponent,
  SortingTableDemoComponent,
} from '@luds/docs/table';

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    ColumnPinningTableDemoComponent,
    ColumnResizingTableDemoComponent,
    CompleteTableDemoComponent,
    CompleteTableServerSideDemoComponent,
    RowSelectionTableDemoComponent,
    ServerSidePaginationTableDemoComponent,
    SimplePaginationTableDemoComponent,
    SortingTableDemoComponent,
  ],
  templateUrl: './table.component.html',
})
export class TableComponent {}
