import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  AlertBackgroundsDemoComponent,
  AlertSizesDemoComponent,
  AlertTypesDemoComponent,
} from '@luds/docs/alert';

@Component({
  selector: 'app-alert',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    AlertBackgroundsDemoComponent,
    AlertSizesDemoComponent,
    AlertTypesDemoComponent,
  ],
  templateUrl: './alert.component.html',
})
export class AlertComponent {}
