import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  FooterDemoComponent,
} from '@luds/docs/footer';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    FooterDemoComponent,
  ],
  templateUrl: './footer.component.html',
})
export class FooterComponent {}
