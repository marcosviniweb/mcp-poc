import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-workbench',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './workbench.component.html',
  styleUrl: './workbench.component.scss'
})
export class WorkbenchComponent {
  @Input() mode: 'column' | 'row' = 'column';
  @Input() title = ''
}
