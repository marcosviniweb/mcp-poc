import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkbenchComponent } from '../workbench/workbench.component';
import { ComponentPageComponent } from '../component-page/component-page.component';
import {
  ButtonDemoSizeDefaultComponent,
  ButtonDemoVariantPrimaryComponent,
  ButtonDemoWithIconsComponent,
  IconButtonDemoComponent,
} from '@luds/docs/button';

@Component({
  selector: 'app-button',
  standalone: true,
  imports: [
    ButtonDemoSizeDefaultComponent,
    ButtonDemoVariantPrimaryComponent,
    ButtonDemoWithIconsComponent,
    IconButtonDemoComponent,
    WorkbenchComponent,
    ComponentPageComponent,
    CommonModule,
  ],
  templateUrl: './button.component.html',
})
export class ButtonComponent {}
