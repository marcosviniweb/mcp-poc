import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import {
  TabsHorizontalDefaultDemoComponent,
  TabsHorizontalSmallDemoComponent,
  TabsVerticalDefaultDemoComponent,
  TabsVerticalSmallDemoComponent,
  TabsValueChangeDemoComponent,
} from "@luds/docs/tabs";
import { WorkbenchComponent } from "../workbench/workbench.component";
import { ComponentPageComponent } from '../component-page/component-page.component';

@Component({
  selector: "app-tabs",
  standalone: true,
  imports: [
    CommonModule,
    WorkbenchComponent,
    ComponentPageComponent,
    TabsValueChangeDemoComponent,
    TabsVerticalSmallDemoComponent,
    TabsHorizontalDefaultDemoComponent,
    TabsHorizontalSmallDemoComponent,
    TabsVerticalDefaultDemoComponent,
  ],
  templateUrl: "./tabs.component.html",
})
export class TabsComponent {}
