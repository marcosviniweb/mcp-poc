import { Injectable } from "@angular/core";

export interface NavigationItem {
  path: string;
  label: string;
  icon?: string;
}

@Injectable({
  providedIn: "root",
})
export class NavigationService {
  private navigationItems: NavigationItem[] = [
    { path: "/home", label: "Home", icon: "🏠" },
    { path: "/alert", label: "Alert", icon: "⚠️" },
    { path: "/badge", label: "Badge", icon: "🏷️" },
    { path: "/button", label: "Button", icon: "🔘" },
    { path: "/card", label: "Card", icon: "🃏" },
    { path: "/checkbox", label: "Checkbox", icon: "☑️" },
    { path: "/chip", label: "Chip", icon: "🔖" },
    { path: "/dialog", label: "Dialog", icon: "💬" },
    { path: "/footer", label: "Footer", icon: "⬇️" },
    { path: "/form-field", label: "Form Field", icon: "📝" },
    { path: "/listbox", label: "Listbox", icon: "📋" },
    { path: "/loader-spinner", label: "Loader Spinner", icon: "⏳" },
    { path: "/menu", label: "Menu", icon: "☰" },
    { path: "/notification", label: "Notification", icon: "🔔" },
    { path: "/pagination", label: "Pagination", icon: "📄" },
    { path: "/popover", label: "Popover", icon: "💭" },
    { path: "/progress-bar", label: "Progress Bar", icon: "📊" },
    { path: "/radio-button", label: "Radio Button", icon: "🔘" },
    { path: "/switch", label: "Switch", icon: "🔄" },
    { path: "/table", label: "Table", icon: "📋" },
    { path: "/tabs", label: "Tabs", icon: "📑" },
    { path: "/tag", label: "Tag", icon: "🏷️" },
    { path: "/user-menu", label: "User Menu", icon: "👤" },
  ];

  getNavigationItems(): NavigationItem[] {
    return this.navigationItems;
  }

  getNavigationItemByPath(path: string): NavigationItem | undefined {
    return this.navigationItems.find((item) => item.path === path);
  }
}
