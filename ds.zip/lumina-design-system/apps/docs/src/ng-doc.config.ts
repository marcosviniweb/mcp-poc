import { NgDocConfiguration } from '@ng-doc/builder';

const config: NgDocConfiguration = {
    cache: false,
};

export default config