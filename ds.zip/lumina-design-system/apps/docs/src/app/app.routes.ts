import { Route } from '@angular/router';

export const appRoutes: Route[] = [
    {
        path: '',
        redirectTo: '/development/installation',
        pathMatch: 'full'
    }
];
