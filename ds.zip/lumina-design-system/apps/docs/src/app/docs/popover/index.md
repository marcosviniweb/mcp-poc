{{ NgDocApi.details("libs/ui/blocks/popover/src/popover/popover.ts#LudsPopover") }}

{{ JSDoc.description("libs/ui/blocks/popover/src/popover/popover.ts#LudsPopover") }}

## Preview

{{ NgDocActions.demo("PopoverDemoComponent") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsPopover, LudsPopoverTrigger, LudsPopoverArrow } from '@luds/ui/blocks/popover';

@Component({
  standalone: true,
  imports: [LudsPopover, LudsPopoverTrigger, LudsPopoverArrow],
  templateUrl: './my-component.html',
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<button [ludsPopoverTrigger]="popoverContent">Clique aqui</button>

<ng-template #popoverContent>
  <div ludsPopover>
    <div ludsPopoverArrow></div>
    <p>Conteúdo do popover aqui</p>
  </div>
</ng-template>
```

## Configuração Global

Configure opções padrão para todos os popovers da aplicação usando a função `providePopoverConfig`:

```typescript name="app.config.ts" group="my-group2"
import { providePopoverConfig } from '@luds/ui/blocks/popover';

export const appConfig: ApplicationConfig = {
  providers: [
    providePopoverConfig({
      placement: 'top',
      offset: 8,
      showDelay: 0,
      hideDelay: 0,
      flip: true,
      shift: true,
      closeOnOutsideClick: true,
      closeOnEscape: true,
      scrollBehavior: 'reposition'
    }),
    // outros providers...
  ],
};
```

## Exemplos

### Posicionamento

{{ NgDocActions.demo("PopoverPlacementDemoComponent") }}

O popover suporta diferentes posicionamentos através da propriedade `ludsPopoverTriggerPlacement`:

- `top` - Acima do trigger
- `bottom` - Abaixo do trigger  
- `left` - À esquerda do trigger
- `right` - À direita do trigger
- `top-start`, `top-end` - Variações do topo
- `bottom-start`, `bottom-end` - Variações da base
- `left-start`, `left-end` - Variações da esquerda
- `right-start`, `right-end` - Variações da direita

### Contexto de Dados

{{ NgDocActions.demo("PopoverContextDemoComponent") }}

Passe dados para o popover usando `ludsPopoverTriggerContext`

### Controle Programático

{{ NgDocActions.demo("PopoverProgrammaticDemoComponent") }}

Controle o popover programaticamente através de eventos e monitore seu estado em tempo real.

### Delay de Exibição/Ocultação

{{ NgDocActions.demo("PopoverDelayDemoComponent") }}
