import { Component, signal } from "@angular/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { LudsPopover, LudsPopoverArrow, LudsPopoverTrigger } from "@luds/ui/blocks/popover";

@Component({
  selector: "popover-programmatic-demo",
  imports: [LudsPopoverTrigger, LudsPopover, LudsPopoverArrow, LudsButton],
  standalone: true,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      align-items: center;
    }
  `,
  template: `
    <button
      [ludsPopoverTrigger]="controlledPopover"
      (ludsPopoverTriggerOpenChange)="onPopoverStateChange($event)"
      variant="secondary"
      ludsButton
    >
      Popover Controlado (Cliques: {{ clickCount() }})
    </button>

    <ng-template #controlledPopover>
      <div ludsPopover>
        <div ludsPopoverHeader>
          <p class="luds-label-large-default">Número de vezes que foi aberto: {{ clickCount() }}</p>
        </div>
        <div ludsPopoverArrow></div>
      </div>
    </ng-template>
  `,
})
export class PopoverProgrammaticDemoComponent {
  protected readonly isOpen = signal(false);
  protected readonly clickCount = signal(0);

  protected onPopoverStateChange(open: boolean): void {
    this.isOpen.set(open);

    if (open) {
      this.clickCount.update((count) => count + 1);
    }
  }
}
