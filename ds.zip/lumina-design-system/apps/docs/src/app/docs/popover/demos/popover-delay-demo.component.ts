import { Component } from "@angular/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { LudsPopover, LudsPopoverArrow, LudsPopoverTrigger } from "@luds/ui/blocks/popover";

@Component({
  selector: "popover-delay-demo",
  imports: [LudsPopoverTrigger, LudsPopover, LudsPopoverArrow, LudsButton],
  standalone: true,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
    }
  `,
  template: `
    <button [ludsPopoverTrigger]="showDelay1000" [ludsPopoverTriggerShowDelay]="1000" variant="secondary" ludsButton>
      1s para Abrir
    </button>

    <button [ludsPopoverTrigger]="hideDelay1000" [ludsPopoverTriggerHideDelay]="1000" variant="secondary" ludsButton>
      1s para Fechar
    </button>

    <ng-template #showDelay1000>
      <div ludsPopover>
        <div ludsPopoverHeader>
          <h3 class="luds-body-large-bold">Delay de Exibição</h3>
          <p class="luds-label-large-default">Este popover aguardou 1 segundo antes de aparecer.</p>
        </div>
        <div ludsPopoverArrow></div>
      </div>
    </ng-template>

    <ng-template #hideDelay1000>
      <div ludsPopover>
        <div ludsPopoverHeader>
          <h3 class="luds-body-large-bold">Delay de Exibição</h3>
          <p class="luds-label-large-default">Este popover aguardará 1 segundo antes de fechar.</p>
        </div>
        <div ludsPopoverArrow></div>
      </div>
    </ng-template>
  `,
})
export class PopoverDelayDemoComponent {}
