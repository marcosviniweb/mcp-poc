import { Component } from "@angular/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { LudsPopover, LudsPopoverArrow, LudsPopoverTrigger, providePopoverConfig } from "@luds/ui/blocks/popover";

@Component({
  selector: "popover-placement-demo",
  imports: [LudsPopoverTrigger, LudsPopover, LudsPopoverArrow, LudsButton],
  providers: [
    providePopoverConfig({
      autoplacement: false,
    }),
  ],
  standalone: true,
  styles: `
    :host {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 2rem;
      padding: 3rem;
      place-items: center;
    }

    [ludsButton] {
      width: 120px;
      justify-content: center;
    }
  `,
  template: `
    <button
      [ludsPopoverTrigger]="topStartPopover"
      ludsPopoverTriggerPlacement="top-start"
      variant="secondary"
      ludsButton
    >
      Top Start
    </button>

    <button [ludsPopoverTrigger]="topPopover" ludsPopoverTriggerPlacement="top" variant="secondary" ludsButton>
      Top
    </button>

    <button [ludsPopoverTrigger]="topEndPopover" ludsPopoverTriggerPlacement="top-end" variant="secondary" ludsButton>
      Top End
    </button>

    <button [ludsPopoverTrigger]="leftPopover" ludsPopoverTriggerPlacement="left" variant="secondary" ludsButton>
      Left
    </button>

    <span></span>

    <button [ludsPopoverTrigger]="rightPopover" ludsPopoverTriggerPlacement="right" variant="secondary" ludsButton>
      Right
    </button>

    <button
      [ludsPopoverTrigger]="bottomStartPopover"
      ludsPopoverTriggerPlacement="bottom-start"
      variant="secondary"
      ludsButton
    >
      Bottom Start
    </button>

    <button [ludsPopoverTrigger]="bottomPopover" ludsPopoverTriggerPlacement="bottom" variant="secondary" ludsButton>
      Bottom
    </button>

    <button
      [ludsPopoverTrigger]="bottomEndPopover"
      ludsPopoverTriggerPlacement="bottom-end"
      variant="secondary"
      ludsButton
    >
      Bottom End
    </button>

    <ng-template #topStartPopover>
      <div ludsPopover>
        <div ludsPopoverArrow></div>
        <p class="luds-label-large-default">Popover no topo-início</p>
      </div>
    </ng-template>

    <ng-template #topPopover>
      <div ludsPopover>
        <div ludsPopoverArrow></div>
        <p class="luds-label-large-default">Popover no topo</p>
      </div>
    </ng-template>

    <ng-template #topEndPopover>
      <div ludsPopover>
        <div ludsPopoverArrow></div>
        <p class="luds-label-large-default">Popover no topo-fim</p>
      </div>
    </ng-template>

    <ng-template #leftPopover>
      <div ludsPopover>
        <div ludsPopoverArrow></div>
        <p class="luds-label-large-default">Popover à esquerda</p>
      </div>
    </ng-template>

    <ng-template #centerPopover>
      <div ludsPopover>
        <div ludsPopoverArrow></div>
        <p class="luds-label-large-default">Popover no centro</p>
      </div>
    </ng-template>

    <ng-template #rightPopover>
      <div ludsPopover>
        <div ludsPopoverArrow></div>
        <p class="luds-label-large-default">Popover à direita</p>
      </div>
    </ng-template>

    <ng-template #bottomStartPopover>
      <div ludsPopover>
        <div ludsPopoverArrow></div>
        <p class="luds-label-large-default">Popover na base-início</p>
      </div>
    </ng-template>

    <ng-template #bottomPopover>
      <div ludsPopover>
        <div ludsPopoverArrow></div>
        <p class="luds-label-large-default">Popover na base</p>
      </div>
    </ng-template>

    <ng-template #bottomEndPopover>
      <div ludsPopover>
        <div ludsPopoverArrow></div>
        <p class="luds-label-large-default">Popover na base-fim</p>
      </div>
    </ng-template>
  `,
})
export class PopoverPlacementDemoComponent {}
