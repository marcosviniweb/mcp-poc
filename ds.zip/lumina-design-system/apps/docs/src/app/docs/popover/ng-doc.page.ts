import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import {
  PopoverDemoComponent,
  PopoverPlacementDemoComponent,
  PopoverContextDemoComponent,
  PopoverProgrammaticDemoComponent,
  PopoverDelayDemoComponent
} from "./demos";

const Popover: NgDocPage = {
  title: `Popover`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  demos: {
    PopoverDemoComponent,
    PopoverPlacementDemoComponent,
    PopoverContextDemoComponent,
    PopoverProgrammaticDemoComponent,
    PopoverDelayDemoComponent
  },
};

export default Popover;
