import { CommonModule } from "@angular/common";
import { Component, signal } from "@angular/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { LudsPopover, LudsPopoverArrow, LudsPopoverTrigger } from "@luds/ui/blocks/popover";

interface UserData {
  id: number;
  name: string;
  email: string;
  role: string;
}

@Component({
  selector: "popover-context-demo",
  imports: [CommonModule, LudsPopoverTrigger, LudsPopover, LudsPopoverArrow, LudsButton],
  standalone: true,
  styles: `
    :host {
      display: flex;
      justify-content: center;
      align-items: center;
    }
  `,
  template: `
    <button
      [ludsPopoverTrigger]="userPopover"
      [ludsPopoverTriggerContext]="selectedUser()"
      variant="secondary"
      ludsButton
    >
      Ver Perfil de {{ selectedUser().name }}
    </button>

    <ng-template #userPopover let-user>
      <div ludsPopover>
        <div ludsPopoverHeader>
          <h3 class="luds-body-large-bold">{{ user().name }}</h3>
          <p class="luds-label-large-default">
            {{ user().role }}
          </p>
          <p class="luds-label-large-default">
            {{ user().email }}
          </p>
        </div>
        <div ludsPopoverContent>
          <button ludsButton variant="tertiary" size="small">Ver perfil completo</button>
        </div>
        <div ludsPopoverArrow></div>
      </div>
    </ng-template>
  `,
})
export class PopoverContextDemoComponent {
  protected readonly selectedUser = signal<UserData>({
    id: 1,
    name: "João Silva",
    email: "joao.silva@empresa.com",
    role: "Desenvolvedor Frontend",
  });
}
