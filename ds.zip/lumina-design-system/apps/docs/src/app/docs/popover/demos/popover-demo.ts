import { Component } from "@angular/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { LudsPopover, LudsPopoverArrow, LudsPopoverTrigger } from "@luds/ui/blocks/popover";

@Component({
  selector: "popover-demo",
  imports: [LudsPopoverTrigger, LudsPopover, LudsPopoverArrow, LudsButton],
  standalone: true,
  styles: `
    :host {
      display: flex;
      justify-content: center;
      gap: 1rem;
    }

    .demo-popover-content {
      gap: 1rem;
    }

    .demo-popover-content [ludsButton] {
      align-self: flex-end;
    }
  `,
  template: `
    <button [ludsPopoverTrigger]="popoverWithSubtitle" variant="secondary" ludsButton>Popover com subtítulo</button>
    <button
      [ludsPopoverTrigger]="popoverWithLabel"
      variant="secondary"
      ludsButton
      #popoverWithLabelTrigger="ludsPopoverTrigger"
    >
      Popover com label
    </button>

    <ng-template #popoverWithSubtitle>
      <div ludsPopover>
        <div ludsPopoverHeader data-direction="column">
          <h3 class="luds-body-large-bold">Precisa de ajuda?</h3>
          <p class="luds-label-large-default">
            Obtenha dicas e orientações rápidas sobre como usar esse recurso com eficiência. Confira nossa documentação
            para mais detalhes!
          </p>
        </div>
        <div ludsPopoverContent>
          <button ludsButton size="small">Saiba mais</button>
        </div>
        <div ludsPopoverArrow></div>
      </div>
    </ng-template>

    <ng-template #popoverWithLabel>
      <div ludsPopover>
        <div ludsPopoverHeader data-direction="row">
          <h3 class="luds-body-large-bold">Gerencie usuários</h3>
          <button ludsButton variant="tertiary" (click)="popoverWithLabelTrigger.hide()">Fechar</button>
        </div>
        <div ludsPopoverContent class="demo-popover-content">
          <p class="luds-label-large-default">
            Aqui você pode adicionar, editar ou remover usuários do sistema. Use os botões de ação para gerenciar
            permissões e perfis de acesso.
          </p>
          <button ludsButton variant="primary" size="small">Próximo</button>
        </div>
        <div ludsPopoverArrow></div>
      </div>
    </ng-template>
  `,
})
export class PopoverDemoComponent {}
