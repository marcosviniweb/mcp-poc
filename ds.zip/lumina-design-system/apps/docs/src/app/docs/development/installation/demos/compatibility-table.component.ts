import { Component } from "@angular/core";

@Component({
  imports: [],
  standalone: true,
  template: `<div ludsTableContainer>
    <table ludsTable>
      <thead></thead>
      <tbody>
        <tr>
          <td>Lumina DS</td>
          <td>Angular</td>
        </tr>
        <tr>
          <td>>=1.0.0</td>
          <td>18.0.0</td>
        </tr>
      </tbody>
    </table>
  </div>`,
})
export class CompatibilityTableDemoComponent {}
