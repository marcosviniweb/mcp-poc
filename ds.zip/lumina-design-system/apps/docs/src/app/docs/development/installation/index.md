Este guia tem como objetivo orientar desenvolvedores na **instalação e integração do Lumina Design System** em projetos Angular, assegurando uma experiência consistente, eficiente e alinhada às diretrizes visuais e funcionais da Lumina.

### Compatibilidade

{{ NgDocActions.demo("CompatibilityTableDemoComponent", { container: false }) }}

### Configurações do registry privado

O Lumina Design System está hospedado em um registry privado.
Para acessá-lo, configure o arquivo .npmrc na raiz do seu projeto com as seguintes informações:

```
registry=https://nexus.devsecops-paas-prd.br.experian.eeca/repository/npm-group-repository/
strict-ssl=false
```

### Instalação

Com o registry configurado, instale o pacote do Lumina Design System via NPM:

```
npm install @luds/ui@latest
```

### Dependencies

O Lumina possui algumas dependências paralelas que precisam ser instaladas para garantir seu funcionamento completo. Se você estiver utilizando o NPM na versão 7 ou superior, essas dependências serão instaladas automaticamente. Caso esteja usando uma versão anterior do NPM ou outro gerenciador de pacotes, pode ser necessário realizar a instalação manual dessas dependências.

{{ NgDocActions.demo("DependenciesTableDemoComponent", { container: false }) }}

Para instalar as dependências, execute o seguinte comando:

```
npm i @angular/cdk@^18.0.0 @tanstack/angular-table @floating-ui/dom@^1.6.0
```

### Configuração de tema

Você deve incluir o tema base do Lumina importando o arquivo **styles.scss** diretamente no seu arquivo principal de estilos:

```
@use '@luds/ui/styles/themes/default';
// outros estilos...
```

### Arquitetura do Lumina Design System

O Lumina é composto por duas camadas principais que atuam de forma integrada para oferecer uma experiência de desenvolvimento consistente, eficiente e escalável.

#### @luds/ui/styles

A camada base que contém todos os **tokens de design** e **temas** organizados de forma modular:

- Tokens de cor, tipografia, espaçamento e breakpoints
- Sistema de camadas CSS para controle de especificidade
- Utilitários CSS gerados automaticamente

#### @luds/ui/blocks

A camada que contém **diretivas e componentes modulares** altamente personalizáveis:

- Diretivas standalone com signals para reatividade
- Componentes focados em uma única responsabilidade
- Seguindo diretrizes de acessibilidade (WCAG)
- Cada bloco é independente e pode ser importado individualmente

#### @luds/ui/components

A camada que contém componentes compostos e fechados:

- Simplicidade de importação
- Componentes focados em reutilização
- Componentes "as is" do figma

Esta arquitetura permite que você importe apenas os componentes necessários, otimizando o bundle final da aplicação através do tree-shaking automático.

### Camada CSS

#### Especificidade

O `@layer` é um recurso nativo do CSS que permite definir camadas em cascata com ordem de precedência personalizada. Este recurso é fundamental para controlar a especificidade dos estilos. Se você não estiver familiarizado com camadas CSS, consulte a [documentação do MDN](https://developer.mozilla.org/en-US/docs/Web/CSS/@layer) para começar.

**Importante:** CSS que **NÃO** está dentro de uma camada (`@layer`) sempre terá a maior especificidade. Isso significa que você conseguirá sobrescrever qualquer estilo dos componentes do Lumina, independentemente da ordem ou especificidade das classes.

#### Reset CSS

Se os componentes do Lumina estão apresentando problemas visuais em sua aplicação, um CSS de Reset pode estar causando conflitos. A solução é usar camadas CSS para encapsular seu código de Reset, evitando que ele interfira nos estilos dos componentes do design system.

Como implementar:

```
/* No seu arquivo styles.scss */

@layer reset {
  /* Coloque todo seu código de Reset CSS aqui */
}
```

Ao fazer isso, o CSS de Reset ficará isolado em sua própria camada, não interferindo nos estilos dos componentes do Lumina.

### Boas práticas

- Siga sempre a documentação oficial ao utilizar os componentes, garantindo consistência visual e funcional em toda a aplicação.
- Mantenha o Lumina Design System atualizado para se beneficiar de correções, melhorias e novos recursos.
- Evite sobrescrever estilos diretamente nos componentes. Utilize os tokens e variáveis disponibilizados pelo sistema para manter a padronização e facilitar a manutenção.
