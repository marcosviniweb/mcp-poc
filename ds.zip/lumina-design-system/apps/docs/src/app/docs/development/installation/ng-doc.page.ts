import { NgDocPage } from "@ng-doc/core";
import DevelopmentCategory from "apps/docs/src/categories/development/ng-doc.category";
import { CompatibilityTableDemoComponent } from "./demos/compatibility-table.component";
import { DependenciesTableDemoComponent } from "./demos/dependecies-table.component";

/**
 * @status:info NEW
 */
const Installation: NgDocPage = {
  title: `Instalação`,
  mdFile: "./index.md",
  category: DevelopmentCategory,
  demos: { CompatibilityTableDemoComponent, DependenciesTableDemoComponent },
};

export default Installation;
