import { Component } from "@angular/core";

@Component({
  imports: [],
  standalone: true,
  template: ` <div ludsTableContainer>
    <table ludsTable>
      <thead></thead>
      <tbody>
        <tr>
          <td>&#64;angular/cdk</td>
          <td>^18.0.0</td>
        </tr>
        <tr>
          <td>&#64;tanstack/angular-table</td>
          <td>^8.21.3</td>
        </tr>
        <tr>
          <td>&#64;floating-ui/dom</td>
          <td>>=1.6.0</td>
        </tr>
      </tbody>
    </table>
  </div>`,
})
export class DependenciesTableDemoComponent {}
