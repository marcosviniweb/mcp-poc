{{ NgDocApi.details("libs/ui/blocks/input/src/input/input.ts#LudsInput") }}

{{ JSDoc.description("libs/ui/blocks/input/src/input/input.ts#LudsInput") }}

## Playground

{{ NgDocActions.playground("FormFieldPlayground") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsInput } from "@luds/ui/blocks/input";
import {
  LudsFormFieldPrefix,
  LudsFormFieldSuffix,
  LudsError,
  LudsLabel,
  LudsDescription,
  ludsFormField,
} from "@luds/ui/blocks/form-field";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorUser, phosphorHouse } from "@ng-icons/phosphor-icons/regular";

@Component({
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    LudsInput,
    LudsFormField,
    LudsLabel,
    LudsError,
    LudsDescription,
    LudsFormFieldSuffix,
    LudsFormFieldPrefix,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorUser, phosphorHouse })],
  templateUrl: "./my-component.html",
})
export class MyComponent {
  readonly formGroup = new FormGroup({
    fullName: new FormControl({ disabled: false, value: "" }, Validators.required),
    address: new FormControl({ disabled: false, value: "" }, Validators.required),
  });
}
```

```html name="my-component.html" group="my-group1"
<form [formGroup]="formGroup">
  <div ludsFormField>
    <label ludsLabel class="luds-body-medium-default">Nome Completo</label>
    <ng-icon ludsFormFieldPrefix name="phosphorUser"></ng-icon>
    <input ludsInput type="text" placeholder="Digite seu nome completo" formControlName="fullName" />
    <p ludsDescription class="luds-label-medium-default">Por favor, inclua seu nome completo.</p>
    <p ludsError ludsErrorValidator="required" class="luds-label-medium-default">Campo obrigatório.</p>
  </div>

  <div ludsFormField>
    <label ludsLabel class="luds-body-medium-default">Endereço</label>
    <ng-icon ludsFormFieldSuffix name="phosphorHouse"></ng-icon>
    <input ludsInput type="text" placeholder="Digite seu endereço" formControlName="address" />
    <p ludsDescription class="luds-label-medium-default">Por favor, inclua seu endereço.</p>
    <p ludsError ludsErrorValidator="required" class="luds-label-medium-default">Campo obrigatório.</p>
  </div>
</form>
```

## Exemplos

### Variantes

{{ NgDocActions.demo("FormFieldDemoVariantComponent") }}
Veja a documentação da API: `ludsInputVariant`

### Texto, descrição e erro

{{ NgDocActions.demo("FormFieldDemoDescriptionComponent") }}
Veja a documentação da API: `ludsLabel` `ludsDescription` `ludsError`

### Ícones

{{ NgDocActions.demo("FormFieldDemoPrefixSufixComponent") }}
Veja a documentação da API: `ludsFormFieldSuffix` `ludsFormFieldPrefix`

### Input Search

{{ NgDocActions.demo("FormFieldDemoSearchComponent") }}
Veja a documentação da API: `ludsSearch`

### Input Password

{{ NgDocActions.demo("FormFieldDemoPasswordComponent") }}
Veja a documentação da API: `ludsPasswordToggle` `ludsPasswordHidden` `ludsPasswordVisible` `ludsRule`

### Contador de Caracteres

#### Angular Validators

{{ NgDocActions.demo("FormFieldDemoCharacterCounterComponent") }}
Veja a documentação da API: `ludsCharacterCounter`

#### maxLength nativo

{{ NgDocActions.demo("FormFieldDemoCharacterCounterNativeComponent") }}
Veja a documentação da API: `ludsCharacterCounter`

### Apenas leitura

{{ NgDocActions.demo("FormFieldDemoReadonlyComponent") }}

### Textarea

{{ NgDocActions.demo("TextareaDemoComponent") }}
