import { CommonModule } from "@angular/common";
import { ChangeDetectionStrategy, Component } from "@angular/core";
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { LudsCharacterCounter, LudsDescription, LudsError, LudsFormField, LudsLabel } from "@luds/ui/blocks/form-field";
import { LudsTextarea } from "@luds/ui/blocks/textarea";

@Component({
  selector: "textarea-demo",
  standalone: true,
  imports: [
    ReactiveFormsModule,
    CommonModule,
    LudsFormField,
    LudsLabel,
    LudsError,
    LudsTextarea,
    LudsDescription,
    LudsCharacterCounter,
  ],
  template: `
    <div [formGroup]="formGroup" ludsFormField>
      <label ludsLabel class="luds-body-medium-default">Comentário</label>
      <textarea
        ludsTextarea
        placeholder="Por favor digite seu comentário"
        formControlName="comment"
        maxlength="90"
      ></textarea>
      <div ludsFormFieldFeedback>
        <p ludsDescription class="luds-label-medium-default">Por favor deixe comentários construtivos.</p>
        <p ludsError ludsErrorValidator="required" class="luds-label-medium-default">Esse campo é obrigatório.</p>
        <div ludsCharacterCounter #characterCounter="ludsCharacterCounter">
          <p class="luds-label-medium-default">
            {{ characterCounter.currentCount() }} / {{ characterCounter.maxLength() }}
          </p>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TextareaDemoComponent {
  protected readonly formGroup = new FormGroup({
    comment: new FormControl("", Validators.required),
  });
}
