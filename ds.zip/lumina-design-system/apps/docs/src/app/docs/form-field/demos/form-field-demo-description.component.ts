import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";
import { LudsDescription, LudsError, LudsFormField, LudsLabel } from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";
import { phosphorXCircle } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "form-field-demo-description",
  imports: [
    FormsModule,
    LudsInput,
    ReactiveFormsModule,
    CommonModule,
    LudsFormField,
    LudsLabel,
    LudsError,
    LudsDescription,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorXCircle })],
  template: `
    <div [formGroup]="formGroup" ludsFormField>
      <label ludsLabel class="luds-body-medium-default">Email</label>
      <input ludsInput type="text" placeholder="Digite seu email" formControlName="fullName" />
      <div ludsFormFieldFeedback>
        <p ludsDescription class="luds-label-medium-default">Por favor, insira seu email.</p>
        <p ludsError ludsErrorValidator="required" class="luds-label-medium-default">
          <ng-icon ludsRuleFailIcon name="phosphorXCircle"></ng-icon>
          Campo obrigatório.
        </p>
        <p ludsError ludsErrorValidator="email" class="luds-label-medium-default">
          <ng-icon ludsRuleFailIcon name="phosphorXCircle"></ng-icon>
          Insira um email válido.
        </p>
      </div>
    </div>
  `,
  standalone: true,
})
export class FormFieldDemoDescriptionComponent {
  readonly formGroup = new FormGroup({
    fullName: new FormControl({ disabled: false, value: "" }, [Validators.required, Validators.email]),
  });
}
