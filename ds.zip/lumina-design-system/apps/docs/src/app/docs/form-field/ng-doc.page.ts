import { LudsFormField, LudsFormFieldPrefix, LudsFormFieldSuffix, LudsLabel } from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import {
  FormFieldDemoCharacterCounterComponent,
  FormFieldDemoCharacterCounterNativeComponent,
  FormFieldDemoDescriptionComponent,
  FormFieldDemoPasswordComponent,
  FormFieldDemoPrefixSufixComponent,
  FormFieldDemoReadonlyComponent,
  FormFieldDemoSearchComponent,
  FormFieldDemoVariantComponent,
  TextareaDemoComponent
} from "./demos";
import { phosphorUser } from "@ng-icons/phosphor-icons/regular";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

const FormField: NgDocPage = {
  title: `Input`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  demos: {
    FormFieldDemoPrefixSufixComponent,
    FormFieldDemoDescriptionComponent,
    FormFieldDemoVariantComponent,
    FormFieldDemoSearchComponent,
    FormFieldDemoPasswordComponent,
    FormFieldDemoReadonlyComponent,
    FormFieldDemoCharacterCounterComponent,
    FormFieldDemoCharacterCounterNativeComponent,
    TextareaDemoComponent
  },
  imports: [ReactiveFormsModule, FormsModule, LudsFormField, LudsLabel, LudsFormFieldPrefix, LudsFormFieldSuffix, NgIcon],
  providers: [provideIcons({ phosphorUser })],
  playgrounds: {
    FormFieldPlayground: {
      target: LudsInput,
      hiddenInputs: ["id", "disabled"],
      template: `
      <form ludsFormField>
        <label ludsLabel class="luds-body-medium-default">Nome Completo</label>
        {{ content.iconLeft }}
        {{ content.iconRight }}
        <ng-doc-selector placeholder="Digite seu nome"></ng-doc-selector>
        <div ludsFormFieldFeedback>
          <p ludsDescription class="luds-label-medium-default">
            Digite seu nome completo.
          </p>
        </div>
      </form>
        `,
      content: {
        iconRight: {
          label: "icone à direita",
          template: '<ng-icon ludsFormFieldSuffix  name="phosphorUser"></ng-icon>',
        },
        iconLeft: {
          label: "icone à esquerda",
          template: '<ng-icon ludsFormFieldPrefix  name="phosphorUser"></ng-icon>',
        },
      },
    },
  },
};

export default FormField;
