import { ChangeDetectionStrategy, Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import {
  AbstractControl,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  ValidationErrors,
  Validators,
} from "@angular/forms";
import {
  LudsFormField,
  LudsFormFieldSuffix,
  LudsLabel,
  LudsPasswordHidden,
  LudsPasswordToggle,
  LudsPasswordVisible,
  LudsRule,
} from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";
import { phosphorEye, phosphorEyeSlash, phosphorXCircle, phosphorCheckCircle } from "@ng-icons/phosphor-icons/regular";

// Custom validator for password requirements
function passwordValidator(control: AbstractControl): ValidationErrors | null {
  const value = control.value;

  const hasNumber = /[0-9]/.test(value);
  const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const isValidLength = value.length >= 8 && value.length <= 20;

  const errors: ValidationErrors = {};

  if (!isValidLength) {
    errors["length"] = true;
  }
  if (!hasNumber) {
    errors["number"] = true;
  }
  if (!hasSpecialChar) {
    errors["specialChar"] = true;
  }
  if (!hasUpperCase) {
    errors["upperCase"] = true;
  }
  if (!hasLowerCase) {
    errors["lowerCase"] = true;
  }

  return Object.keys(errors).length ? errors : null;
}

@Component({
  selector: "form-field-demo-password",
  standalone: true,
  imports: [
    FormsModule,
    LudsInput,
    ReactiveFormsModule,
    LudsFormField,
    LudsLabel,
    LudsPasswordToggle,
    LudsFormFieldSuffix,
    LudsPasswordVisible,
    LudsPasswordHidden,
    LudsRule,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorEye, phosphorEyeSlash, phosphorXCircle, phosphorCheckCircle })],
  template: `
    <form [formGroup]="formGroup">
      <div ludsFormField>
        <label ludsLabel class="luds-body-medium-default">Digite sua senha</label>
        <input ludsInput type="password" formControlName="password" />
        <button ludsPasswordToggle ludsFormFieldSuffix>
          <ng-icon ludsPasswordHidden name="phosphorEye"></ng-icon>
          <ng-icon ludsPasswordVisible name="phosphorEyeSlash"></ng-icon>
        </button>
        <div ludsFormFieldFeedback>
          <p ludsRule ludsRuleValidator="length" class="luds-label-medium-default">
            <ng-icon ludsRuleFailIcon name="phosphorXCircle"></ng-icon>
            <ng-icon ludsRulePassIcon name="phosphorCheckCircle"></ng-icon>
            A senha deve conter de 8 a 20 caracteres
          </p>
          <p ludsRule ludsRuleValidator="number" class="luds-label-medium-default">
            <ng-icon ludsRuleFailIcon name="phosphorXCircle"></ng-icon>
            <ng-icon ludsRulePassIcon name="phosphorCheckCircle"></ng-icon>
            Ter pelo menos 1 número
          </p>
          <p ludsRule ludsRuleValidator="specialChar" class="luds-label-medium-default">
            <ng-icon ludsRuleFailIcon name="phosphorXCircle"></ng-icon>
            <ng-icon ludsRulePassIcon name="phosphorCheckCircle"></ng-icon>
            Ter pelo menos um caractere especial (Ex.: # &#64; $ % ! * & ?)
          </p>
          <p ludsRule ludsRuleValidator="lowerCase" class="luds-label-medium-default">
            <ng-icon ludsRuleFailIcon name="phosphorXCircle"></ng-icon>
            <ng-icon ludsRulePassIcon name="phosphorCheckCircle"></ng-icon>
            Ter pelo menos uma letra minúscula
          </p>
          <p ludsRule ludsRuleValidator="upperCase" class="luds-label-medium-default">
            <ng-icon ludsRuleFailIcon name="phosphorXCircle"></ng-icon>
            <ng-icon ludsRulePassIcon name="phosphorCheckCircle"></ng-icon>
            Ter pelo menos uma letra maiúscula
          </p>
        </div>
      </div>
    </form>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormFieldDemoPasswordComponent {
  protected readonly formGroup = new FormGroup({
    password: new FormControl("", [Validators.required, passwordValidator]),
  });
}
