import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsFormField, LudsFormFieldPrefix, LudsLabel } from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";
import { phosphorUser } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "form-field-demo-variant",
  imports: [LudsInput, CommonModule, LudsFormField, LudsLabel, LudsFormFieldPrefix, NgIcon],
  providers: [provideIcons({ phosphorUser })],
  template: `
    <div ludsFormField>
      <ng-icon ludsFormFieldPrefix name="phosphorUser"></ng-icon>
      <label ludsLabel class="luds-body-medium-default">Default</label>
      <input ludsInput type="text" />
      <div ludsFormFieldFeedback>
        <p ludsDescription class="luds-label-medium-default">Input com variante default.</p>
      </div>
    </div>

    <div ludsFormField>
      <ng-icon ludsFormFieldPrefix name="phosphorUser"></ng-icon>
      <label ludsLabel class="luds-body-medium-default">White</label>
      <input ludsInput type="text" variant="white" />
      <div ludsFormFieldFeedback>
        <p ludsDescription class="luds-label-medium-default">Input com variante white.</p>
      </div>
    </div>
  `,
  standalone: true,
})
export class FormFieldDemoVariantComponent {}
