import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { FormControl, FormGroup, ReactiveFormsModule } from "@angular/forms";
import { LudsCharacterCounter, LudsFormField, LudsLabel } from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";

@Component({
  selector: "form-field-demo-character-counter-native",
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, LudsInput, LudsFormField, LudsLabel, LudsCharacterCounter],
  template: `
    <form [formGroup]="formGroup">
      <div ludsFormField>
        <label ludsLabel class="luds-body-medium-default">Contador de caracteres</label>
        <input ludsInput formControlName="text" maxlength="25" />
        <div ludsFormFieldFeedback>
          <p ludsDescription class="luds-label-medium-default">Tamanho máximo de 25 caracteres.</p>

          <div ludsCharacterCounter #characterCounter="ludsCharacterCounter">
            <p class="luds-label-medium-default">
              {{ characterCounter.currentCount() }} / {{ characterCounter.maxLength() }}
            </p>
          </div>
        </div>
      </div>
    </form>
  `,
})
export class FormFieldDemoCharacterCounterNativeComponent {
  protected readonly formGroup = new FormGroup({
    text: new FormControl(""),
  });
}
