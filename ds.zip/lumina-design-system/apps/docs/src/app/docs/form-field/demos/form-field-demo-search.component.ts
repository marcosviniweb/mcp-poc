import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { LudsFormField, LudsFormFieldSuffix, LudsLabel } from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";
import { LudsSearch } from "@luds/ui/blocks/search";
import { phosphorMagnifyingGlass } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "form-field-demo-search",
  imports: [
    FormsModule,
    LudsInput,
    ReactiveFormsModule,
    LudsFormFieldSuffix,
    CommonModule,
    LudsFormField,
    LudsLabel,
    LudsSearch,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorMagnifyingGlass })],
  template: `
    <form [formGroup]="formGroup">
      <div ludsFormField ludsSearch>
        <label ludsLabel class="luds-body-medium-default">Pesquise por</label>
        <ng-icon ludsFormFieldSuffix name="phosphorMagnifyingGlass"></ng-icon>
        <input ludsInput type="search" formControlName="search" />
      </div>
    </form>
  `,
  standalone: true,
})
export class FormFieldDemoSearchComponent {
  readonly formGroup = new FormGroup({
    search: new FormControl({ disabled: false, value: "" }),
  });
}
