import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { LudsFormField, LudsLabel } from '@luds/ui/blocks/form-field';
import { LudsInput } from '@luds/ui/blocks/input';

@Component({
  selector: 'form-field-demo-readonly',
  imports: [
    FormsModule,
    LudsInput,
    ReactiveFormsModule,
    CommonModule,
    LudsFormField,
    LudsLabel,
  ],
  template: `
    <form [formGroup]="formGroup">
      <div ludsFormField>
        <label ludsLabel class="luds-body-medium-default">Nome Completo</label>
        <input ludsInput formControlName="text" readonly />
      </div>
    </form>
  `,
  standalone: true,
})
export class FormFieldDemoReadonlyComponent {
  readonly formGroup = new FormGroup({
    text: new FormControl({ disabled: false, value: '' }),
  });
}
