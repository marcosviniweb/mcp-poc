import { CommonModule } from "@angular/common";
import { ChangeDetectionStrategy, Component, signal } from "@angular/core";
import { NgIcon, provideIcons } from '@ng-icons/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { LudsCharacterCounter, LudsError, LudsFormField, LudsLabel } from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";
import { phosphorXCircle } from '@ng-icons/phosphor-icons/regular';

@Component({
  selector: "form-field-demo-character-counter",
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, LudsInput, LudsFormField, LudsLabel, LudsError, LudsCharacterCounter, NgIcon],
  providers: [provideIcons({ phosphorXCircle })],
  template: `
    <form [formGroup]="formGroup">
      <div ludsFormField>
        <label ludsLabel class="luds-body-medium-default">Contador de caracteres</label>
        <input ludsInput formControlName="text" />
        <div ludsFormFieldFeedback>
          <p ludsError ludsErrorValidator="maxlength" class="luds-label-medium-default">
            <ng-icon ludsRuleFailIcon  name="phosphorXCircle"></ng-icon>
            Limite excedido.
          </p>
          <p ludsDescription class="luds-label-medium-default">Tamanho máximo de 25 caracteres.</p>

          <div ludsCharacterCounter #characterCounter="ludsCharacterCounter">
            <p class="luds-label-medium-default">
              {{ characterCounter.currentCount() }} / {{ characterCounter.maxLength() }}
            </p>
          </div>
        </div>
      </div>
    </form>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormFieldDemoCharacterCounterComponent {
  protected readonly formGroup = new FormGroup({
    text: new FormControl("", Validators.maxLength(25)),
  });
}
