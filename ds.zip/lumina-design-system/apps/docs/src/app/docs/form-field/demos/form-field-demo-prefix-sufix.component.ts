/** This example uses ng-primitives styles, which are imported from ng-primitives/example-theme/index.css in the global styles file **/
import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
  LudsDescription,
  LudsFormField,
  LudsFormFieldPrefix,
  LudsFormFieldSuffix,
  LudsLabel,
} from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";
import { phosphorHouse, phosphorUser } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "form-field-demo-prefix-sufix",
  imports: [
    FormsModule,
    LudsInput,
    ReactiveFormsModule,
    LudsFormFieldSuffix,
    LudsFormFieldPrefix,
    CommonModule,
    LudsFormField,
    LudsLabel,
    LudsDescription,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorUser, phosphorHouse })],
  template: `
    <form [formGroup]="formGroup">
      <div ludsFormField>
        <label ludsLabel class="luds-body-medium-default">Nome Completo</label>
        <ng-icon ludsFormFieldPrefix name="phosphorUser"></ng-icon>
        <input ludsInput type="text" placeholder="Digite seu nome completo" formControlName="fullName" />
        <div ludsFormFieldFeedback>
          <p ludsDescription class="luds-label-medium-default">Por favor, inclua seu nome completo.</p>
        </div>
      </div>

      <div ludsFormField>
        <label ludsLabel class="luds-body-medium-default">Endereço</label>
        <ng-icon ludsFormFieldSuffix name="phosphorHouse"></ng-icon>
        <input ludsInput type="text" formControlName="address" />
        <div ludsFormFieldFeedback>
          <p ludsDescription class="luds-label-medium-default">Por favor, inclua seu endereço.</p>
        </div>
      </div>
    </form>
  `,
  standalone: true,
})
export class FormFieldDemoPrefixSufixComponent {
  readonly formGroup = new FormGroup({
    fullName: new FormControl({ disabled: false, value: "" }),
    address: new FormControl({ disabled: false, value: "" }),
  });
}
