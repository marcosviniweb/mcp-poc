import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsButton } from "@luds/ui/blocks/button";
import {
  LudsDialog,
  LudsDialogDescription,
  LudsDialogOverlay,
  LudsDialogTitle,
  LudsDialogTrigger,
} from "@luds/ui/blocks/dialog";
import { phosphorArrowsClockwise, phosphorX } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "dialog-demo-1",
  imports: [
    LudsDialog,
    LudsDialogTrigger,
    LudsDialogOverlay,
    LudsButton,
    LudsDialogTitle,
    LudsDialogDescription,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorArrowsClockwise, phosphorX })],
  template: `
    <button ludsButton [ludsDialogTrigger]="dialog">Abrir Dialog</button>

    <ng-template #dialog let-close="close">
      <div ludsDialogOverlay>
        <div ludsDialog>
          <ng-icon name="phosphorArrowsClockwise" ludsDialogIcon></ng-icon>
          <button
            ludsDialogCloseIcon
            ludsButton
            buttonType="icon-button"
            variant="tertiary"
            (click)="close()"
            aria-label="Fechar"
          >
            <ng-icon name="phosphorX"></ng-icon>
          </button>
          <h1 ludsDialogTitle>Dialog com Botão Único</h1>
          <p ludsDialogDescription>Este é um dialog com botão único</p>
          <div ludsDialogActions>
            <button (click)="close()" ludsButton>Confirmar</button>
          </div>
        </div>
      </div>
    </ng-template>
  `,
  standalone: true,
})
export class DialogDemo1Component {}
