export { DialogDemo1Component } from "./dialog-demo-1.component";
export { DialogDemo2Component } from "./dialog-demo-2.component";
export { DialogDemo3Component } from "./dialog-demo-3.component";
export { DialogDemoTriggerComponent } from "./dialog-demo-external-data.component";
export { DialogExternalData } from "./dialog-demo-external-data.component";
