{{ NgDocApi.details("libs/ui/blocks/dialog/src/dialog/dialog.ts#LudsDialog") }}

{{ JSDoc.description("libs/ui/blocks/dialog/src/dialog/dialog.ts#LudsDialog") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsDialog } from "@luds/ui/blocks/dialog";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorArrowsClockwise, phosphorX } from "@ng-icons/phosphor-icons/regular";

@Component({
  standalone: true,
  imports: [LudsDialog, NgIcon],
  providers: [provideIcons({ phosphorArrowsClockwise, phosphorX })],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<button ludsButton [ludsDialogTrigger]="dialog">Launch Dialog</button>

<ng-template #dialog let-close="close">
  <div ludsDialogOverlay>
    <div ludsDialog>
      <ng-icon name="phosphorArrowsClockwise" ludsDialogIcon></ng-icon>
      <button
        ludsDialogCloseIcon
        ludsButton
        buttonType="icon-button"
        variant="tertiary"
        (click)="close()"
        aria-label="Fechar"
      >
        <ng-icon name="phosphorX"></ng-icon>
      </button>
      <h1 ludsDialogTitle>Publish this article?</h1>
      <p ludsDialogDescription>Are you sure you want to publish this article? This action is irreversible.</p>
      <div ludsDialogActions>
        <button (click)="close()" ludsButton variant="secondary">Cancel</button>
        <button (click)="close()" ludsButton>Confirm</button>
      </div>
    </div>
  </div>
</ng-template>
```

## Exemplos

### Dialog com botão único

{{ NgDocActions.demo("DialogDemo1Component") }}

### Dialog com dois botões

{{ NgDocActions.demo("DialogDemo2Component") }}

### Dialog com dois botões

{{ NgDocActions.demo("DialogDemo3Component") }}

### Dialog com dados externos

{{ NgDocActions.demo("DialogDemoTriggerComponent") }}
