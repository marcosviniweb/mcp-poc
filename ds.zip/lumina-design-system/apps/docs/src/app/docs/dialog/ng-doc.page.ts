import {
  LudsDialog,
  LudsDialogDescription,
  LudsDialogOverlay,
  LudsDialogTitle,
  LudsDialogTrigger,
} from "@luds/ui/blocks/dialog";
import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { DialogDemo1Component } from "./demos/dialog-demo-1.component";
import { DialogDemo2Component } from "./demos/dialog-demo-2.component";
import { DialogDemo3Component } from "./demos/dialog-demo-3.component";
import { DialogDemoTriggerComponent } from "./demos/dialog-demo-external-data.component";

const Dialog: NgDocPage = {
  title: `Dialog`,
  mdFile: "./index.md",
  category: ComponentsCategory,

  demos: { DialogDemoTriggerComponent, DialogDemo1Component, DialogDemo2Component, DialogDemo3Component },
  imports: [LudsDialog, LudsDialogTrigger, LudsDialogOverlay, LudsDialogDescription, LudsDialogTitle],
};

export default Dialog;
