import { FocusOrigin } from "@angular/cdk/a11y";
import { Component, inject } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsButton } from "@luds/ui/blocks/button";
import {
  injectDialogRef,
  LudsDialog,
  LudsDialogDescription,
  LudsDialogManager,
  LudsDialogOverlay,
  LudsDialogTitle,
} from "@luds/ui/blocks/dialog";
import { phosphorArrowsClockwise, phosphorX } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "dialog-trigger",
  imports: [LudsButton],
  standalone: true,
  template: ` <button (click)="openDialog()" ludsButton>Abrir Dialog</button> `,
})
export class DialogDemoTriggerComponent {
  private dialogManager = inject(LudsDialogManager);

  openDialog() {
    this.dialogManager.open(DialogExternalData, {
      data: "Dados externos!",
    });
  }
}

@Component({
  selector: "dialog-external-data",
  imports: [LudsButton, LudsDialog, LudsDialogOverlay, LudsDialogTitle, LudsDialogDescription, NgIcon],
  providers: [provideIcons({ phosphorArrowsClockwise, phosphorX })],
  standalone: true,
  template: `
    <div ludsDialogOverlay>
      <div ludsDialog>
        <ng-icon name="phosphorArrowsClockwise" ludsDialogIcon></ng-icon>
        <button
          ludsDialogCloseIcon
          ludsButton
          buttonType="icon-button"
          variant="tertiary"
          (click)="close('cancel', 'mouse')"
          aria-label="Fechar"
        >
          <ng-icon name="phosphorX"></ng-icon>
        </button>

        <h1 ludsDialogTitle>Dialog com dados externos</h1>
        <p ludsDialogDescription>O seguinte valor foi passado para o dialog: {{ dialogRef.data }}</p>

        <div ludsDialogActions>
          <button (click)="close('cancel', 'mouse')" ludsButton variant="secondary">Cancelar</button>
          <button (click)="close('confirm', 'mouse')" ludsButton>Confirmar</button>
        </div>
      </div>
    </div>
  `,
})
export class DialogExternalData {
  protected readonly dialogRef = injectDialogRef<string>();

  constructor() {
    this.dialogRef.closed.subscribe((event) => {
      console.log("Dialog closed", event);
    });
  }

  close(result: string, focusOrigin: FocusOrigin) {
    this.dialogRef.close(result, focusOrigin);
  }
}
