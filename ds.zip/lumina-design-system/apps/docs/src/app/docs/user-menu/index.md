---
title: Componente
keyword: UserMenuComponentPage
---

O template User Menu oferece uma solução pronta para menus de usuário, utilizando os componentes fechados do sistema (`luds-menu`, `luds-menu-item`, `luds-menu-header`). Sem lógicas de negócio específicas, ele foca na apresentação visual padronizada de opções relacionadas ao usuário logado, como perfil, configurações e logout.

## Preview

{{ NgDocActions.demo("UserMenuDemo") }}

## Importação

```typescript name="my-component.ts" group="user-menu-import"
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorUser, phosphorGear, phosphorSignOut } from "@ng-icons/phosphor-icons/regular";
import { Menu, MenuItem, MenuHeader } from "@luds/ui/components/menu";
import { LudsMenuTrigger } from "@luds/ui/blocks/menu";
import { LudsButton } from "@luds/ui/blocks/button";

@Component({
  standalone: true,
  imports: [Menu, MenuItem, MenuHeader, LudsMenuTrigger, LudsButton, NgIcon],
  providers: [provideIcons({ phosphorUser, phosphorGear, phosphorSignOut })],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="user-menu-import"
<button [ludsMenuTrigger]="userMenu" ludsButton variant="tertiary">
  <ng-icon name="phosphorUser"></ng-icon>
  {{ user.name }}
</button>

<ng-template #userMenu>
  <luds-menu>
    <luds-menu-header>
      <p class="luds-body-large-bold">{{ user.name }}</p>
      <p class="luds-label-large-default">{{ user.email }}</p>
    </luds-menu-header>

    <luds-menu-item (click)="viewProfile()">
      <ng-icon name="phosphorUser"></ng-icon>
      Ver Perfil
    </luds-menu-item>

    <luds-menu-item (click)="settings()">
      <ng-icon name="phosphorGear"></ng-icon>
      Configurações
    </luds-menu-item>

    <luds-menu-item (click)="logout()">
      <ng-icon name="phosphorSignOut"></ng-icon>
      Sair
    </luds-menu-item>
  </luds-menu>
</ng-template>
```

## Customização Avançada

Para casos que requerem maior flexibilidade na estrutura HTML, consulte a [documentação de diretivas](/templates/user-menu/diretivas), que explica como usar as diretivas de baixo nível do menu.
