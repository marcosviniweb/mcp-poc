---
title: Diretivas
route: diretivas
keyword: UserMenuDirectivesPage
---

Para casos que requerem maior flexibilidade na estrutura HTML ou customizações específicas do User Menu, você pode utilizar as diretivas de baixo nível do sistema de Menu.

O User Menu é essencialmente um caso de uso específico do [Menu](/components/menu/diretivas), portanto, todas as funcionalidades de diretivas estão disponíveis (`ludsMenuTrigger`, `ludsMenu`, `ludsMenuArrow`, `ludsMenuHeader`, `ludsMenuContent`, `ludsMenuItem`)

## Importação

```typescript name="user-menu-component.ts" group="user-menu-directives"
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorUser, phosphorBuildingOffice, phosphorSignOut } from "@ng-icons/phosphor-icons/regular";
import { LudsMenu, LudsMenuItem, LudsMenuTrigger, LudsMenuHeader, LudsMenuContent } from "@luds/ui/blocks/menu";

@Component({
  standalone: true,
  imports: [LudsMenu, LudsMenuItem, LudsMenuTrigger, LudsMenuHeader, LudsMenuContent, NgIcon],
  providers: [provideIcons({ phosphorUser, phosphorBuildingOffice, phosphorSignOut })],
  templateUrl: "./user-menu-component.html",
})
export class UserMenuComponent {}
```

```html name="user-menu-component.html" group="user-menu-directives"
<button [ludsMenuTrigger]="userMenu">
  <ng-icon name="phosphorUser"></ng-icon>
</button>

<ng-template #userMenu>
  <div ludsMenu>
    <div ludsMenuArrow></div>
    <div ludsMenuHeader data-direction="column">
      <p class="luds-body-large-bold">Nome do Usuário</p>
      <p class="luds-label-large-default">usuario@empresa.com</p>
    </div>
    <div ludsMenuContent>
      <button ludsMenuItem>
        <ng-icon name="phosphorUser"></ng-icon>
        Perfil
      </button>
      <button ludsMenuItem>
        <ng-icon name="phosphorBuildingOffice"></ng-icon>
        Empresa
      </button>
      <button ludsMenuItem>
        <ng-icon name="phosphorSignOut"></ng-icon>
        Sair
      </button>
    </div>
  </div>
</ng-template>
```

## Documentação Completa

Para informações detalhadas sobre todas as diretivas, configurações avançadas e exemplos práticos, consulte a **[documentação de diretivas do Menu](/components/menu/diretivas)**.

Lá você encontrará:

- Estrutura completa das diretivas
- Configurações de posicionamento (`provideMenuConfig`)
- Headers horizontais e verticais
- Controle de setas
- Separadores entre itens

Para casos simples, recomendamos usar os [componentes fechados](/templates/user-menu/) que já oferecem uma solução pronta e padronizada.
