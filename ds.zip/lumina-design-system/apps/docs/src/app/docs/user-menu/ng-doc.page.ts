import { NgDocPage } from '@ng-doc/core';
import TemplatesCategory from 'apps/docs/src/categories/templates/ng-doc.category';
import { UserMenuDemo } from './demos';

/**
 * @status:info NEW
 */
const UserMenu: NgDocPage = {
  title: `UserMenu`,
  mdFile: ['./index.md', './directives.md'],
  category: TemplatesCategory,
  demos: { UserMenuDemo },
};

export default UserMenu;
