import { Component, signal, ChangeDetectionStrategy } from '@angular/core';
import { NgIcon, provideIcons } from '@ng-icons/core';
import { LudsMenuTrigger } from '@luds/ui/blocks/menu';
import { LudsButton } from '@luds/ui/blocks/button';
import { Menu, MenuItem, MenuHeader } from '@luds/ui/components/menu'
import { 
  phosphorUser, 
  phosphorBuildingOffice, 
  phosphorDatabase, 
  phosphorUserCircleGear, 
  phosphorReceipt, 
  phosphorQuestion 
} from '@ng-icons/phosphor-icons/regular';

interface IMenuItem { id: string; label: string; icon: string };

@Component({
  selector: 'user-menu-demo',
  imports: [LudsMenuTrigger, Menu, MenuItem, MenuHeader, LudsButton, NgIcon],
  providers: [provideIcons({ 
    phosphorUser, 
    phosphorBuildingOffice, 
    phosphorDatabase, 
    phosphorUserCircleGear, 
    phosphorReceipt, 
    phosphorQuestion 
  })],
  template: `
    <button
      [ludsMenuTrigger]="menu"
      ludsButton
      variant="tertiary"
      buttonType='icon-button'
    >
      <ng-icon  name="phosphorUser"></ng-icon>
      </button>
    <ng-template #menu>
      <luds-menu>
          <luds-menu-header>
          <p class="luds-body-large-bold">{{ user.name }}</p>
          <p class="luds-label-large-default">{{ user.email }}</p>
        </luds-menu-header>

        @for(menuItem of menuItems(); track menuItem.id) {
          <luds-menu-item (click)="onMenuItemClick(menuItem)">
            <ng-icon [name]="menuItem.icon"></ng-icon>
            <p class="luds-body-large-default">{{ menuItem.label }}</p>
          </luds-menu-item>
        }
      </luds-menu>
    </ng-template>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
})
export class UserMenuDemo {
  protected readonly user = {
    name: 'Nome do Usuário',
    email: 'nomedousuario@empresa.com',
  }

  protected readonly menuItems = signal<IMenuItem[]>([
    { id: 'perfil', label: 'Perfil', icon: 'phosphorUser' },
    { id: 'empresa', label: 'Empresa', icon: 'phosphorBuildingOffice' },
    { id: 'planos', label: 'Planos', icon: 'phosphorDatabase' },
    { id: 'gestao_de_acesso', label: 'Gestão de Acesso', icon: 'phosphorUserCircleGear' },
    { id: 'faturamento', label: 'Faturamento', icon: 'phosphorReceipt' },
    { id: 'ajuda', label: 'Ajuda', icon: 'phosphorQuestion' },
  ]);

  onMenuItemClick(menuItem: IMenuItem) {
    console.log('Item de menu clicado:', menuItem);
  }
}
