import { NgDocPage } from "@ng-doc/core";
import { CompleteTableDemoComponent } from "./demos/complete-table-demo.component";
import { CompleteTableServerSideDemoComponent } from "./demos/complete-table-server-side-demo.component";
import { SimplePaginationTableDemoComponent } from "./demos/simple-pagination-table-demo.component";
import { ServerSidePaginationTableDemoComponent } from "./demos/server-side-pagination-table-demo.component";
import { RowSelectionTableDemoComponent } from "./demos/row-selection-table-demo.component";
import { ColumnPinningTableDemoComponent } from "./demos/column-pinning-table-demo.component";
import { ColumnResizingTableDemoComponent } from "./demos/column-resizing-table-demo.component";
import { SortingTableDemoComponent } from "./demos/sorting-table-demo.component";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";

const Table: NgDocPage = {
  title: `Table`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  demos: {
    CompleteTableDemoComponent,
    SimplePaginationTableDemoComponent,
    ServerSidePaginationTableDemoComponent,
    RowSelectionTableDemoComponent,
    CompleteTableServerSideDemoComponent,
    ColumnPinningTableDemoComponent,
    ColumnResizingTableDemoComponent,
    SortingTableDemoComponent,
  },
};

export default Table;
