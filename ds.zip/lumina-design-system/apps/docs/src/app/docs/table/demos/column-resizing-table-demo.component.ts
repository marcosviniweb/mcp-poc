import { Component, signal } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { CommonModule } from "@angular/common";
import { ColumnDef, createAngularTable, FlexRenderDirective, getCoreRowModel } from "@tanstack/angular-table";
import { makeData, Person } from "./make-data";
import { phosphorArrowsOutLineHorizontal } from "@ng-icons/phosphor-icons/regular";
import {
  LudsTable,
  LudsTableColumnResizer,
  LudsTableContainer,
  LudsTableResizableCell,
  LudsTableResizableHeader,
} from "@luds/ui/blocks/table";

const defaultColumns: ColumnDef<Person, any>[] = [
  { accessorKey: "firstName", header: "Nome", size: 150 },
  { accessorKey: "lastName", header: "Sobrenome", size: 150 },
  { accessorKey: "email", header: "Email", size: 250 },
  { accessorKey: "age", header: "Idade", size: 100 },
  { accessorKey: "phone", header: "Telefone", size: 180 },
  { accessorKey: "address", header: "Endereço", size: 300 },
];

@Component({
  selector: "column-resizing-table-demo",
  standalone: true,
  imports: [
    CommonModule,
    FlexRenderDirective,
    LudsTable,
    LudsTableContainer,
    LudsTableResizableCell,
    LudsTableResizableHeader,
    LudsTableColumnResizer,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorArrowsOutLineHorizontal })],
  template: `
    <div ludsTableContainer>
      <table ludsTable [ludsTableInstance]="table">
        <thead>
          @for (headerGroup of table.getHeaderGroups(); track headerGroup.id) {
            <tr>
              @for (header of headerGroup.headers; track header.id) {
                <th [ludsTableResizableHeaderId]="header.id">
                  {{ header.column.columnDef.header }}
                  <div ludsTableColumnResizer [ludsColumnResizerHeader]="header">
                    <ng-icon name="phosphorArrowsOutLineHorizontal"></ng-icon>
                  </div>
                </th>
              }
            </tr>
          }
        </thead>
        <tbody>
          @for (row of table.getRowModel().rows; track row.id) {
            <tr>
              @for (cell of row.getVisibleCells(); track cell.id) {
                <td [ludsTableResizableCellId]="cell.column.id">
                  <ng-container *flexRender="cell.column.columnDef.cell; props: cell.getContext(); let cellValue">
                    {{ cellValue }}
                  </ng-container>
                </td>
              }
            </tr>
          }
        </tbody>
      </table>
    </div>
  `,
})
export class ColumnResizingTableDemoComponent {
  data = signal<Person[]>(makeData(5));

  table = createAngularTable(() => ({
    data: this.data(),
    columns: defaultColumns,
    getCoreRowModel: getCoreRowModel(),
    columnResizeMode: "onChange",
  }));
}
