{{ NgDocApi.details("libs/ui/blocks/table/src/table/table.ts#LudsTable") }}

> **Baseado no TanStack Table**  
> Esta documentação foi desenvolvida baseada no [TanStack Table](https://tanstack.com/table/latest), uma biblioteca poderosa e flexível para criação de tabelas. Para documentação mais detalhada sobre APIs avançadas e recursos adicionais, consulte a [documentação oficial do TanStack Table](https://tanstack.com/table/latest/docs/introduction).

## Introdução

O componente `LudsTable` é uma solução para criação de tabelas em Angular, construída sobre o TanStack Table. Oferece uma API declarativa e flexível que permite criar desde tabelas simples até implementações complexas com ordenação, filtros, paginação, seleção de linhas e muito mais.

## Importação

```typescript name="basic-table.component.ts" group="basic-table"
import { Component, signal } from "@angular/core";
import { LudsTable } from "@luds/ui/blocks/table";
import { createAngularTable, FlexRenderDirective, getCoreRowModel } from "@tanstack/angular-table";
import type { ColumnDef } from "@tanstack/angular-table";

interface User {
  id: number;
  name: string;
  email: string;
  age: number;
}

@Component({
  selector: "app-basic-table",
  imports: [LudsTable, FlexRenderDirective],
  templateUrl: "./basic-table.component.html",
})
export class BasicTableComponent {
  // Dados da tabela
  private readonly data = signal<User[]>([
    { id: 1, name: "João Silva", email: "joao@example.com", age: 30 },
    { id: 2, name: "Maria Santos", email: "maria@example.com", age: 25 },
    { id: 3, name: "Pedro Costa", email: "pedro@example.com", age: 35 },
  ]);

  // Definição das colunas
  private readonly columns: ColumnDef<User>[] = [
    {
      accessorKey: "name",
      header: "Nome",
    },
    {
      accessorKey: "email",
      header: "E-mail",
    },
    {
      accessorKey: "age",
      header: "Idade",
    },
  ];

  // Instância da tabela
  readonly table = createAngularTable(() => ({
    data: this.data(),
    columns: this.columns,
    getCoreRowModel: getCoreRowModel(),
  }));
}
```

```html name="basic-table.component.html" group="basic-table"
<div ludsTableContainer>
  <table ludsTable>
    <thead>
      @for (headerGroup of table.getHeaderGroups(); track headerGroup.id) {
      <tr>
        @for (header of headerGroup.headers; track header.id) {
        <th>
          @if (!header.isPlaceholder) {
          <ng-container *flexRender="header.column.columnDef.header; context: header.getContext()" />
          }
        </th>
        }
      </tr>
      }
    </thead>
    <tbody>
      @for (row of table.getRowModel().rows; track row.id) {
      <tr>
        @for (cell of row.getVisibleCells(); track cell.id) {
        <td>
          <ng-container *flexRender="cell.column.columnDef.cell; context: cell.getContext()" />
        </td>
        }
      </tr>
      }
    </tbody>
  </table>
</div>
```

## Exemplos Práticos

### Tabela Completa com Dados Locais

Exemplo avançado com todas as funcionalidades combinadas usando processamento de dados no frontend: ordenação, redimensionamento de colunas, fixação de colunas e seleção de linhas.

{{ NgDocActions.demo("CompleteTableDemoComponent", { class: "table-demo-pane" }) }}

### Tabela Completa com Dados de API (API-Driven)

Exemplo avançado que replica todas as funcionalidades da tabela completa, mas com dados carregados e processados via API. Inclui ordenação baseada em API, paginação manual, seleção de linhas, fixação de colunas e redimensionamento.

{{ NgDocActions.demo("CompleteTableServerSideDemoComponent", { class: "table-demo-pane" }) }}

## Funcionalidades

### Ordenação de Colunas (Sorting)

Para habilitar ordenação nas colunas da tabela, permitindo que usuários cliquem nos cabeçalhos para ordenar os dados:

1. **Configure o estado de ordenação:**

```typescript
readonly sorting = signal<SortingState>([]);
```

2. **Adicione no estado da tabela:**

```typescript
state: {
  sorting: this.sorting(),
},
onSortingChange: (updater) => {
  const newState = typeof updater === "function" ? updater(this.sorting()) : updater;
  this.sorting.set(newState);
},
```

3. **Habilite a funcionalidade:**

```typescript
enableSorting: true,
getSortedRowModel: getSortedRowModel(), // Para ordenação local (dados processados no frontend)
// OU
manualSorting: true, // Para ordenação baseada em API (dados processados remotamente)
```

4. **Use a diretiva no template:**

```html
{% raw %}
<th [ludsTableSortColumn]="header.column">{{ header.column.columnDef.header }}</th>
{% endraw %}
```

**Exemplo de implementação completa**

{{ NgDocActions.demo("SortingTableDemoComponent", { class: "table-demo-pane" } )}}

### Seleção de Linhas com Checkbox (Row Selection)

Para permitir que usuários selecionem uma ou múltiplas linhas da tabela usando checkboxes:

1. **Configure o estado de seleção:**

```typescript
readonly rowSelection = signal<RowSelectionState>({});
```

2. **Adicione no estado da tabela:**

```typescript
state: {
  rowSelection: this.rowSelection(),
},
onRowSelectionChange: (updater) => {
  const newState = typeof updater === "function" ? updater(this.rowSelection()) : updater;
  this.rowSelection.set(newState);
},
enableRowSelection: true,
getRowId: (row, index) => index.toString(), // Opcional: define ID único para cada linha para controle de seleção
```

3. **Configure colunas de seleção:**

```typescript
{
  accessorKey: "select",
  header: "", // Cabeçalho vazio para a coluna de checkbox
  enableSorting: false, // Desabilita ordenação para esta coluna
}
```

4. **Use checkboxes no template:**

```html
<!-- Checkbox para selecionar/desselecionar linha individual -->
<luds-checkbox [checked]="row.getIsSelected()" (checkedChange)="row.toggleSelected()" />

<!-- Checkbox no cabeçalho para selecionar/desselecionar todas as linhas -->
<luds-checkbox
  [checked]="table.getIsAllRowsSelected()"
  [indeterminate]="table.getIsSomeRowsSelected()"
  (checkedChange)="table.toggleAllRowsSelected()"
/>
```

**Exemplo de implementação completa**

{{ NgDocActions.demo("RowSelectionTableDemoComponent", { class: "table-demo-pane" } )}}

### Fixação de Colunas nas Laterais (Column Pinning)

Para fixar colunas específicas à esquerda ou direita da tabela, mantendo-as visíveis durante o scroll horizontal:

1. **Configure o estado de fixação:**

```typescript
readonly columnPinning = signal<ColumnPinningState>({
  left: ["select"], // Colunas fixadas à esquerda (ex: checkboxes)
  right: ["action"], // Colunas fixadas à direita (ex: botões de ação)
});
```

2. **Adicione no estado da tabela:**

```typescript
state: {
  columnPinning: this.columnPinning(),
},
onColumnPinningChange: (updater) => {
  const newState = typeof updater === "function" ? updater(this.columnPinning()) : updater;
  this.columnPinning.set(newState);
},
enableColumnPinning: true,
```

3. **Use as diretivas no template:**

```html
<!-- Para cabeçalhos das colunas -->
<th [ludsTablePinColumn]="header.column">
  <!-- Para células do corpo da tabela -->
</th>

<td [ludsTablePinCell]="cell"></td>
```

**Exemplo de implementação completa**

{{ NgDocActions.demo("ColumnPinningTableDemoComponent", { class: "table-demo-pane" } )}}

### Paginação de Dados

Para implementar paginação e dividir grandes conjuntos de dados em páginas menores:

1. **Configure o estado de paginação:**

```typescript
readonly pagination = signal<PaginationState>({ pageIndex: 0, pageSize: 10 });
```

2. **Para paginação padrão (dados locais):**

```typescript
// Todos os dados são carregados no frontend e a paginação é feita localmente
state: {
  pagination: this.pagination(),
},
onPaginationChange: (updater) => {
  const newState = typeof updater === "function" ? updater(this.pagination()) : updater;
  this.pagination.set(newState);
},
getPaginationRowModel: getPaginationRowModel(),
```

3. **Para paginação manual (dados de API):**

```typescript
// Os dados são carregados página por página do servidor
manualPagination: true,
pageCount: Math.ceil(totalCount / pageSize), // Total de páginas calculado com base no total de registros
```

4. **Use o componente de paginação:**

```html
<luds-pagination
  [page]="pagination().pageIndex + 1"
  [totalItems]="totalCount()"
  [itemsPerPage]="pagination().pageSize"
  (pageChange)="onPageChange($event)" <!-- Evento disparado ao trocar de página -->
  (itemsPerPageChange)="onPageSizeChange($event)" <!-- Evento disparado ao mudar itens por página -->
/>
```

**Exemplo de implementação de paginação padrão (dados locais)**

{{ NgDocActions.demo("SimplePaginationTableDemoComponent", { class: "table-demo-pane" } )}}

**Exemplo de implementação de paginação manual (dados de API)**

{{ NgDocActions.demo("ServerSidePaginationTableDemoComponent", { class: "table-demo-pane" } )}}

### Redimensionamento Interativo de Colunas

Para permitir que usuários ajustem a largura das colunas arrastando as bordas:

1. **Configure no estado da tabela:**

```typescript
columnResizeMode: "onChange", // Redimensiona em tempo real conforme arrasta
// ou "onEnd" - Redimensiona apenas quando solta o mouse
```

2. **Use as diretivas no template:**

```html
<!-- Para cabeçalhos das colunas -->
<th [ludsTableResizableHeaderId]="header.id">
  <!-- Elemento de controle para redimensionamento -->
  <div ludsTableColumnResizer [ludsColumnResizerHeader]="header">
    <ng-icon name="phosphorArrowsOutLineHorizontal"></ng-icon>
    <!-- Ícone indicativo -->
  </div>
</th>

<!-- Para células do corpo da tabela -->
<td [ludsTableResizableCellId]="cell.column.id"></td>
```

**Exemplo de implementação completa**

{{ NgDocActions.demo("ColumnResizingTableDemoComponent", { class: "table-demo-pane" } )}}
