import { Component, signal } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import {
  ColumnDef,
  createAngularTable,
  FlexRenderDirective,
  getCoreRowModel,
  getPaginationRowModel,
  PaginationState,
  getSortedRowModel,
  SortingState,
  ColumnPinningState,
} from "@tanstack/angular-table";
import { Pagination } from "@luds/ui/components/pagination";
import { Checkbox } from "@luds/ui/components/checkbox";
import { LudsButton } from "@luds/ui/blocks/button";
import { makeData, Person } from "./make-data";
import { phosphorArrowsOutLineHorizontal, phosphorCaretRight } from "@ng-icons/phosphor-icons/regular";
import {
  LudsTable,
  LudsTableColumnResizer,
  LudsTablePinColumn,
  LudsTablePinCell,
  LudsTableResizableCell,
  LudsTableResizableHeader,
  LudsTableSort,
  LudsTableContainer,
} from "@luds/ui/blocks/table";

const defaultColumns: ColumnDef<Person, any>[] = [
  {
    accessorKey: "select",
    header: "",
    enableSorting: false,
    enableResizing: false,
    size: 60,
  },
  { accessorKey: "firstName", header: "Nome" },
  { accessorKey: "lastName", header: "Sobrenome" },
  { accessorKey: "email", header: "Email", size: 300 },
  { accessorKey: "age", header: "Idade" },
  { accessorKey: "visits", header: "Visitas" },
  { accessorKey: "progress", header: "Progresso" },
  { accessorKey: "status", header: "Status" },
  { accessorKey: "phone", header: "Telefone", enableSorting: false },
  { accessorKey: "address", header: "Endereço", size: 300 },
  { accessorKey: "country", header: "País", size: 300 },
  {
    accessorKey: "action",
    header: "",
    enableSorting: false,
    enableResizing: false,
    size: 60,
  },
];

@Component({
  selector: "complete-table-demo",
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    FlexRenderDirective,
    Pagination,
    Checkbox,
    LudsButton,
    LudsTableSort,
    LudsTablePinColumn,
    LudsTablePinCell,
    LudsTable,
    LudsTableContainer,
    LudsTableResizableCell,
    LudsTableResizableHeader,
    LudsTableColumnResizer,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorArrowsOutLineHorizontal, phosphorCaretRight })],
  template: `
    <div ludsTableContainer>
      <table ludsTable [ludsTableInstance]="table">
        <thead>
          @for (headerGroup of table.getHeaderGroups(); track headerGroup.id) {
            <tr>
              @for (header of headerGroup.headers; track header.id) {
                <th
                  [ludsTableResizableHeaderId]="header.id"
                  [ludsTableSortColumn]="header.column"
                  [ludsTablePinColumn]="header.column"
                >
                  @switch (header.column.id) {
                    @case ("select") {
                      <luds-checkbox
                        [checked]="table.getIsAllRowsSelected()"
                        [indeterminate]="table.getIsSomeRowsSelected()"
                        (checkedChange)="table.toggleAllRowsSelected()"
                        title="Selecionar todos"
                      />
                    }
                    @default {
                      {{ header.column.columnDef.header }}
                    }
                  }

                  <div ludsTableColumnResizer [ludsColumnResizerHeader]="header">
                    <ng-icon name="phosphorArrowsOutLineHorizontal"></ng-icon>
                  </div>
                </th>
              }
            </tr>
          }
        </thead>
        <tbody>
          @for (row of table.getRowModel().rows; track row.id) {
            <tr>
              @for (cell of row.getVisibleCells(); track cell.id) {
                <td [ludsTablePinCell]="cell" [ludsTableResizableCellId]="cell.column.id">
                  @switch (cell.column.id) {
                    @case ("select") {
                      <luds-checkbox
                        [checked]="row.getIsSelected()"
                        (checkedChange)="row.toggleSelected()"
                        title="Selecionar linha"
                      />
                    }
                    @case ("firstName") {
                      {{ row.original.firstName }}
                      <p class="luds-note-medium-default">
                        {{ row.original.lastName }}
                      </p>
                    }
                    @case ("action") {
                      <button ludsButton buttonType="icon-button" aria-label="Acessar" [variant]="'tertiary'">
                        <ng-icon name="phosphorCaretRight"></ng-icon>
                      </button>
                    }
                    @default {
                      <ng-container *flexRender="cell.column.columnDef.cell; props: cell.getContext(); let cellValue">
                        {{ cellValue }}
                      </ng-container>
                    }
                  }
                </td>
              }
            </tr>
          }
        </tbody>
      </table>
    </div>
    <luds-pagination
      [page]="pagination().pageIndex + 1"
      [totalItems]="data().length"
      [itemsPerPage]="pagination().pageSize"
      (pageChange)="table.setPageIndex($event - 1)"
      (itemsPerPageChange)="table.setPageSize($event)"
    />
  `,
})
export class CompleteTableDemoComponent {
  data = signal<Person[]>(makeData(300));
  readonly pagination = signal<PaginationState>({ pageIndex: 0, pageSize: 10 });
  readonly sorting = signal<SortingState>([]);
  readonly columnPinning = signal<ColumnPinningState>({
    left: ["select"],
    right: ["action"],
  });

  table = createAngularTable(() => ({
    data: this.data(),
    columns: defaultColumns,
    state: {
      pagination: this.pagination(),
      sorting: this.sorting(),
      columnPinning: this.columnPinning(),
    },
    onPaginationChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.pagination()) : updater;
      this.pagination.set(newState);
    },
    onSortingChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.sorting()) : updater;
      this.sorting.set(newState);
    },
    onColumnPinningChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.columnPinning()) : updater;
      this.columnPinning.set(newState);
    },
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    enableRowSelection: true,
    enableSorting: true,
    enableColumnPinning: true,
    columnResizeMode: "onChange",
  }));
}
