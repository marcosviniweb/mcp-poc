import { Component, signal } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { CommonModule } from "@angular/common";
import {
  ColumnDef,
  createAngularTable,
  FlexRenderDirective,
  getCoreRowModel,
  ColumnPinningState,
} from "@tanstack/angular-table";
import { LudsButton } from "@luds/ui/blocks/button";
import { makeData, Person } from "./make-data";
import { LudsTable, LudsTablePinColumn, LudsTablePinCell, LudsTableContainer } from "@luds/ui/blocks/table";
import { phosphorCaretRight } from "@ng-icons/phosphor-icons/regular";

const defaultColumns: ColumnDef<Person, any>[] = [
  {
    accessorKey: "id",
    header: "ID",
    size: 60,
  },
  { accessorKey: "firstName", header: "Nome" },
  { accessorKey: "lastName", header: "Sobrenome" },
  { accessorKey: "email", header: "Email", size: 300 },
  { accessorKey: "age", header: "Idade" },
  { accessorKey: "visits", header: "Visitas" },
  { accessorKey: "progress", header: "Progresso" },
  { accessorKey: "status", header: "Status" },
  { accessorKey: "phone", header: "Telefone" },
  { accessorKey: "address", header: "Endereço", size: 300 },
  { accessorKey: "country", header: "País", size: 200 },
  {
    accessorKey: "action",
    header: "Ação",
    size: 60,
  },
];

@Component({
  selector: "column-pinning-table-demo",
  standalone: true,
  imports: [
    CommonModule,
    FlexRenderDirective,
    LudsButton,
    LudsTablePinColumn,
    LudsTablePinCell,
    LudsTable,
    LudsTableContainer,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorCaretRight })],
  template: `
    <div ludsTableContainer>
      <table ludsTable [ludsTableInstance]="table">
        <thead>
          @for (headerGroup of table.getHeaderGroups(); track headerGroup.id) {
            <tr>
              @for (header of headerGroup.headers; track header.id) {
                <th [ludsTablePinColumn]="header.column">
                  {{ header.column.columnDef.header }}
                </th>
              }
            </tr>
          }
        </thead>
        <tbody>
          @for (row of table.getRowModel().rows; track row.id) {
            <tr>
              @for (cell of row.getVisibleCells(); track cell.id) {
                <td [ludsTablePinCell]="cell">
                  @switch (cell.column.id) {
                    @case ("id") {
                      #{{ row.index + 1 }}
                    }
                    @case ("action") {
                      <button ludsButton buttonType="icon-button" aria-label="Acessar" [variant]="'tertiary'">
                        <ng-icon name="phosphorCaretRight"></ng-icon>
                      </button>
                    }
                    @default {
                      <ng-container *flexRender="cell.column.columnDef.cell; props: cell.getContext(); let cellValue">
                        {{ cellValue }}
                      </ng-container>
                    }
                  }
                </td>
              }
            </tr>
          }
        </tbody>
      </table>
    </div>
  `,
})
export class ColumnPinningTableDemoComponent {
  data = signal<Person[]>(makeData(5));
  readonly columnPinning = signal<ColumnPinningState>({
    left: ["id"],
    right: ["action"],
  });

  table = createAngularTable(() => ({
    data: this.data(),
    columns: defaultColumns,
    state: {
      columnPinning: this.columnPinning(),
    },
    onColumnPinningChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.columnPinning()) : updater;
      this.columnPinning.set(newState);
    },
    getCoreRowModel: getCoreRowModel(),
    enableColumnPinning: true,
  }));
}
