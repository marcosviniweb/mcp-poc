import { makeData, Person } from "./make-data";
import { SortingState } from "@tanstack/angular-table";

// Simulate backend service
interface PagedResponse<T> {
  data: T[];
  totalCount: number;
  pageIndex: number;
  pageSize: number;
}

export class MockBackendService {
  private allData = makeData(1000); // Simulate large dataset on server

  async fetchPage(pageIndex: number, pageSize: number, sorting: SortingState): Promise<PagedResponse<Person>> {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500));

    let sortedData = [...this.allData];

    // Apply sorting if provided
    if (sorting.length > 0) {
      const sort = sorting[0]; // Handle first sort only for simplicity
      sortedData.sort((a, b) => {
        const aValue = a[sort.id as keyof Person];
        const bValue = b[sort.id as keyof Person];

        // Handle different data types
        if (typeof aValue === 'string' && typeof bValue === 'string') {
          const comparison = aValue.localeCompare(bValue);
          return sort.desc ? -comparison : comparison;
        }

        if (typeof aValue === 'number' && typeof bValue === 'number') {
          const comparison = aValue - bValue;
          return sort.desc ? -comparison : comparison;
        }

        // Fallback for other types
        const aStr = String(aValue);
        const bStr = String(bValue);
        const comparison = aStr.localeCompare(bStr);
        return sort.desc ? -comparison : comparison;
      });
    }

    const startIndex = pageIndex * pageSize;
    const endIndex = startIndex + pageSize;
    const data = sortedData.slice(startIndex, endIndex);

    return {
      data,
      totalCount: this.allData.length,
      pageIndex,
      pageSize,
    };
  }
}