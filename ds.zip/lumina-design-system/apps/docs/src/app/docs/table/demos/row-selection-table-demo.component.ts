import { Component, signal } from "@angular/core";
import { CommonModule } from "@angular/common";
import {
  ColumnDef,
  createAngularTable,
  FlexRenderDirective,
  getCoreRowModel,
  RowSelectionState,
} from "@tanstack/angular-table";
import { Checkbox } from "@luds/ui/components/checkbox";
import { makeData, Person } from "./make-data";
import { LudsTable, LudsTableContainer } from "@luds/ui/blocks/table";

const defaultColumns: ColumnDef<Person, any>[] = [
  {
    accessorKey: "select",
    header: "",
    enableSorting: false,
    size: 60,
  },
  { accessorKey: "firstName", header: "Nome" },
  { accessorKey: "lastName", header: "Sobrenome" },
  { accessorKey: "email", header: "Email" },
  { accessorKey: "age", header: "Idade" },
];

@Component({
  selector: "row-selection-table-demo",
  standalone: true,
  imports: [
    CommonModule,
    FlexRenderDirective,
    Checkbox,
    LudsTable,
    LudsTableContainer
  ],
  template: `
    <div ludsTableContainer>
      <table ludsTable [ludsTableInstance]="table">
        <thead>
          @for (headerGroup of table.getHeaderGroups(); track headerGroup.id) {
            <tr>
              @for (header of headerGroup.headers; track header.id) {
                <th>
                  @switch (header.column.id) {
                    @case ("select") {
                      <luds-checkbox
                        [checked]="table.getIsAllRowsSelected()"
                        [indeterminate]="table.getIsSomeRowsSelected()"
                        (checkedChange)="table.toggleAllRowsSelected()"
                        title="Selecionar todos"
                      />
                    }
                    @default {
                      {{ header.column.columnDef.header }}
                    }
                  }
                </th>
              }
            </tr>
          }
        </thead>
        <tbody>
          @for (row of table.getRowModel().rows; track row.id) {
            <tr>
              @for (cell of row.getVisibleCells(); track cell.id) {
                <td>
                  @switch (cell.column.id) {
                    @case ("select") {
                      <luds-checkbox
                        [checked]="row.getIsSelected()"
                        (checkedChange)="row.toggleSelected()"
                        title="Selecionar linha"
                      />
                    }
                    @default {
                      <ng-container *flexRender="cell.column.columnDef.cell; props: cell.getContext(); let cellValue">
                        {{ cellValue }}
                      </ng-container>
                    }
                  }
                </td>
              }
            </tr>
          }
        </tbody>
      </table>
    </div>
  `,
})
export class RowSelectionTableDemoComponent {
  data = signal<Person[]>(makeData(5));
  readonly rowSelection = signal<RowSelectionState>({});

  table = createAngularTable(() => ({
    data: this.data(),
    columns: defaultColumns,
    state: {
      rowSelection: this.rowSelection(),
    },
    onRowSelectionChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.rowSelection()) : updater;
      this.rowSelection.set(newState);
    },
    getCoreRowModel: getCoreRowModel(),
    enableRowSelection: true,
    getRowId: (row, index) => index.toString(),
  }));
}
