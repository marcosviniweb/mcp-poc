import { Component, signal } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import {
  ColumnDef,
  createAngularTable,
  FlexRenderDirective,
  getCoreRowModel,
  PaginationState,
  SortingState,
  ColumnPinningState,
  RowSelectionState,
} from "@tanstack/angular-table";
import { Checkbox } from "@luds/ui/components/checkbox";
import { Pagination } from "@luds/ui/components/pagination";
import { LudsButton } from "@luds/ui/blocks/button";
import { Person } from "./make-data";
import {
  LudsTable,
  LudsTableColumnResizer,
  LudsTablePinColumn,
  LudsTablePinCell,
  LudsTableResizableCell,
  LudsTableResizableHeader,
  LudsTableSort,
  LudsTableContainer,
} from "@luds/ui/blocks/table";
import { MockBackendService } from "./mock-backend.service";
import { phosphorArrowsOutLineHorizontal, phosphorCaretRight } from "@ng-icons/phosphor-icons/regular";

const defaultColumns: ColumnDef<Person, any>[] = [
  {
    accessorKey: "select",
    header: "",
    enableSorting: false,
    enableResizing: false,
    size: 60,
  },
  { accessorKey: "firstName", header: "Nome" },
  { accessorKey: "lastName", header: "Sobrenome" },
  { accessorKey: "email", header: "Email", size: 300 },
  { accessorKey: "age", header: "Idade" },
  { accessorKey: "visits", header: "Visitas" },
  { accessorKey: "progress", header: "Progresso" },
  { accessorKey: "status", header: "Status" },
  { accessorKey: "phone", header: "Telefone", enableSorting: false },
  { accessorKey: "address", header: "Endereço", size: 300 },
  { accessorKey: "country", header: "País", size: 300 },
  {
    accessorKey: "action",
    header: "",
    enableSorting: false,
    enableResizing: false,
    size: 60,
  },
];

@Component({
  selector: "complete-table-server-side-demo",
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    FlexRenderDirective,
    Pagination,
    Checkbox,
    LudsButton,
    LudsTableSort,
    LudsTablePinColumn,
    LudsTablePinCell,
    LudsTable,
    LudsTableContainer,
    LudsTableResizableCell,
    LudsTableResizableHeader,
    LudsTableColumnResizer,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorArrowsOutLineHorizontal, phosphorCaretRight })],
  template: `
    <div ludsTableContainer>
      <table ludsTable [ludsTableInstance]="table">
        <thead>
          @for (headerGroup of table.getHeaderGroups(); track headerGroup.id) {
            <tr>
              @for (header of headerGroup.headers; track header.id) {
                <th
                  [ludsTableResizableHeaderId]="header.id"
                  [ludsTableSortColumn]="header.column"
                  [ludsTablePinColumn]="header.column"
                >
                  @switch (header.column.id) {
                    @case ("select") {
                      <luds-checkbox
                        [checked]="table.getIsAllRowsSelected()"
                        [indeterminate]="table.getIsSomeRowsSelected()"
                        (checkedChange)="table.toggleAllRowsSelected()"
                        title="Selecionar todos"
                      />
                    }
                    @default {
                      {{ header.column.columnDef.header }}
                    }
                  }

                  <div ludsTableColumnResizer [ludsColumnResizerHeader]="header">
                    <ng-icon name="phosphorArrowsOutLineHorizontal"></ng-icon>
                  </div>
                </th>
              }
            </tr>
          }
        </thead>
        <tbody>
          @for (row of table.getRowModel().rows; track row.id) {
            <tr>
              @for (cell of row.getVisibleCells(); track cell.id) {
                <td [ludsTablePinCell]="cell" [ludsTableResizableCellId]="cell.column.id">
                  @switch (cell.column.id) {
                    @case ("select") {
                      <luds-checkbox
                        [checked]="row.getIsSelected()"
                        (checkedChange)="row.toggleSelected()"
                        title="Selecionar linha"
                      />
                    }
                    @case ("firstName") {
                      {{ row.original.firstName }}
                      <p class="luds-note-medium-default">
                        {{ row.original.lastName }}
                      </p>
                    }
                    @case ("action") {
                      <button ludsButton buttonType="icon-button" aria-label="Acessar" [variant]="'tertiary'">
                        <ng-icon name="phosphorCaretRight"></ng-icon>
                      </button>
                    }
                    @default {
                      <ng-container *flexRender="cell.column.columnDef.cell; props: cell.getContext(); let cellValue">
                        {{ cellValue }}
                      </ng-container>
                    }
                  }
                </td>
              }
            </tr>
          }
        </tbody>
      </table>
    </div>

    <luds-pagination
      [page]="table.getState().pagination.pageIndex + 1"
      [totalItems]="totalCount()"
      [itemsPerPage]="table.getState().pagination.pageSize"
      (pageChange)="table.setPageIndex($event - 1)"
      (itemsPerPageChange)="table.setPageSize($event)"
    />
  `,
})
export class CompleteTableServerSideDemoComponent {
  private backendService = new MockBackendService();

  // Estado da tabela
  readonly data = signal<Person[]>([]);
  readonly totalCount = signal(0);
  readonly pagination = signal<PaginationState>({ pageIndex: 0, pageSize: 10 });
  readonly sorting = signal<SortingState>([]);
  readonly columnPinning = signal<ColumnPinningState>({
    left: ["select"],
    right: ["action"],
  });
  readonly rowSelection = signal<RowSelectionState>({});

  // Referência para usar no template
  readonly defaultColumns = defaultColumns;

  constructor() {
    // Carrega dados iniciais
    this.loadData();
  }

  table = createAngularTable(() => ({
    data: this.data(),
    columns: defaultColumns,
    state: {
      pagination: this.pagination(),
      sorting: this.sorting(),
      columnPinning: this.columnPinning(),
      rowSelection: this.rowSelection(),
    },
    onPaginationChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.pagination()) : updater;
      this.pagination.set(newState);
      this.loadData();
    },
    onSortingChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.sorting()) : updater;
      this.sorting.set(newState);
      this.loadData();
    },
    onRowSelectionChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.rowSelection()) : updater;
      this.rowSelection.set(newState);
    },
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    manualSorting: true,
    pageCount: Math.ceil(this.totalCount() / (this.pagination().pageSize || 10)),
    enableRowSelection: true,
    enableSorting: true,
    enableColumnPinning: true,
    columnResizeMode: "onChange",
    getRowId: (row, index) => index.toString(),
  }));

  private async loadData() {
    try {
      const state = this.table.getState();
      const response = await this.backendService.fetchPage(
        state.pagination.pageIndex,
        state.pagination.pageSize,
        state.sorting,
      );

      this.data.set(response.data);
      this.totalCount.set(response.totalCount);

      this.table.resetRowSelection();
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
    }
  }
}
