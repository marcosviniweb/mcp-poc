import { Component, signal } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ColumnDef, createAngularTable, FlexRenderDirective, getCoreRowModel, PaginationState } from "@tanstack/angular-table";
import { Pagination } from "@luds/ui/components/pagination";
import { Person } from "./make-data";
import { LudsTable, LudsTableContainer } from "@luds/ui/blocks/table";
import { MockBackendService } from "./mock-backend.service";

const defaultColumns: ColumnDef<Person, any>[] = [
  { accessorKey: "firstName", header: "Nome" },
  { accessorKey: "lastName", header: "Sobrenome" },
  { accessorKey: "email", header: "Email" },
  { accessorKey: "age", header: "Idade" },
  { accessorKey: "status", header: "Status" },
];

@Component({
  selector: "server-side-pagination-table-demo",
  standalone: true,
  imports: [CommonModule, FlexRenderDirective, Pagination, LudsTable, LudsTableContainer],
  template: `
    <div ludsTableContainer>
      <table ludsTable [ludsTableInstance]="table">
        <thead>
          @for (headerGroup of table.getHeaderGroups(); track headerGroup.id) {
            <tr>
              @for (header of headerGroup.headers; track header.id) {
                <th>
                  {{ header.column.columnDef.header }}
                </th>
              }
            </tr>
          }
        </thead>
        <tbody>
          @for (row of table.getRowModel().rows; track row.id) {
            <tr>
              @for (cell of row.getVisibleCells(); track cell.id) {
                <td>
                  <ng-container *flexRender="cell.column.columnDef.cell; props: cell.getContext(); let cellValue">
                    {{ cellValue }}
                  </ng-container>
                </td>
              }
            </tr>
          }
        </tbody>
      </table>
    </div>

    <luds-pagination
      [page]="table.getState().pagination.pageIndex + 1"
      [totalItems]="totalCount()"
      [itemsPerPage]="table.getState().pagination.pageSize"
      (pageChange)="table.setPageIndex($event - 1)"
      (itemsPerPageChange)="table.setPageSize($event)"
    />
  `,
})
export class ServerSidePaginationTableDemoComponent {
  private backendService = new MockBackendService();

  // Estado local
  readonly pagination = signal<PaginationState>({ pageIndex: 0, pageSize: 10 });
  readonly data = signal<Person[]>([]);
  readonly totalCount = signal(0);

  // Referência para usar no template
  readonly defaultColumns = defaultColumns;

  table = createAngularTable(() => ({
    data: this.data(),
    columns: defaultColumns,
    state: {
      pagination: this.pagination(),
    },
    onPaginationChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.pagination()) : updater;
      this.pagination.set(newState);
      this.loadData();
    },
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    pageCount: Math.ceil(this.totalCount() / (this.pagination().pageSize || 10)),
  }));

  constructor() {
    // Carrega dados iniciais
    this.loadData();
  }

  private async loadData() {
    try {
      const state = this.table.getState();
      const response = await this.backendService.fetchPage(state.pagination.pageIndex, state.pagination.pageSize, []);

      this.data.set(response.data);
      this.totalCount.set(response.totalCount);
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
    }
  }
}
