import { Component, signal } from "@angular/core";
import { CommonModule } from "@angular/common";
import {
  ColumnDef,
  createAngularTable,
  FlexRenderDirective,
  getCoreRowModel,
  getSortedRowModel,
  SortingState,
} from "@tanstack/angular-table";
import { makeData, Person } from "./make-data";
import { LudsTable, LudsTableContainer, LudsTableSort } from "@luds/ui/blocks/table";

const defaultColumns: ColumnDef<Person, any>[] = [
  { accessorKey: "firstName", header: "Nome" },
  { accessorKey: "lastName", header: "Sobrenome" },
  { accessorKey: "email", header: "Email" },
];

@Component({
  selector: "sorting-table-demo",
  standalone: true,
  imports: [
    CommonModule,
    FlexRenderDirective,
    LudsTable,
    LudsTableSort,
    LudsTableContainer
  ],
  template: `
    <div ludsTableContainer>
      <table ludsTable [ludsTableInstance]="table">
        <thead>
          @for (headerGroup of table.getHeaderGroups(); track headerGroup.id) {
            <tr>
              @for (header of headerGroup.headers; track header.id) {
                <th [ludsTableSortColumn]="header.column">
                  {{ header.column.columnDef.header }}
                </th>
              }
            </tr>
          }
        </thead>
        <tbody>
          @for (row of table.getRowModel().rows; track row.id) {
            <tr>
              @for (cell of row.getVisibleCells(); track cell.id) {
                <td>
                  <ng-container *flexRender="cell.column.columnDef.cell; props: cell.getContext(); let cellValue">
                    {{ cellValue }}
                  </ng-container>
                </td>
              }
            </tr>
          }
        </tbody>
      </table>
    </div>
  `,
})
export class SortingTableDemoComponent {
  data = signal<Person[]>(makeData(5));
  readonly sorting = signal<SortingState>([
    {
        id: "firstName",
        desc: true
    }
  ]);

  table = createAngularTable(() => ({
    data: this.data(),
    columns: defaultColumns,
    state: {
      sorting: this.sorting(),
    },
    onSortingChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.sorting()) : updater;
      this.sorting.set(newState);
    },
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    enableSorting: true,
  }));
}
