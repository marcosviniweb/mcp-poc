import { Component, signal } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import {
  ColumnDef,
  createAngularTable,
  FlexRenderDirective,
  getCoreRowModel,
  getPaginationRowModel,
  PaginationState,
} from "@tanstack/angular-table";
import { Pagination } from "@luds/ui/components/pagination";
import { Person, makeData } from "./make-data";
import { LudsTable, LudsTableContainer } from "@luds/ui/blocks/table";

const defaultColumns: ColumnDef<Person, any>[] = [
  { accessorKey: "firstName", header: "Nome" },
  { accessorKey: "lastName", header: "Sobrenome" },
  { accessorKey: "email", header: "Email" },
];

@Component({
  selector: "simple-pagination-table-demo",
  standalone: true,
  imports: [CommonModule, FormsModule, FlexRenderDirective, Pagination, LudsTable, LudsTableContainer],
  template: `
    <div ludsTableContainer>
      <table ludsTable [ludsTableInstance]="table">
        <thead>
          @for (headerGroup of table.getHeaderGroups(); track headerGroup.id) {
            <tr>
              @for (header of headerGroup.headers; track header.id) {
                <th>
                  {{ header.column.columnDef.header }}
                </th>
              }
            </tr>
          }
        </thead>
        <tbody>
          @for (row of table.getRowModel().rows; track row.id) {
            <tr>
              @for (cell of row.getVisibleCells(); track cell.id) {
                <td>
                  <ng-container *flexRender="cell.column.columnDef.cell; props: cell.getContext(); let cellValue">
                    {{ cellValue }}
                  </ng-container>
                </td>
              }
            </tr>
          }
        </tbody>
      </table>
    </div>
    <luds-pagination
      [page]="pagination().pageIndex + 1"
      [totalItems]="data().length"
      [itemsPerPage]="pagination().pageSize"
      (pageChange)="table.setPageIndex($event - 1)"
      (itemsPerPageChange)="table.setPageSize($event)"
    />
  `,
})

export class SimplePaginationTableDemoComponent {
  data = signal<Person[]>(makeData(300));
  readonly pagination = signal<PaginationState>({ pageIndex: 0, pageSize: 10 });

  table = createAngularTable(() => ({
    data: this.data(),
    columns: defaultColumns,
    state: {
      pagination: this.pagination(),
    },
    onPaginationChange: (updater) => {
      const newState = typeof updater === "function" ? updater(this.pagination()) : updater;
      this.pagination.set(newState);
    },
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
  }));
}
