import { Component, ChangeDetectionStrategy } from '@angular/core';
import { LudsMenuTrigger } from '@luds/ui/blocks/menu';
import { LudsButton } from '@luds/ui/blocks/button';
import { Menu, MenuItem, MenuHeader } from '@luds/ui/components/menu';

@Component({
  selector: 'menu-with-vertical-header-demo',
  imports: [LudsMenuTrigger, Menu, MenuItem, MenuHeader, LudsButton],
  template: `
    <button [ludsMenuTrigger]="menu" ludsButton>Score de Crédito</button>
    <ng-template #menu>
      <luds-menu>
        <luds-menu-header>
          <p class="luds-body-large-bold">Score Atual: {{ score }}</p>
          <p class="luds-label-large-default">Última atualização: {{ lastUpdate }}</p>
        </luds-menu-header>

        @for(menuItem of menuItems; track menuItem) {
          <luds-menu-item (click)="handleClick(menuItem)">
            {{ menuItem }}
          </luds-menu-item>
        }
      </luds-menu>
    </ng-template>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
})
export class MenuWithVerticalHeaderDemo {
  protected readonly score = 850;
  protected readonly lastUpdate = "15/09/2025";
  protected readonly menuItems = [
    "Evolução do Score",
    "Fatores que impactam",
    "Dicas para Melhorar",
    "Alertas",
    "Ajuda"
  ];
  protected handleClick(item: string) {
    console.log('clicou em', item);
  }
}
