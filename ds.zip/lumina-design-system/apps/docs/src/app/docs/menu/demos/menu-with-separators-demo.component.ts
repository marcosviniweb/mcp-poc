import { Component } from '@angular/core';
import { LudsMenuTrigger } from '@luds/ui/blocks/menu';
import { LudsButton } from '@luds/ui/blocks/button';
import { Menu, MenuHeader, MenuItem } from '@luds/ui/components/menu';

@Component({
  selector: 'menu-with-separators-demo',
  imports: [LudsMenuTrigger, Menu, MenuItem, MenuHeader, LudsButton],
  template: `
    <button [ludsMenuTrigger]="menu" ludsButton>Monitoramento Ativo</button>
    <ng-template #menu>
      <luds-menu>
        @for (menuItem of menuItems; track menuItem) {
          <luds-menu-item data-separator="true" (click)="handleClick(menuItem)">
            {{ menuItem }}
          </luds-menu-item>
        }
      </luds-menu>
    </ng-template>
  `,
  standalone: true,
})
export class MenuWithSeparatorsDemo {
  protected readonly menuItems = [
    "Alertas de Vazamento",
    "Permissão de Acesso",
    "Histórico de Atividades",
    "Ajuda"
  ]

  protected handleClick(item: string) {
    console.log('clicou em', item);
  }
}
