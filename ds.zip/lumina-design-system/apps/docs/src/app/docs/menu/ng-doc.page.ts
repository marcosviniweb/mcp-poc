import { NgDocPage } from '@ng-doc/core';
import ComponentsCategory from 'apps/docs/src/categories/components/ng-doc.category';
import {
  MenuDemo,
  MenuWithHorizontalHeaderDemo,
  MenuWithSeparatorsDemo,
  MenuWithVerticalHeaderDemo,
  MenuWithoutArrowDemo,
} from './demos';


/**
 * @status:info NEW
 */
const Menu: NgDocPage = {
  title: `Menu`,
  mdFile: ['./index.md', 'directives.md'],
  category: ComponentsCategory,
  demos: {
    MenuDemo,
    MenuWithHorizontalHeaderDemo,
    MenuWithSeparatorsDemo,
    MenuWithVerticalHeaderDemo,
    MenuWithoutArrowDemo,
  },
};

export default Menu;
