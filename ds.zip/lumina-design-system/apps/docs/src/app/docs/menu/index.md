---
title: Componente
keyword: MenuComponentPage
---

O componente `Menu` é uma versão pré-configurada e simplificada que encapsula toda a complexidade das diretivas em uma interface fácil de usar. Ideal para casos de uso comuns onde você precisa de um menu funcional sem personalizações específicas.

## Preview

{{ NgDocActions.demo("MenuDemo") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { Menu, MenuItem, MenuHeader } from "@luds/ui/components/menu";
import { MenuTrigger } from "@luds/ui/blocks/menu";

@Component({
  standalone: true,
  imports: [Menu, MenuItem, MenuHeader, MenuTrigger],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<button [ludsMenuTrigger]="menu">Open Menu</button>
<ng-template #menu>
  <luds-menu>
    <luds-menu-header>
      <p class="luds-body-large-bold">Título</p>
      <p class="luds-label-large-default">Subtítulo</p>
    </luds-menu-header>
    <luds-menu-item>Item 1</luds-menu-item>
    <luds-menu-item>Item 2</luds-menu-item>
    <luds-menu-item>Item 3</luds-menu-item>
  </luds-menu>
</ng-template>
```

## Variações de Layout

### Menu com Header Horizontal

{{ NgDocActions.demo("MenuWithHorizontalHeaderDemo") }}

Veja o template [Notification](/templates/notification) para um exemplo prático desta implementação.

### Menu com Header Vertical

{{ NgDocActions.demo("MenuWithVerticalHeaderDemo") }}

Confira como essa variação é utilizada no template [User Menu](/templates/user-menu).

### Menu com Separadores

{{ NgDocActions.demo("MenuWithSeparatorsDemo") }}

### Menu sem Seta

{{ NgDocActions.demo("MenuWithoutArrowDemo") }}

## Customização Avançada

Para casos que exigem maior flexibilidade e personalização, consulte a [documentação das Diretivas](/components/menu/diretivas).
