---
title: Diretivas
route: diretivas
keyword: MenuDirectivesPage
---

{{ NgDocApi.details("libs/ui/blocks/menu/src/menu/menu.ts#LudsMenu") }}

{{ JSDoc.description("libs/ui/blocks/menu/src/menu/menu.ts#LudsMenu") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsMenu, LudsMenuItem, LudsMenuTrigger } from "@luds/ui/blocks/menu";

@Component({
  standalone: true,
  imports: [LudsMenu, LudsMenuItem, LudsMenuTrigger],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<button [ludsMenuTrigger]="menu">Abrir Menu</button>
<ng-template #menu>
  <div ludsMenu>
    <div ludsMenuArrow></div>
    <div ludsMenuHeader>
      <!-- Conteúdo do cabeçalho -->
    </div>
    <div ludsMenuContent>
      <button ludsMenuItem>Item 1</button>
      <button ludsMenuItem>Item 2</button>
      <button ludsMenuItem>Item 3</button>
    </div>
  </div>
</ng-template>
```

## Estrutura e Diretivas

As diretivas do menu fornecem flexibilidade total para criar menus customizados. A estrutura básica inclui:

- **`ludsMenuTrigger`**: Diretiva aplicada ao elemento que abre o menu
- **`ludsMenu`**: Container principal do menu
- **`ludsMenuArrow`**: Seta do menu (opcional)
- **`ludsMenuHeader`**: Cabeçalho do menu (opcional)
- **`ludsMenuContent`**: Container dos itens do menu
- **`ludsMenuItem`**: Itens individuais do menu

## Funcionalidades Principais

### 1. Header com Orientação

O `ludsMenuHeader` pode ser configurado com orientação horizontal ou vertical:

```html name="header-horizontal.html"
<!-- Header Horizontal -->
<div ludsMenuHeader data-direction="row">
  <p class="luds-body-large-bold">Título</p>
  <button ludsButton variant="tertiary">Ação</button>
</div>
```

```html name="header-vertical.html"
<!-- Header Vertical (padrão) -->
<div ludsMenuHeader data-direction="column">
  <p class="luds-body-large-bold">Score Atual: 850</p>
  <p class="luds-label-large-default">Última atualização: 15/09/2025</p>
</div>
```

Os templates [Notification]("/templates/notification") e [User Menu]("/templates/user-menu") foram desenvolvidos utilizando essas mesmas diretivas e seletores, oferecendo exemplos práticos de implementação em cenários reais de uso.

### 2. Seta do Menu

Controle a exibição da seta usando a diretiva `ludsMenuArrow`:

```html name="with-arrow.html"
<!-- Com seta -->
<div ludsMenu>
  <div ludsMenuArrow></div>
  <div ludsMenuContent>
    <!-- itens do menu -->
  </div>
</div>
```

```html name="without-arrow.html"
<!-- Sem seta -->
<div ludsMenu>
  <div ludsMenuContent>
    <!-- itens do menu -->
  </div>
</div>
```

### 3. Separadores

Adicione separadores visuais usando o atributo `data-separator`:

```html name="separators.html"
<div ludsMenuContent>
  <button ludsMenuItem data-separator="true">Item com separador</button>
  <button ludsMenuItem data-separator="true">Outro item com separador</button>
  <button ludsMenuItem>Item sem separador</button>
</div>
```

## Configuração Avançada

Use `provideMenuConfig()` para configurar o comportamento do menu:

```typescript name="advanced-config.ts"
import { provideMenuConfig } from '@luds/ui/blocks/menu';

@Component({
  providers: [
    provideMenuConfig({
      placement: 'bottom-start',     // Posição do menu
      offset: 8,                     // Distância do trigger
      flip: true,                    // Inverter se não couber
      autoplacement: false,          // Auto posicionamento
      shift: true,                   // Ajustar para ficar visível
      arrowPadding: 16,              // Espaçamento entre seta e bordas
      scrollBehavior: 'reposition',  // Comportamento no scroll
      container: 'body'              // Elemento container
    })
  ]
})
export class MyComponent {}
```
