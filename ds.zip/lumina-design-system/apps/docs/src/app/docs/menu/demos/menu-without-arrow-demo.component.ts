import { Component } from '@angular/core';
import { LudsMenuTrigger, provideMenuConfig } from '@luds/ui/blocks/menu';
import { LudsButton } from '@luds/ui/blocks/button';
import { Menu, MenuItem } from '@luds/ui/components/menu';

@Component({
  selector: 'menu-without-arrow-demo',
  imports: [LudsMenuTrigger, Menu, MenuItem, LudsButton],
  providers: [provideMenuConfig({ offset: 8 })],
  template: `
    <button [ludsMenuTrigger]="menu" ludsButton>Identidade Digital</button>
    <ng-template #menu>
      <luds-menu [showArrow]="false">
        @for (menuItem of menuItems; track menuItem) {
          <luds-menu-item (click)="handleClick(menuItem)">
            {{ menuItem }}
          </luds-menu-item>
        }
      </luds-menu>
    </ng-template>
  `,
  standalone: true,
})
export class MenuWithoutArrowDemo {
    protected readonly menuItems = [
    "Verificação de Identidade",
    "Documentos Associados",
    "Histórico de Acessos",
    "Autenticação",
    "Segurança",
    "Configuração"
  ];
  protected handleClick(item: string) {
    console.log('clicou em', item);
  }
}
