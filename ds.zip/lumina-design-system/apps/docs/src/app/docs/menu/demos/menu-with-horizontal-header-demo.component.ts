import { Component, ViewChild } from '@angular/core';
import { LudsMenuTrigger } from '@luds/ui/blocks/menu';
import { LudsButton } from '@luds/ui/blocks/button';
import { Menu, MenuItem, MenuHeader } from '@luds/ui/components/menu';

@Component({
  selector: 'menu-with-horizontal-header-demo',
  imports: [LudsMenuTrigger, Menu, MenuItem, MenuHeader, LudsButton],
  template: `
    <button [ludsMenuTrigger]="menu" ludsButton>Empresa Associada</button>
    <ng-template #menu>
      <luds-menu #menuRef>
        <luds-menu-header direction="row">
          <p class="luds-body-large-bold">Empresa Ltda.</p>
          <button ludsButton variant="tertiary" (click)="handleClickEditProfile($event)">
            Editar perfil
          </button>
        </luds-menu-header>

        @for(menuItem of menuItems; track menuItem) {
          <luds-menu-item (click)="handleClickMenuItem(menuItem)">
            {{ menuItem }}
          </luds-menu-item>
        }
      </luds-menu>
    </ng-template>
  `,
  standalone: true,
})
export class MenuWithHorizontalHeaderDemo {
  @ViewChild('menuRef', { read: Menu }) menu!: Menu;

  protected readonly menuItems = [
    "Score PJ",
    "Protestos e Pendências",
    "Certidões",
    "Gestão de Acesso",
  ];

  protected handleClickMenuItem(item: string) {
    console.log('clicou em', item);
  }

  protected handleClickEditProfile(event: MouseEvent) {
    console.log('clicou em Editar perfil');
    this.menu.closeAllMenus(event);
  }
}
