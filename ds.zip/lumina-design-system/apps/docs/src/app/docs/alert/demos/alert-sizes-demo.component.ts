import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsAlert } from "@luds/ui/blocks/alert";
import { phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "alert-sizes-demo",
  imports: [LudsAlert, NgIcon],
  providers: [provideIcons({ phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle })],
  styles: `
    .demo-container {
      display: grid;
      gap: 1rem;
    }

    .demo-alert-row {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
  `,
  template: `
    <div class="demo-container">
      <p class="luds-body-medium-default">Default</p>
      <div ludsAlert background="soft" data-testid="luds-alert-info-default" type="info" aria-label="Alerta do tipo informação">
        <ng-icon ludsAlertIcon name="phosphorInfo" alt="Ícone de informação"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Atualização disponível</p>
          <p ludsAlertContent class="luds-label-large-default">
            Uma nova versão do aplicativo está pronta para instalação. Atualize para aproveitar os recursos mais
            recentes.
          </p>
        </span>
      </div>
      <div ludsAlert background="soft" data-testid="luds-alert-success-default" type="success" aria-label="Alerta do tipo sucesso">
        <ng-icon ludsAlertIcon name="phosphorCheckCircle" alt="Ícone de sucesso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Parabéns!</p>
          <p ludsAlertContent class="luds-label-large-default">
            Sua inscrição foi realizada com sucesso. Você receberá um e-mail com os próximos passos.
          </p>
        </span>
      </div>
      <div ludsAlert background="soft" data-testid="luds-alert-warning-default" type="warning" aria-label="Alerta do tipo aviso">
        <ng-icon ludsAlertIcon name="phosphorWarning" alt="Ícone de aviso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Aviso</p>
          <p ludsAlertContent class="luds-label-large-default">
            A conexão está instável. Algumas funcionalidades podem não responder corretamente.
          </p>
        </span>
      </div>
      <div ludsAlert background="soft" data-testid="luds-alert-error-default" type="error" aria-label="Alerta do tipo erro">
        <ng-icon ludsAlertIcon name="phosphorXCircle" alt="Ícone de erro"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Erro ao carregar os dados</p>
          <p ludsAlertContent class="luds-label-large-default">O servidor não respondeu. Tente novamente mais tarde.</p>
        </span>
      </div>
      <p class="luds-body-medium-default">Small</p>
      <div ludsAlert background="soft" size="small" data-testid="luds-alert-info-small" type="info" aria-label="Alerta do tipo informação">
        <ng-icon ludsAlertIcon name="phosphorInfo" alt="Ícone de informação"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-medium-bold">Atualização disponível</p>
          <p ludsAlertContent class="luds-label-medium-default">
            Uma nova versão do aplicativo está pronta para instalação. Atualize para aproveitar os recursos mais
            recentes.
          </p>
        </span>
      </div>
      <div ludsAlert background="soft" size="small" data-testid="luds-alert-success-small" type="success" aria-label="Alerta do tipo sucesso">
        <ng-icon ludsAlertIcon name="phosphorCheckCircle" alt="Ícone de sucesso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-medium-bold">Parabéns!</p>
          <p ludsAlertContent class="luds-label-medium-default">
            Sua inscrição foi realizada com sucesso. Você receberá um e-mail com os próximos passos.
          </p>
        </span>
      </div>
      <div ludsAlert background="soft" size="small" data-testid="luds-alert-warning-small" type="warning" aria-label="Alerta do tipo aviso">
        <ng-icon ludsAlertIcon name="phosphorWarning" alt="Ícone de aviso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-medium-bold">Aviso</p>
          <p ludsAlertContent class="luds-label-medium-default">
            A conexão está instável. Algumas funcionalidades podem não responder corretamente.
          </p>
        </span>
      </div>
      <div ludsAlert background="soft" size="small" data-testid="luds-alert-error-small" type="error" aria-label="Alerta do tipo erro">
        <ng-icon ludsAlertIcon name="phosphorXCircle" alt="Ícone de erro"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-medium-bold">Erro ao carregar os dados</p>
          <p ludsAlertContent class="luds-label-medium-default">
            O servidor não respondeu. Tente novamente mais tarde.
          </p>
        </span>
      </div>
    </div>
  `,
  standalone: true,
})
export class AlertSizesDemoComponent {}
