import { Component } from "@angular/core";
import { LudsAlert } from "@luds/ui/blocks/alert";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "alert-backgrounds-demo",
  imports: [LudsAlert, NgIcon],
  providers: [provideIcons({ phosphorInfo, phosphorCheckCircle, phosphorWarning, phosphorXCircle })],
  styles: `
    .demo-container {
      display: grid;
      gap: 1rem;
    }

    .demo-alert-row {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
  `,
  template: `
    <div class="demo-container">
      <p class="luds-body-medium-default">Soft</p>
      <div ludsAlert background="soft" data-testid="luds-alert-info-soft" type="info" aria-label="Alerta do tipo informação">
        <ng-icon ludsAlertIcon name="phosphorInfo" alt="Ícone de informação"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Atualização disponível</p>
          <p ludsAlertContent class="luds-label-large-default">
            Uma nova versão do aplicativo está pronta para instalação. Atualize para aproveitar os recursos mais
            recentes.
          </p>
        </span>
      </div>
      <div ludsAlert background="soft" data-testid="luds-alert-success-soft" type="success" aria-label="Alerta do tipo sucesso">
        <ng-icon ludsAlertIcon name="phosphorCheckCircle" alt="Ícone de sucesso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Parabéns!</p>
          <p ludsAlertContent class="luds-label-large-default">
            Sua inscrição foi realizada com sucesso. Você receberá um e-mail com os próximos passos.
          </p>
        </span>
      </div>
      <div ludsAlert background="soft" data-testid="luds-alert-warning-soft" type="warning" aria-label="Alerta do tipo aviso">
        <ng-icon ludsAlertIcon name="phosphorWarning" alt="Ícone de aviso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Aviso</p>
          <p ludsAlertContent class="luds-label-large-default">
            A conexão está instável. Algumas funcionalidades podem não responder corretamente.
          </p>
        </span>
      </div>
      <div ludsAlert background="soft" data-testid="luds-alert-error-soft" type="error" aria-label="Alerta do tipo erro">
        <ng-icon ludsAlertIcon name="phosphorXCircle" alt="Ícone de erro"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Erro ao carregar os dados</p>
          <p ludsAlertContent class="luds-label-large-default">O servidor não respondeu. Tente novamente mais tarde.</p>
        </span>
      </div>
      <p class="luds-body-medium-default">Filled</p>
      <div ludsAlert type="info" data-testid="luds-alert-info-filled" aria-label="Alerta do tipo informação">
        <ng-icon ludsAlertIcon name="phosphorInfo" alt="Ícone de informação"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Atualização disponível</p>
          <p ludsAlertContent class="luds-label-large-default">
            Uma nova versão do aplicativo está pronta para instalação. Atualize para aproveitar os recursos mais
            recentes.
          </p>
        </span>
      </div>
      <div ludsAlert type="success" data-testid="luds-alert-success-filled" aria-label="Alerta do tipo sucesso">
        <ng-icon ludsAlertIcon name="phosphorCheckCircle" alt="Ícone de sucesso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Parabéns!</p>
          <p ludsAlertContent class="luds-label-large-default">
            Sua inscrição foi realizada com sucesso. Você receberá um e-mail com os próximos passos.
          </p>
        </span>
      </div>
      <div ludsAlert type="warning" data-testid="luds-alert-warning-filled" aria-label="Alerta do tipo aviso">
        <ng-icon ludsAlertIcon name="phosphorWarning" alt="Ícone de aviso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Aviso</p>
          <p ludsAlertContent class="luds-label-large-default">
            A conexão está instável. Algumas funcionalidades podem não responder corretamente.
          </p>
        </span>
      </div>
      <div ludsAlert type="error" data-testid="luds-alert-error-filled" aria-label="Alerta do tipo erro">
        <ng-icon ludsAlertIcon name="phosphorXCircle" alt="Ícone de erro"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Erro ao carregar os dados</p>
          <p ludsAlertContent class="luds-label-large-default">O servidor não respondeu. Tente novamente mais tarde.</p>
        </span>
      </div>
      <p class="luds-body-medium-default">Flat</p>
      <div ludsAlert background="flat" data-testid="luds-alert-info-flat" type="info" aria-label="Alerta do tipo informação">
        <ng-icon ludsAlertIcon name="phosphorInfo" alt="Ícone de informação"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Atualização disponível</p>
          <p ludsAlertContent class="luds-label-large-default">
            Uma nova versão do aplicativo está pronta para instalação. Atualize para aproveitar os recursos mais
            recentes.
          </p>
        </span>
      </div>
      <div ludsAlert background="flat" data-testid="luds-alert-success-flat" type="success" aria-label="Alerta do tipo sucesso">
        <ng-icon ludsAlertIcon name="phosphorCheckCircle" alt="Ícone de sucesso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Parabéns!</p>
          <p ludsAlertContent class="luds-label-large-default">
            Sua inscrição foi realizada com sucesso. Você receberá um e-mail com os próximos passos.
          </p>
        </span>
      </div>
      <div ludsAlert background="flat" data-testid="luds-alert-warning-flat" type="warning" aria-label="Alerta do tipo aviso">
        <ng-icon ludsAlertIcon name="phosphorWarning" alt="Ícone de aviso"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Aviso</p>
          <p ludsAlertContent class="luds-label-large-default">
            A conexão está instável. Algumas funcionalidades podem não responder corretamente.
          </p>
        </span>
      </div>
      <div ludsAlert background="flat" data-testid="luds-alert-error-flat" type="error" aria-label="Alerta do tipo erro">
        <ng-icon ludsAlertIcon name="phosphorXCircle" alt="Ícone de erro"></ng-icon>
        <span ludsAlertTextContainer>
          <p ludsAlertTitle class="luds-label-large-bold">Erro ao carregar os dados</p>
          <p ludsAlertContent class="luds-label-large-default">O servidor não respondeu. Tente novamente mais tarde.</p>
        </span>
      </div>
    </div>
  `,
  standalone: true,
})
export class AlertBackgroundsDemoComponent {}
