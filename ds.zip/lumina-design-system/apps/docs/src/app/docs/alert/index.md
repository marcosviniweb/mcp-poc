{{ NgDocApi.details("libs/ui/blocks/alert/src/alert.ts#LudsAlert") }}

{{ JSDoc.description("libs/ui/blocks/alert/src/alert.ts#LudsAlert") }}

## Playground

{{ NgDocActions.playground("AlertStandardPlayground") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsAlert } from "@luds/ui/blocks/alert";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorCheckCircle } from "@ng-icons/phosphor-icons/regular";

@Component({
  standalone: true,
  imports: [LudsAlert, NgIcon],
  providers: [provideIcons({ phosphorCheckCircle })],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<div ludsAlert background="soft" type="success" aria-label="Alerta do tipo sucesso">
  <ng-icon ludsAlertIcon name="phosphorCheckCircle" alt="Ícone de sucesso"></ng-icon>
  <span ludsAlertTextContainer>
    <p ludsAlertTitle class="luds-label-large-bold">Parabéns!</p>
    <p ludsAlertContent class="luds-label-large-default">
      Sua inscrição foi realizada com sucesso. Você receberá um e-mail com os próximos passos.
    </p>
  </span>
</div>
```

## Exemplos

### Tipos

{{ NgDocActions.demo("AlertTypesDemoComponent") }}

Veja a documentação da API: `ludsAlertType`

### Tamanhos

{{ NgDocActions.demo("AlertSizesDemoComponent") }}

Veja a documentação da API: `ludsAlertSize`

### Fundos

{{ NgDocActions.demo("AlertBackgroundsDemoComponent") }}

Veja a documentação da API: `ludsAlertBackground`
