import { LudsAlert } from "@luds/ui/blocks/alert";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { AlertTypesDemoComponent } from "./demos/alert-types-demo.component";
import { AlertSizesDemoComponent } from "./demos/alert-sizes-demo.component";
import { AlertBackgroundsDemoComponent } from "./demos/alert-backgrounds-demo.component";
import { phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle } from "@ng-icons/phosphor-icons/regular";

const Alert: NgDocPage = {
  title: `Alert`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  imports: [NgIcon],
  providers: [provideIcons({ phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle })],
  demos: {
    AlertTypesDemoComponent,
    AlertSizesDemoComponent,
    AlertBackgroundsDemoComponent,
  },
  playgrounds: {
    AlertStandardPlayground: {
      target: LudsAlert,
      selectors: "div[ludsAlert]",
      template: `
        <div ludsAlert>
          @switch (properties['type']) {
            @case ('success') {
              <ng-icon ludsAlertIcon  name="phosphorCheckCircle" aria-hidden="true"></ng-icon>
              <span ludsAlertTextContainer>
                <p ludsAlertTitle [class]="properties['size'] === 'default' ? 'luds-label-large-bold' : 'luds-label-medium-bold'">Parabéns!</p>
                <p ludsAlertContent [class]="properties['size'] === 'default' ? 'luds-label-large-default' : 'luds-label-medium-default'">Sua inscrição foi realizada com sucesso. Você receberá um e-mail com os próximos passos.</p>
              </span>
            }
            @case ('info') {
              <ng-icon ludsAlertIcon  name="phosphorInfo" aria-hidden="true"></ng-icon>
              <span ludsAlertTextContainer>
                <p ludsAlertTitle [class]="properties['size'] === 'default' ? 'luds-label-large-bold' : 'luds-label-medium-bold'">Atualização disponível</p>
                <p ludsAlertContent [class]="properties['size'] === 'default' ? 'luds-label-large-default' : 'luds-label-medium-default'">Uma nova versão do aplicativo está pronta para instalação. Atualize para aproveitar os recursos mais recentes.</p>
              </span>
            }
            @case ('warning') {
              <ng-icon ludsAlertIcon  name="phosphorWarning" aria-hidden="true"></ng-icon>
              <span ludsAlertTextContainer>
                <p ludsAlertTitle [class]="properties['size'] === 'default' ? 'luds-label-large-bold' : 'luds-label-medium-bold'">Aviso</p>
                <p ludsAlertContent [class]="properties['size'] === 'default' ? 'luds-label-large-default' : 'luds-label-medium-default'">A conexão está instável. Algumas funcionalidades podem não responder corretamente.</p>
              </span>
            }
            @case ('error') {
              <ng-icon ludsAlertIcon  name="phosphorXCircle" aria-hidden="true"></ng-icon>
              <span ludsAlertTextContainer>
                <p ludsAlertTitle [class]="properties['size'] === 'default' ? 'luds-label-large-bold' : 'luds-label-medium-bold'">Erro ao carregar os dados</p>
                <p ludsAlertContent [class]="properties['size'] === 'default' ? 'luds-label-large-default' : 'luds-label-medium-default'">O servidor não respondeu. Tente novamente mais tarde.</p>
              </span>
            }
          }
        </div>`,
    },
  },
};

export default Alert;
