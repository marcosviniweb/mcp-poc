export { AlertBackgroundsDemoComponent } from './alert-backgrounds-demo.component';
export { AlertSizesDemoComponent } from './alert-sizes-demo.component';
export { AlertTypesDemoComponent } from './alert-types-demo.component';
