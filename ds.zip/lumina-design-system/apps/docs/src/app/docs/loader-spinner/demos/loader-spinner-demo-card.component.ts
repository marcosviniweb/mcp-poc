import { Component } from "@angular/core";
import { LudsLoaderSpinner } from "@luds/ui/blocks/loader-spinner";

@Component({
  selector: "loader-spinner-demo-card",
  imports: [LudsLoaderSpinner],
  template: `
    <section
      ludsCard
      style="display: flex; align-items: center; justify-content: center; width: 280px;"
      data-testid="card-loading"
    >
      <div
        ludsCardContainer
        style="display:flex; flex-direction:column; align-items:center; justify-content:center;"
        data-testid="card-loading-body"
        aria-labelledby="card-loading-title"
        role="status"
      >
        <div ludsLoaderSpinner [size]="'large'" aria-hidden="true" focusable="false"></div>
        <p ludsCardDescription class="luds-body-medium-default">Aguarde um instante</p>
      </div>
    </section>
  `,
  standalone: true,
})
export class LoaderSpinnerDemoCardComponent {}
