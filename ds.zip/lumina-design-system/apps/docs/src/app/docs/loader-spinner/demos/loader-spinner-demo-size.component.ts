import { Component } from '@angular/core';
import { LudsLoaderSpinner } from '@luds/ui/blocks/loader-spinner';

@Component({
  selector: 'loader-spinner-demo-size',
  imports: [LudsLoaderSpinner],
  template: `
    <div style="display: flex; gap: 16px;">
      <div ludsLoaderSpinner size="large" aria-label="carregando"></div>
      <div ludsLoaderSpinner size="default" aria-label="carregando"></div>
      <div ludsLoaderSpinner size="small" aria-label="carregando"></div>
    </div>
  `,

  standalone: true,
})
export class LoaderSpinnerDemoSizeComponent {}
