{{ NgDocApi.details("libs/ui/blocks/loader-spinner/src/loader-spinner.ts#LudsLoaderSpinner") }}

{{ JSDoc.description("libs/ui/blocks/loader-spinner/src/loader-spinner.ts#LudsLoaderSpinner") }}

## Playground

{{ NgDocActions.playground("LudsLoaderSpinnerPlayground") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsLoaderSpinner } from "@luds/ui/blocks/loader-spinner";

@Component({
  standalone: true,
  imports: [LudsLoaderSpinner],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<div ludsLoaderSpinner></div>
```

## Exemplos

### Variantes

{{ NgDocActions.demo("LoaderSpinnerDemoVariantComponent") }}
{{ NgDocActions.demo("LoaderSpinnerDemoVariantNegativeComponent",  {class: "background-demo-grey"}) }}

Veja a documentação da API: `LudsLoaderSpinnerVariant`

### Tamanhos

Os tamanhos `default` e `small` devem ser usados em botões, enquanto o tamanho `large` é recomendado para uso em páginas.
{{ NgDocActions.demo("LoaderSpinnerDemoSizeComponent") }}

Veja a documentação da API: `LudsLoaderSpinnerSize`

### Botões

{{ NgDocActions.demo("LoaderSpinnerDemoButtonComponent") }}

### Card

{{ NgDocActions.demo("LoaderSpinnerDemoCardComponent") }}
