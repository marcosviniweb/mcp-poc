import { Component } from '@angular/core';
import { LudsButton } from '@luds/ui/blocks/button';
import { LudsLoaderSpinner } from '@luds/ui/blocks/loader-spinner';

@Component({
  selector: 'loader-spinner-demo-button',
  imports: [LudsLoaderSpinner, LudsButton],
  template: `
    <div style="display: flex; gap: 16px; flex-direction: column;">
      <div style="display: flex; gap: 16px;">
        <button ludsButton buttonType="icon-button" aria-label="Atualizando dados">
          <div ludsLoaderSpinner variant="negative" size="default" aria-hidden="true"></div>
        </button>
        <button ludsButton buttonType="icon-button" size="small" aria-label="Carregando">
          <div ludsLoaderSpinner variant="negative" size="small" aria-hidden="true"></div>
        </button>
      </div>
      <div style="display: flex; gap: 16px;">
        <button
          ludsButton
          buttonType="icon-button"
          variant="secondary"
          size="small"
          aria-label="Processando"
        >
          <div ludsLoaderSpinner variant="positive" size="default" aria-hidden="true"></div>
        </button>
        <button
          ludsButton
          buttonType="icon-button"
          variant="secondary"
          size="small"
          aria-label="Salvando"
        >
          <div ludsLoaderSpinner variant="positive" size="small" aria-hidden="true"></div>
        </button>
      </div>
    </div>
  `,

  standalone: true,
})
export class LoaderSpinnerDemoButtonComponent {}
