import { Component } from "@angular/core";
import { LudsLoaderSpinner } from "@luds/ui/blocks/loader-spinner";

@Component({
  selector: "loader-spinner-demo-variant-negative",
  imports: [LudsLoaderSpinner],
  template: ` <div ludsLoaderSpinner variant="negative" aria-hidden="true"></div> `,

  standalone: true,
})
export class LoaderSpinnerDemoVariantNegativeComponent {}
