import { Component } from "@angular/core";
import { LudsLoaderSpinner } from "@luds/ui/blocks/loader-spinner";

@Component({
  selector: "loader-spinner-demo-variant",
  imports: [LudsLoaderSpinner],
  template: ` <div ludsLoaderSpinner variant="positive" aria-hidden="carregando"></div> `,

  standalone: true,
})
export class LoaderSpinnerDemoVariantComponent {}
