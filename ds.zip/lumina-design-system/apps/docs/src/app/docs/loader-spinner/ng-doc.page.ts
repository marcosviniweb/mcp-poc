import { LudsLoaderSpinner } from '@luds/ui/blocks/loader-spinner';
import { NgDocPage } from '@ng-doc/core';
import ComponentsCategory from 'apps/docs/src/categories/components/ng-doc.category';
import { LoaderSpinnerDemoSizeComponent } from './demos/loader-spinner-demo-size.component';
import { LoaderSpinnerDemoVariantComponent } from './demos/loader-spinner-demo-variant.component';
import { LoaderSpinnerDemoButtonComponent } from './demos/loader-spinner-demo-button.component';
import { LoaderSpinnerDemoVariantNegativeComponent } from './demos/loader-spinner-demo-variant-negative.component';
import { LoaderSpinnerDemoCardComponent } from './demos';

const LoaderSpinner: NgDocPage = {
  title: `Loader Spinner`,
  mdFile: './index.md',
  category: ComponentsCategory,
  imports: [LudsLoaderSpinner],
  demos: {
    LoaderSpinnerDemoSizeComponent,
    LoaderSpinnerDemoButtonComponent,
    LoaderSpinnerDemoVariantComponent,
    LoaderSpinnerDemoVariantNegativeComponent,
    LoaderSpinnerDemoCardComponent
  },
  playgrounds: {
    LudsLoaderSpinnerPlayground: {
      target: LudsLoaderSpinner,
      selectors: '[ludsLoaderSpinner]',
      template: `
        <div ludsLoaderSpinner aria-label="carregando"></div>`,
    },
  },
};

export default LoaderSpinner;
