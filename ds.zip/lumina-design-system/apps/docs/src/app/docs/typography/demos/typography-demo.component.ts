import { Component } from "@angular/core";
import { NgDocHeadingAnchorComponent } from "@ng-doc/app/components/heading-anchor";
import { capitalizeFirstLetter, convertRemToPx } from "../../../utils";
import { TypographySwatchComponent } from "../typography-swatch/typography-swatch.component";
// Lidar com import dinâmico num cenário de multi-temas
import typographyTokens from "@luds/ui/styles/themes/default/build/utils/ts/typography";

const includedStyles = {
  "font": "Font",
  "font-size": "Size",
  "font-weight": "Weight",
  "line-height": "Line height",
  "text-decoration-line": "Decoration",
} as const;

const fontWeights: Record<string, string> = {
  "100": "Thin",
  "200": "Extra Light",
  "300": "Light",
  "400": "Regular",
  "500": "Medium",
  "600": "Semi Bold",
  "700": "Bold",
  "800": "Extra Bold",
  "900": "Black",
};

@Component({
  selector: "typography-demo",
  imports: [NgDocHeadingAnchorComponent, TypographySwatchComponent],
  styles: `
    .typography-category {
      display: flex;
      flex-direction: column;
      margin-bottom: 3.5rem;
      h3 {
        padding-bottom: var(--luds-spacing-xs);
      }
      .typography-row {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        column-gap: 2.25rem;
        border-top: 1px solid var(--luds-color-stroke-main);
        padding-top: var(--luds-spacing-m);
        padding-bottom: var(--luds-spacing-m);
      }
    }
    .typography-font-family {
      margin-bottom: var(--luds-spacing-xxg);
    }
  `,
  template: `
    @for (category of categoryEntries; track category[0]) {
      <div class="typography-category">
        <h3 class="luds-title-small" [id]="category[0]" headinglink="true">
          {{ category[0] }}
          <ng-doc-heading-anchor [anchor]="category[0]"></ng-doc-heading-anchor>
        </h3>
        @for (row of category[1]; track $index) {
          <div class="typography-row">
            @for (class of row; track class.className) {
              <typography-swatch [className]="class.className" [styles]="class.styles" [title]="class.title">
              </typography-swatch>
            }
          </div>
        }
      </div>
    }
  `,
  standalone: true,
})
export class TypographyDemoComponent {
  readonly categoryEntries: [string, any[][]][] = Object.entries(
    Object.entries(typographyTokens)
      .map(([className, styles]) => {
        const nameArray = className.split("-");
        nameArray.shift();

        return {
          category: capitalizeFirstLetter(nameArray[0]),
          title: nameArray.map(capitalizeFirstLetter).join(" "),
          className,
          styles: Object.entries(styles)
            .filter(([prop]) => prop in includedStyles)
            .map(([prop, value]) => ({
              key: includedStyles[prop as keyof typeof includedStyles],
              value: this.transformValues(prop, String(value)),
            })),
        };
      })
      .reduce(
        (acc, item) => {
          if (!acc[item.category]) acc[item.category] = [];
          acc[item.category].push(item);
          return acc;
        },
        {} as Record<string, any[]>,
      ),
  ).map(([categoryName, items]) => [
    categoryName,
    Array.from({ length: Math.ceil(items.length / 3) }, (_, index) => items.slice(index * 3, index * 3 + 3)),
  ]);

  transformValues(prop: string, value: string) {
    switch (prop) {
      case "font-size":
        return value.includes("rem") ? `${convertRemToPx(value)} / ${value}` : value;
      case "font-weight":
        return `${fontWeights[value]} (${value})`;
      default:
        return value;
    }
  }
}
