import { Component, input } from "@angular/core";
import { NgDocCopyButtonComponent } from "@ng-doc/app/components/copy-button";
import { NgDocIconComponent } from "@ng-doc/ui-kit/components/icon";

@Component({
  selector: "typography-swatch",
  imports: [NgDocCopyButtonComponent, NgDocIconComponent],
  standalone: true,
  styles: `
    .typography-swatch-container {
      display: flex;
      flex-direction: column;
      row-gap: var(--luds-spacing-s);
    }
    .typography-swatch-copy-content {
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      align-items: center;
      column-gap: var(--luds-spacing-xs);
    }
    .typography-swatch-class-name {
      display: flex;
      align-items: center;
      gap: var(--luds-spacing-xs);
    }
  `,
  template: `
    <div class="luds-body-large-default typography-swatch-container">
      <span [class]="className()">{{ title() }}</span>
      <div>
        @for (style of styles(); track style.key) {
          <div>{{ style.key }}: {{ style.value }}</div>
        }
        <div class="typography-swatch-copy-content">
          class:
          <div class="typography-swatch-class-name">
            <span class="luds-body-large-bold">{{ className() }}</span>
            <ng-doc-copy-button [text]="className()">
              <ng-doc-icon icon="copy"></ng-doc-icon>
            </ng-doc-copy-button>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class TypographySwatchComponent {
  public className = input.required<string>();
  public styles = input.required<any[]>();
  public title = input.required<string>();
}
