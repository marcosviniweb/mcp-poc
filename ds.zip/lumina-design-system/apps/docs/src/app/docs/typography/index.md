O sistema tipográfico do Lumina DS é estruturado por meio de **tokens tipográficos**, que padronizam atributos como **tamanhos**, **pesos**, **espaçamentos** e **alturas de linha**. Essa abordagem promove consistência visual, facilita a manutenção e assegura escalabilidade em diferentes plataformas e contextos de uso. 

{{ NgDocActions.demo("TypographyDemoComponent", { container: false }) }}
