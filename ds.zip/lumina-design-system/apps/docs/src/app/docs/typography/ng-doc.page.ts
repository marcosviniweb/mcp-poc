import { NgDocPage } from '@ng-doc/core';
import DesignTokensCategory from 'apps/docs/src/categories/design-tokens/ng-doc.category';
import { TypographyDemoComponent } from './demos/typography-demo.component';

const Typography: NgDocPage = {
  title: `Tipografia`,
  mdFile: './index.md',
  category: DesignTokensCategory,
  demos: { TypographyDemoComponent },
};

export default Typography;
