{{ NgDocApi.details("libs/ui/blocks/tag/src/tag.ts#LudsTag") }}

{{ JSDoc.description("libs/ui/blocks/tag/src/tag.ts#LudsTag") }}

## Playground

{{ NgDocActions.playground("TagStandardPlayground") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsTag } from "@luds/ui/blocks/tag";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorCheckCircle } from "@ng-icons/phosphor-icons/regular";

@Component({
  standalone: true,
  imports: [LudsTag, NgIcon],
  providers: [provideIcons({ phosphorCheckCircle })],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<span ludsTag type="success" size="small" background="filled">
  <ng-icon name="phosphorCheckCircle"></ng-icon>
  Atualizado
</span>
```

## Exemplos

### Tipos

{{ NgDocActions.demo("TagTypesDemoComponent") }}

Veja a documentação da API: `LudsTagType`

### Tamanhos

{{ NgDocActions.demo("TagSizesDemoComponent") }}

A Tag permite a exibição de texto com até 90 caracteres. Deste modo, todos os caracteres acima disso não são exibidos.

Por exemplo, o texto a seguir contém 107 caracteres e não será completamente exibido dentro de uma Tag.

> "A inovação transforma ideias em soluções reais, conectando pessoas, promovendo inclusão e criando o futuro."
> {{ NgDocActions.demo("TagSizeMaxCharactersDemoComponent") }}

Veja a documentação da API: `LudsTagSize`

### Fundos

{{ NgDocActions.demo("TagBackgroundsDemoComponent") }}

Veja a documentação da API: `LudsTagBackground`
