export { TagBackgroundsDemoComponent } from './tag-backgrounds-demo.component';
export { TagSizeMaxCharactersDemoComponent } from './tag-size-max-characters-demo.component';
export { TagSizesDemoComponent } from './tag-sizes-demo.component';
export { TagTypesDemoComponent } from './tag-types-demo.component';
