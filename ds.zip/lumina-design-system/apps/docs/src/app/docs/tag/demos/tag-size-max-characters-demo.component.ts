import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsTag } from "@luds/ui/blocks/tag";
import { phosphorInfo } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "tag-size-max-characters-demo",
  imports: [LudsTag, NgIcon],
  providers: [provideIcons({ phosphorInfo })],
  template: `
    <div style="display: grid; gap: 1rem;">
      <span ludsTag type="info">
        <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
        <p class="luds-label-large-bold">
          A inovação transforma ideias em soluções reais, conectando pessoas, promovendo inclusão e criando o futuro.
        </p>
      </span>

      <span ludsTag type="info" background="soft">
        <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
        <p class="luds-label-large-bold">
          A inovação transforma ideias em soluções reais, conectando pessoas, promovendo inclusão e criando o futuro.
        </p>
      </span>

      <span ludsTag type="info" background="flat">
        <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
        <p class="luds-label-large-bold">
          A inovação transforma ideias em soluções reais, conectando pessoas, promovendo inclusão e criando o futuro.
        </p>
      </span>

      <span ludsTag type="info" size="small">
        <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
        <p class="luds-label-medium-bold">
          A inovação transforma ideias em soluções reais, conectando pessoas, promovendo inclusão e criando o futuro.
        </p>
      </span>

      <span ludsTag type="info" size="small" background="soft">
        <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
        <p class="luds-label-medium-bold">
          A inovação transforma ideias em soluções reais, conectando pessoas, promovendo inclusão e criando o futuro.
        </p>
      </span>

      <span ludsTag type="info" size="small" background="flat">
        <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
        <p class="luds-label-medium-bold">
          A inovação transforma ideias em soluções reais, conectando pessoas, promovendo inclusão e criando o futuro.
        </p>
      </span>
    </div>
  `,
  standalone: true,
})
export class TagSizeMaxCharactersDemoComponent {}
