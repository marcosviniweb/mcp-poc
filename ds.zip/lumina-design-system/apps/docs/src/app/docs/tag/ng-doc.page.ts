import { LudsTag } from "@luds/ui/blocks/tag";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { TagTypesDemoComponent } from "./demos/tag-types-demo.component";
import { TagSizesDemoComponent } from "./demos/tag-sizes-demo.component";
import { TagSizeMaxCharactersDemoComponent } from "./demos/tag-size-max-characters-demo.component";
import { TagBackgroundsDemoComponent } from "./demos/tag-backgrounds-demo.component";
import { phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle } from "@ng-icons/phosphor-icons/regular";

const Tag: NgDocPage = {
  title: `Tag`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  imports: [NgIcon],
  providers: [provideIcons({ phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle })],
  demos: {
    TagTypesDemoComponent,
    TagSizesDemoComponent,
    TagSizeMaxCharactersDemoComponent,
    TagBackgroundsDemoComponent,
  },
  playgrounds: {
    TagStandardPlayground: {
      target: LudsTag,
      template: `
        <span ludsTag>
          @switch (properties['type']) {
            @case ('success') {
              <ng-icon ludsTagIcon  name="phosphorCheckCircle" aria-hidden="true"></ng-icon>
            }
            @case ('info') {
              <ng-icon ludsTagIcon  name="phosphorInfo" aria-hidden="true"></ng-icon>
            }
            @case ('warning') {
              <ng-icon ludsTagIcon  name="phosphorWarning" aria-hidden="true"></ng-icon>
            }
            @case ('error') {
              <ng-icon ludsTagIcon  name="phosphorXCircle" aria-hidden="true"></ng-icon>
            }
          }
          <p [class]="properties['size'] === 'default' ? 'luds-label-large-bold' : 'luds-label-medium-bold'">title</p>
        </span>`,
    },
  },
};

export default Tag;
