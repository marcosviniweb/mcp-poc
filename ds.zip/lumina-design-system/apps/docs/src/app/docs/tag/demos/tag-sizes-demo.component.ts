import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsTag } from "@luds/ui/blocks/tag";
import { phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "tag-sizes-demo",
  imports: [LudsTag, NgIcon],
  providers: [provideIcons({ phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle })],
  template: `
    <div style="display: grid; gap: 1rem;">
      <div style="display: flex; align-items: center; gap: 1rem;">
        <span ludsTag type="success">
          <ng-icon ludsTagIcon name="phosphorCheckCircle"></ng-icon>
          <p class="luds-label-large-bold">Success</p>
        </span>

        <span ludsTag type="success" size="small">
          <ng-icon ludsTagIcon name="phosphorCheckCircle"></ng-icon>
          <p class="luds-label-medium-bold">Success</p>
        </span>
      </div>

      <div style="display: flex; align-items: center; gap: 1rem;">
        <span ludsTag type="info">
          <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
          <p class="luds-label-large-bold">Info</p>
        </span>

        <span ludsTag type="info" size="small">
          <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
          <p class="luds-label-medium-bold">Info</p>
        </span>
      </div>

      <div style="display: flex; align-items: center; gap: 1rem;">
        <span ludsTag type="warning">
          <ng-icon ludsTagIcon name="phosphorWarning"></ng-icon>
          <p class="luds-label-large-bold">Warning</p>
        </span>

        <span ludsTag type="warning" size="small">
          <ng-icon ludsTagIcon name="phosphorWarning"></ng-icon>
          <p class="luds-label-medium-bold">Warning</p>
        </span>
      </div>

      <div style="display: flex; align-items: center; gap: 1rem;">
        <span ludsTag type="error">
          <ng-icon ludsTagIcon name="phosphorXCircle"></ng-icon>
          <p class="luds-label-large-bold">Error</p>
        </span>

        <span ludsTag type="error" size="small">
          <ng-icon ludsTagIcon name="phosphorXCircle"></ng-icon>
          <p class="luds-label-medium-bold">Error</p>
        </span>
      </div>
    </div>
  `,
  standalone: true,
})
export class TagSizesDemoComponent {}
