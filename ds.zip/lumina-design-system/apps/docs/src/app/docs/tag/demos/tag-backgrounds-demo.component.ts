import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsTag } from "@luds/ui/blocks/tag";
import { phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "tag-backgrounds-demo",
  imports: [LudsTag, NgIcon],
  providers: [provideIcons({ phosphorCheckCircle, phosphorInfo, phosphorWarning, phosphorXCircle })],
  template: `
    <div style="display: grid; gap: 1rem;">
      <div style="display: flex; align-items: center; gap: 1rem;">
        <span ludsTag type="success">
          <ng-icon ludsTagIcon name="phosphorCheckCircle"></ng-icon>
          <p class="luds-label-large-bold">Success</p>
        </span>

        <span ludsTag type="success" background="soft">
          <ng-icon ludsTagIcon name="phosphorCheckCircle"></ng-icon>
          <p class="luds-label-large-bold">Success</p>
        </span>

        <span ludsTag type="success" background="flat">
          <ng-icon ludsTagIcon name="phosphorCheckCircle"></ng-icon>
          <p class="luds-label-large-bold">Success</p>
        </span>
      </div>

      <div style="display: flex; align-items: center; gap: 1rem;">
        <span ludsTag type="info">
          <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
          <p class="luds-label-large-bold">Info</p>
        </span>

        <span ludsTag type="info" background="soft">
          <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
          <p class="luds-label-large-bold">Info</p>
        </span>

        <span ludsTag type="info" background="flat">
          <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
          <p class="luds-label-large-bold">Info</p>
        </span>
      </div>

      <div style="display: flex; align-items: center; gap: 1rem;">
        <span ludsTag type="warning">
          <ng-icon ludsTagIcon name="phosphorWarning"></ng-icon>
          <p class="luds-label-large-bold">Warning</p>
        </span>

        <span ludsTag type="warning" background="soft">
          <ng-icon ludsTagIcon name="phosphorWarning"></ng-icon>
          <p class="luds-label-large-bold">Warning</p>
        </span>

        <span ludsTag type="warning" background="flat">
          <ng-icon ludsTagIcon name="phosphorWarning"></ng-icon>
          <p class="luds-label-large-bold">Warning</p>
        </span>
      </div>

      <div style="display: flex; align-items: center; gap: 1rem;">
        <span ludsTag type="error">
          <ng-icon ludsTagIcon name="phosphorXCircle"></ng-icon>
          <p class="luds-label-large-bold">Error</p>
        </span>

        <span ludsTag type="error" background="soft">
          <ng-icon ludsTagIcon name="phosphorXCircle"></ng-icon>
          <p class="luds-label-large-bold">Error</p>
        </span>

        <span ludsTag type="error" background="flat">
          <ng-icon ludsTagIcon name="phosphorXCircle"></ng-icon>
          <p class="luds-label-large-bold">Error</p>
        </span>
      </div>
    </div>
  `,
  standalone: true,
})
export class TagBackgroundsDemoComponent {}
