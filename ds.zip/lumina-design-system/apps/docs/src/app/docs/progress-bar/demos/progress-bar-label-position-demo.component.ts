import { Component, computed, signal } from "@angular/core";
import {
  LudsProgressBar,
  LudsProgressBarIndicator,
  LudsProgressBarLabel,
  LudsProgressBarTrack,
  LudsProgressBarValueTextFn,
} from "@luds/ui/blocks/progress-bar";
import { injectDisposables } from "@luds/ui/blocks/utils";

@Component({
  selector: "progress-bar-label-position-demo",
  imports: [LudsProgressBar, LudsProgressBarIndicator, LudsProgressBarTrack, LudsProgressBarLabel],
  standalone: true,
  styles: `
    .container {
      display: flex;
      flex-direction: column;
      gap: 2rem;
      [ludsProgressBar] {
        margin-top: 0.25rem;
      }
    }
  `,
  template: `
    <div class="container">
      <div>
        <span class="luds-body-large-default">Acima (top)</span>
        <div
          ludsProgressBar
          [ludsProgressBarValue]="value()"
          ludsProgressBarLabelPosition="top"
          [ludsProgressBarMax]="maxValue()"
          [ludsProgressBarValueLabel]="getValueText"
        >
          <span ludsProgressBarLabel class="luds-label-medium-default">{{ valueText() }}</span>

          <div ludsProgressBarTrack>
            <div ludsProgressBarIndicator></div>
          </div>
        </div>
      </div>

      <div>
        <span class="luds-body-large-default">À direita (right)</span>
        <div
          ludsProgressBar
          [ludsProgressBarValue]="value()"
          ludsProgressBarLabelPosition="right"
          [ludsProgressBarMax]="maxValue()"
          [ludsProgressBarValueLabel]="getValueText"
        >
          <span ludsProgressBarLabel class="luds-label-medium-default">{{ valueText() }}</span>

          <div ludsProgressBarTrack>
            <div ludsProgressBarIndicator></div>
          </div>
        </div>
      </div>

      <div>
        <span class="luds-body-large-default">Abaixo (bottom)</span>
        <div
          ludsProgressBar
          [ludsProgressBarValue]="value()"
          ludsProgressBarLabelPosition="bottom"
          [ludsProgressBarMax]="maxValue()"
          [ludsProgressBarValueLabel]="getValueText"
        >
          <span ludsProgressBarLabel class="luds-label-medium-default">{{ valueText() }}</span>

          <div ludsProgressBarTrack>
            <div ludsProgressBarIndicator></div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ProgressBarLabelPositionDemoComponent {
  readonly value = signal(0);
  readonly maxValue = signal(80);

  getValueText: LudsProgressBarValueTextFn = (value, max) => {
    return `${value} de ${max} documentos`;
  };

  readonly valueText = computed(() => this.getValueText(this.value(), this.maxValue()));
  /**
   * Usar os helpers disposable para garantir que o intervalo é limpo quando o componente é destruído.
   */
  readonly disposables = injectDisposables();

  constructor() {
    this.disposables.setInterval(() => this.value.update((value) => (value >= this.maxValue() ? 0 : value + 1)), 150);
  }
}
