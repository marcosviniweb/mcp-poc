import { Component, computed, signal } from "@angular/core";
import {
  LudsProgressBar,
  LudsProgressBarIndicator,
  LudsProgressBarTrack,
  LudsProgressBarLabel,
  LudsProgressBarValueTextFn,
} from "@luds/ui/blocks/progress-bar";
import { injectDisposables } from "@luds/ui/blocks/utils";

@Component({
  selector: "progress-bar-high-contrast-demo",
  imports: [LudsProgressBar, LudsProgressBarIndicator, LudsProgressBarTrack, LudsProgressBarLabel],
  standalone: true,
  template: `
    <div>
      <div
        ludsProgressBar
        [ludsProgressBarValue]="currentStep()"
        [ludsProgressBarMax]="finalStep()"
        ludsProgressBarLabelPosition="top"
        ludsProgressBarVariant="high-contrast"
        [ludsProgressBarValueLabel]="getValueText"
      >
        <span ludsProgressBarLabel class="luds-label-medium-default">{{ valueText() }}</span>

        <div ludsProgressBarTrack>
          <div ludsProgressBarIndicator></div>
        </div>
      </div>
    </div>
  `,
})
export class ProgressBarHighContrastDemoComponent {
  readonly currentStep = signal(0);
  readonly finalStep = signal(4);

  getValueText: LudsProgressBarValueTextFn = (step, total) => {
    return `${step} de ${total}`;
  };

  readonly valueText = computed(() => this.getValueText(this.currentStep(), this.finalStep()));

  /**
   * Usar os helpers disposable para garantir que o intervalo é limpo quando o componente é destruído.
   */
  readonly disposables = injectDisposables();

  constructor() {
    this.disposables.setInterval(() => this.currentStep.update((step) => (step >= this.finalStep() ? 0 : step + 1)), 1500);
  }
}
