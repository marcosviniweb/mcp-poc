{{ NgDocApi.details("libs/ui/blocks/progress-bar/src/progress-bar/progress-bar.ts#LudsProgressBar") }}

{{ JSDoc.description("libs/ui/blocks/progress-bar/src/progress-bar/progress-bar.ts#LudsProgressBar") }}

## Playground

{{ NgDocActions.playground("ProgressBarPlayground") }}

## Importação

```typescript name="my-component.ts" group="progress-example"
import { 
  LudsProgressBar, 
  LudsProgressBarIndicator, 
  LudsProgressBarTrack, 
  LudsProgressBarLabel 
} from "@luds/ui/blocks/progress-bar";

@Component({
  standalone: true,
  imports: [LudsProgressBar, LudsProgressBarIndicator, LudsProgressBarTrack, LudsProgressBarLabel],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="progress-example"
<div ludsProgressBar [ludsProgressBarValue]="50">
  <span ludsProgressBarLabel>{{ 50 }}%</span>

  <div ludsProgressBarTrack>
    <div ludsProgressBarIndicator></div>
  </div>
</div>
```

## Exemplos

### Status do Progresso

{{ NgDocActions.demo("ProgressBarStatusDemoComponent") }}

### Posições do Label

{{ NgDocActions.demo("ProgressBarLabelPositionDemoComponent") }}

### Contraste de Fundo

{{ NgDocActions.demo("ProgressBarHighContrastDemoComponent", { class: "background-demo-grey" }) }}

{{ NgDocActions.demo("ProgressBarLowContrastDemoComponent") }}
