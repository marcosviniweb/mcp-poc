import { Component, signal } from "@angular/core";
import { LudsProgressBar, LudsProgressBarIndicator, LudsProgressBarTrack, LudsProgressBarLabel } from "@luds/ui/blocks/progress-bar";
import { injectDisposables } from "@luds/ui/blocks/utils";

@Component({
  selector: "progress-bar-status-demo",
  imports: [LudsProgressBar, LudsProgressBarIndicator, LudsProgressBarTrack, LudsProgressBarLabel],
  standalone: true,
  styles: `
    .container {
      display: flex;
      flex-direction: column;
      gap: 2rem;
      [ludsProgressBar] {
        margin-top: 0.25rem;
      }
    }
  `,
  template: `
    <div class="container">
      <div>
        <span class="luds-body-large-default">Em progresso (in-progress)</span>
        <div ludsProgressBar [ludsProgressBarValue]="currentValue()" [ludsProgressBarMax]="totalValue()">
          <span ludsProgressBarLabel class="luds-label-medium-default">{{ percentage() }}</span>
          <div ludsProgressBarTrack>
            <div ludsProgressBarIndicator></div>
          </div>
        </div>
      </div>

      <div>
        <span class="luds-body-large-default">Com erro (error)</span>
        <div ludsProgressBar [ludsProgressBarValue]="99" ludsProgressBarStatus="error">
          <span ludsProgressBarLabel class="luds-label-medium-default">Erro no envio</span>

          <div ludsProgressBarTrack>
            <div ludsProgressBarIndicator></div>
          </div>
        </div>
      </div>

      <div>
        <span class="luds-body-large-default">Indeterminado (indeterminate)</span>
        <div ludsProgressBar ludsProgressBarStatus="indeterminate">
          <span ludsProgressBarLabel class="luds-label-medium-default">Processando...</span>

          <div ludsProgressBarTrack>
            <div ludsProgressBarIndicator></div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ProgressBarStatusDemoComponent {
  readonly currentValue = signal(0);
  readonly totalValue = signal(120);

  /**
   * Usar os helpers disposable para garantir que o intervalo é limpo quando o componente é destruído.
   */
  readonly disposables = injectDisposables();

  percentage() {
    return `${Math.round((this.currentValue() / this.totalValue()) * 100)}%`;
  }

  constructor() {
    this.disposables.setInterval(() => this.currentValue.update((value) => (value >= this.totalValue() ? 0 : value + 1)), 150);
  }
}
