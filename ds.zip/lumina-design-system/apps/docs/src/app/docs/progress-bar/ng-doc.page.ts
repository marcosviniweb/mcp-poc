import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import {
  ProgressBarHighContrastDemoComponent,
  ProgressBarLowContrastDemoComponent,
  ProgressBarLabelPositionDemoComponent,
  ProgressBarStatusDemoComponent,
} from "./demos";
import {
  LudsProgressBar,
  LudsProgressBarIndicator,
  LudsProgressBarLabel,
  LudsProgressBarTrack,
} from "@luds/ui/blocks/progress-bar";

const ProgressBar: NgDocPage = {
  title: `Progress Bar`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  demos: {
    ProgressBarHighContrastDemoComponent,
    ProgressBarLowContrastDemoComponent,
    ProgressBarLabelPositionDemoComponent,
    ProgressBarStatusDemoComponent,
  },
  imports: [LudsProgressBar, LudsProgressBarLabel, LudsProgressBarTrack, LudsProgressBarIndicator],
  playgrounds: {
    ProgressBarPlayground: {
      target: LudsProgressBar,
      selectors: "[ludsProgressBar]",
      template: `
        <div ludsProgressBar>
          <span ludsProgressBarLabel class="luds-label-medium-default">
            {{
              properties['status'] == 'indeterminate' 
              || properties['value'] == null 
              || properties['max'] == null 
              || properties['max'] == 0
                ? 'carregando...'
                : ((properties['value'] / properties['max']) * 100).toFixed(0) + '%'
            }}
          </span>
          <div ludsProgressBarTrack>
            <div ludsProgressBarIndicator></div>
          </div>
        </div>
      `,
      controls: {
        value: { type: "number", alias: "ludsProgressBarValue" },
      },
      defaults: {
        value: 75,
      },
      hiddenInputs: ["min", "variant", "valueLabel"],
    },
  },
};

export default ProgressBar;
