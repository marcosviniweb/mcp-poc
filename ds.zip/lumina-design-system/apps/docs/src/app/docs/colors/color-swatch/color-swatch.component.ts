import { Component, computed, input } from '@angular/core';
import { NgDocCopyButtonComponent } from '@ng-doc/app/components/copy-button';
import { NgDocIconComponent } from '@ng-doc/ui-kit/components/icon';

@Component({
  selector: 'color-swatch',
  imports: [NgDocCopyButtonComponent, NgDocIconComponent],
  standalone: true,
  styles: `
    .color-swatch-container {
      display: flex;
      flex-direction: column;
      width: 160px;
      gap: var(--luds-spacing-xs);
    }
    .color-preview {
      width: 100%;
      height: 140px;
      border: 1px solid var(--luds-color-background-disabled);
    }
    .color-info {
      display: flex;
      flex-direction: row;
      justify-content: flex-start;
      align-items: center;
    }
  `,
  template: `
    <div class="color-swatch-container luds-body-medium-default">
      <div class="color-preview" [style.background-color]="hexcode()"></div>
      <span class="luds-body-large-bold">{{ colorName() }}</span>
      <div class="color-info">
        <span>{{ token() }}</span>
        <ng-doc-copy-button [text]="token()">
          <ng-doc-icon icon="copy"></ng-doc-icon>
        </ng-doc-copy-button>
      </div>
      <span>{{ hexcode().toUpperCase() }}</span>
    </div>
  `,
})
export class ColorSwatchComponent {
  public token = input.required<string>();
  public hexcode = input.required<string>();
  public name = input<string>('');

  readonly colorName = computed(
    () => this.name() || this.token().split('-').pop()
  );
}
