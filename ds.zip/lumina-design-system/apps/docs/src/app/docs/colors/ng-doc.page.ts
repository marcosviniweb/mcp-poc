import { NgDocPage } from '@ng-doc/core';
import DesignTokensCategory from 'apps/docs/src/categories/design-tokens/ng-doc.category';
import { ColorsDemoComponent } from './demos/colors-demo.component';

const Colors: NgDocPage = {
  title: `Cores`,
  mdFile: './index.md',
  category: DesignTokensCategory,
  demos: { ColorsDemoComponent },
};

export default Colors;
