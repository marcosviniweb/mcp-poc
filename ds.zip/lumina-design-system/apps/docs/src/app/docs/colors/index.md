No Lumina DS as cores são definidas através dos **tokens de cores**. Essa abordagem permite maior **escalabilidade** e **manutenção**, garantindo que a aplicação das cores seja consistente, eficiente e alinhada com os princípios da marca em todos os contextos de uso.

{{ NgDocActions.demo("ColorsDemoComponent", { container: false }) }}
