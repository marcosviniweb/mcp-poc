import { Component } from "@angular/core";
import { NgDocHeadingAnchorComponent } from "@ng-doc/app/components/heading-anchor";
import { ColorSwatchComponent } from "../color-swatch/color-swatch.component";
import { capitalizeFirstLetter } from "../../../utils";
// Lidar com import dinâmico num cenário de multi-temas
import colorTokens from "@luds/ui/styles/themes/default/build/semantic/ts/colors";

@Component({
  selector: "colors-demo",
  imports: [ColorSwatchComponent, NgDocHeadingAnchorComponent],
  styles: `
    .color-category {
      display: flex;
      flex-wrap: wrap;
      gap: var(--luds-spacing-s);
      width: 100%;
      max-width: 50rem;
      border-top: 1px solid var(--luds-color-stroke-main);
      padding: 0.75rem 0 var(--luds-spacing-xg);
    }
    .colors-container {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      h3 {
        margin: 0;
      }
    }
  `,
  template: `
    <div class="colors-container">
      @for (cat of colorCategories; track cat.category) {
        <h3 class="luds-title-small" [id]="cat.category" headinglink="true">
          {{ getCategory(cat.category) }}
          <ng-doc-heading-anchor [anchor]="cat.category"></ng-doc-heading-anchor>
        </h3>
        <div class="color-category">
          @for (color of cat.colorsArray; track color.name) {
            <color-swatch [hexcode]="color.hexcode" [token]="color.token" [name]="color.name"></color-swatch>
          }
        </div>
      }
    </div>
  `,
  standalone: true,
})
export class ColorsDemoComponent {
  readonly colorCategories = Object.entries(colorTokens.color).map(([category, colors]) => ({
    category,
    colorsArray: Object.entries(colors as Record<string, { name: string; value: string }>).map(
      ([name, { name: token, value: hexcode }]) => ({
        name,
        token: `--${token}`,
        hexcode,
      }),
    ),
  }));

  getCategory(category: string) {
    return capitalizeFirstLetter(category);
  }
}
