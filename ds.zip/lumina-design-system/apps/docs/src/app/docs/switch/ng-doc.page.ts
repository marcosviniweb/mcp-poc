import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { SwitchDemoComponent } from "./demos/switch-demo.component";
import { SwitchFormFieldDemoComponent } from "./demos/switch-form-field-demo.component";
import { SwitchFormFieldEventEmitDemoComponent } from "./demos/switch-form-field-event-emit-demo.component";
import { SwitchPreviewDemoComponent } from "./demos/switch-preview-demo.component";

const Switch: NgDocPage = {
  title: `Switch`,
  mdFile: "./index.md",
  category: ComponentsCategory,

  demos: { SwitchDemoComponent, SwitchFormFieldDemoComponent, SwitchFormFieldEventEmitDemoComponent, SwitchPreviewDemoComponent },
};

export default Switch;
