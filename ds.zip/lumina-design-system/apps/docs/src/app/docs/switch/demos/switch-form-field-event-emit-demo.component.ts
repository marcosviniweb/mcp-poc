import { Component } from "@angular/core";
import { FormControl, ReactiveFormsModule } from "@angular/forms";
import { LudsFormField } from "@luds/ui/blocks/form-field";
import { LudsSwitch, LudsSwitchThumb } from "@luds/ui/blocks/switch";

@Component({
  selector: "switch-form-field-event-demo",
  standalone: true,
  imports: [LudsSwitch, LudsSwitchThumb, LudsFormField, ReactiveFormsModule],
  template: `
    <div ludsFormField>
      <div ludsSwitchContainer>
        <button
          ludsSwitch
          id="switch-4"
          [ludsSwitchChecked]="switchControl.value"
          (ludsSwitchCheckedChange)="onSwitchChange($event)"
        >
          <span ludsSwitchThumb></span>
        </button>
        <label ludsSwitchLabel for="switch-4" class="luds-body-large-default">
          Título
          <span class="luds-note-large-default">Conteúdo.</span>
        </label>
      </div>
    </div>
  `,
})
export class SwitchFormFieldEventEmitDemoComponent {
  readonly switchControl = new FormControl(false);

  onSwitchChange(checked: boolean): void {
    this.switchControl.setValue(checked);
    alert(`Switch alterado para: ${checked ? "ativado" : "desativado"}`);
  }
}
