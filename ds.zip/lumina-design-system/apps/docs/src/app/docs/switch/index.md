{{ NgDocApi.details("libs/ui/blocks/switch/src/switch/switch.ts#LudsSwitch") }}

{{ JSDoc.description("libs/ui/blocks/switch/src/switch/switch.ts#LudsSwitch") }}

## Preview

{{ NgDocActions.demo("SwitchPreviewDemoComponent") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsSwitch, LudsSwitchThumb } from "@luds/ui/blocks/switch";

@Component({
  standalone: true,
  imports: [LudsSwitch, LudsSwitchThumb],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<div ludsSwitchContainer>
  <button ludsSwitch id="switch">
    <span ludsSwitchThumb></span>
  </button>
  <label ludsSwitchLabel for="switch" class="luds-body-large-default">
    Title
    <span class="luds-note-large-default">Content.</span>
  </label>
</div>
```

## Exemplos

### Uso simples

{{ NgDocActions.demo("SwitchDemoComponent") }}

### Reactive Forms

{{ NgDocActions.demo("SwitchFormFieldDemoComponent") }}

### Emitindo eventos

{{ NgDocActions.demo("SwitchFormFieldEventEmitDemoComponent") }}
