import { Component } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { LudsSwitch, LudsSwitchThumb } from "@luds/ui/blocks/switch";

@Component({
  selector: "switch-demo",
  standalone: true,
  imports: [LudsSwitch, LudsSwitchThumb, ReactiveFormsModule],
  template: `
    <div ludsSwitchContainer>
      <button ludsSwitch id="switch-2">
        <span ludsSwitchThumb></span>
      </button>
      <label ludsSwitchLabel for="switch-2" class="luds-body-large-default">
        Título
        <span class="luds-note-large-default">Conteúdo.</span>
      </label>
    </div>
  `,
})
export class SwitchDemoComponent {}
