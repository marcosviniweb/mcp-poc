export { SwitchFormFieldDemoComponent } from './switch-form-field-demo.component';
export { SwitchDemoComponent } from './switch-demo.component';
export { SwitchFormFieldEventEmitDemoComponent } from './switch-form-field-event-emit-demo.component';