import { Component, signal } from '@angular/core';
import { LudsRadioGroup, LudsRadioIndicator, LudsRadioItem } from '@luds/ui/blocks/radio';

@Component({
  selector: 'radio-title-and-content-demo-component',
  imports: [LudsRadioGroup, LudsRadioItem, LudsRadioIndicator ],
  template: `
    <div [(ludsRadioGroupValue)]="corFavorita"
      ludsRadioGroup
      ludsRadioGroupOrientation="vertical"
    >
    <div ludsRadioItem ludsRadioItemValue="vermelho">
      <span ludsRadioIndicator></span>
      <div ludsRadioItemContent>  
        <p class="luds-body-large-default">Vermelho</p>
        <p class="luds-note-large-default">O vermelho é uma cor vibrante e energética.</p>
      </div>
    </div>

    <div ludsRadioItem [ludsRadioItemValue]="'azul'">
      <span ludsRadioIndicator></span>
      <div ludsRadioItemContent>  
        <p class="luds-body-large-default">Azul</p>
        <p class="luds-note-large-default">O azul transmite calma e tranquilidade.</p>
      </div>
    </div>

    <div ludsRadioItem [ludsRadioItemValue]="'verde'">
      <span ludsRadioIndicator></span>
      <div ludsRadioItemContent>  
        <p class="luds-body-large-default">Verde</p>
        <p class="luds-note-large-default">O verde está associado à natureza e ao equilíbrio.</p>
      </div>
    </div>

    <div ludsRadioItem [ludsRadioItemValue]="'amarelo'">
      <span ludsRadioIndicator></span>
      <div ludsRadioItemContent>  
        <p class="luds-body-large-default">Amarelo</p>
        <p class="luds-note-large-default">O amarelo representa alegria e otimismo.</p>
      </div>
    </div>
  </div>
  `,
  standalone: true,
})
export class RadioTitleAndContentDemoComponent {
  readonly corFavorita = signal<Cor>('vermelho');
}

type Cor = 'vermelho' | 'azul' | 'verde' | 'amarelo';
