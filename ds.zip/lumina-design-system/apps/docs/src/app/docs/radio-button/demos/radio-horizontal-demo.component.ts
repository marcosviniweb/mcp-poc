import { Component, signal } from '@angular/core';
import { LudsRadioGroup, LudsRadioIndicator, LudsRadioItem } from '@luds/ui/blocks/radio';

@Component({
  selector: 'radio-horizontal-demo-component',
  imports: [LudsRadioGroup, LudsRadioItem, LudsRadioIndicator ],
  template: `
    <div [(ludsRadioGroupValue)]="corFavorita"
      ludsRadioGroup
    >
    <div ludsRadioItem ludsRadioItemValue="vermelho">
      <span ludsRadioIndicator></span>
      <div ludsRadioItemContent>  
        <p class="luds-body-large-default">Vermelho</p>
      </div>
    </div>

    <div ludsRadioItem [ludsRadioItemValue]="'azul'">
      <span ludsRadioIndicator></span>
      <div ludsRadioItemContent>  
        <p class="luds-body-large-default">Azul</p>
      </div>      
    </div>

    <div ludsRadioItem [ludsRadioItemValue]="'verde'">
      <span ludsRadioIndicator></span>
      <div ludsRadioItemContent>  
        <p class="luds-body-large-default">Verde</p>
      </div>
    </div>

    <div ludsRadioItem [ludsRadioItemValue]="'amarelo'">
      <span ludsRadioIndicator></span>
      <div ludsRadioItemContent>  
        <p class="luds-body-large-default">Amarelo</p>
      </div>
    </div>
  </div>
  `,
  standalone: true,
})
export class RadioHorizontalDemoComponent {
  readonly corFavorita = signal<Cor>('vermelho');
}

type Cor = 'vermelho' | 'azul' | 'verde' | 'amarelo'
