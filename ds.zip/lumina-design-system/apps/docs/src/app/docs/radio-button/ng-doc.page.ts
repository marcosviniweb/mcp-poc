import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { RadioHorizontalDemoComponent } from "./demos/radio-horizontal-demo.component";
import { RadioReactiveFormDemoComponent } from "./demos/radio-reactive-form-demo.component";
import { RadioTitleAndContentDemoComponent } from "./demos/radio-title-and-content-demo.component";
import { RadioVerticalDemoComponent } from "./demos/radio-vertical-demo.component";

const RadioButton: NgDocPage = {
  title: `Radio Button`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  demos: {
    RadioHorizontalDemoComponent,
    RadioVerticalDemoComponent,
    RadioTitleAndContentDemoComponent,
    RadioReactiveFormDemoComponent,
  },
};

export default RadioButton;
