import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { LudsButton } from '@luds/ui/blocks/button';
import { LudsFormField, LudsLabel } from '@luds/ui/blocks/form-field';
import { LudsRadioGroup, LudsRadioGroupValueAccessor, LudsRadioIndicator, LudsRadioItem } from '@luds/ui/blocks/radio';

@Component({
  selector: 'radio-reactive-form-demo-component',
  imports: [LudsRadioGroup, LudsRadioGroupValueAccessor, CommonModule, LudsRadioItem, LudsRadioIndicator, LudsButton, LudsLabel, LudsFormField, ReactiveFormsModule],
  template: `
    <form [formGroup]="form" ludsFormField (ngSubmit)="submit()">
      <label ludsLabel class="luds-body-large-default">Escolha sua cor preferida:</label>
      <div ludsRadioGroup ludsRadioGroupOrientation="vertical" formControlName="favoriteColor">
        <div ludsRadioItem ludsRadioItemValue="vermelho">
          <span ludsRadioIndicator></span>
          <div ludsRadioItemContent>  
            <p class="luds-body-large-default">Vermelho</p>
          </div>
        </div>

        <div ludsRadioItem [ludsRadioItemValue]="'verde'">
          <span ludsRadioIndicator></span>
          <div ludsRadioItemContent>  
            <p class="luds-body-large-default">Verde</p>
          </div>
        </div>

        <div ludsRadioItem [ludsRadioItemValue]="'amarelo'">
          <span ludsRadioIndicator></span>
          <div ludsRadioItemContent>  
            <p class="luds-body-large-default">Amarelo</p>
          </div>
        </div>

        <div ludsRadioItem [ludsRadioItemValue]="'azul'">
          <span ludsRadioIndicator></span>
          <div ludsRadioItemContent>  
            <p class="luds-body-large-default">Azul</p>
          </div>
        </div>
      </div>
      <button ludsButton>Submit</button>
    </form>
  `,
  styles: '[ludsRadioGroup], [ludsButton] { margin-top: 1rem }',
  standalone: true,
})
export class RadioReactiveFormDemoComponent implements OnInit {
  form!: FormGroup;

  ngOnInit(): void {
    this.form = new FormGroup({
      favoriteColor: new FormControl('amarelo', Validators.required)
    });
  }

  submit(): void {
    this.form.markAllAsTouched();
    alert('Opção selecionada: ' + this.form.value.favoriteColor);
  }
}
