{{ NgDocApi.details("libs/ui/blocks/radio/src/radio-group/radio-group.ts#LudsRadioGroup") }}

{{ JSDoc.description("libs/ui/blocks/radio/src/radio-group/radio-group.ts#LudsRadioGroup") }}

## Preview

{{ NgDocActions.demo("RadioHorizontalDemoComponent") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsRadioGroup, LudsRadioItem, LudsRadioIndicator } from '@luds/ui/blocks/radio';

@Component({
  standalone: true,
  imports: [LudsRadioGroup, LudsRadioItem, LudsRadioIndicator],
  templateUrl: './my-component.html',
})
export class MyComponent {
    readonly selectedValue = signal<string>('option1');
}
```

```html name="my-component.html" group="my-group1"
<div ludsRadioGroup [(ludsRadioGroupValue)]="selectedValue">
  <div ludsRadioItem [ludsRadioItemValue]="'option1'">
    <div ludsRadioIndicator>
        <span></span>
    </div>
    <p class="luds-body-large-default">Opção 1</p>
  </div>
  <div ludsRadioItem [ludsRadioItemValue]="'option2'">
    <div ludsRadioIndicator>
        <span></span>
    </div>
    <p class="luds-body-large-default">Opção 2</p>
  </div>
</div>
```

## Exemplos

### Horizontal

{{ NgDocActions.demo("RadioHorizontalDemoComponent") }}

### Vertical

{{ NgDocActions.demo("RadioVerticalDemoComponent") }}

### Título e Conteúdo

{{ NgDocActions.demo("RadioTitleAndContentDemoComponent") }}

### Utilizando Reactive Form

{{ NgDocActions.demo("RadioReactiveFormDemoComponent") }}

