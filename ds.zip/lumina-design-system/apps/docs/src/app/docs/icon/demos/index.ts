export { IconDemo } from "./icon-demo.component";
