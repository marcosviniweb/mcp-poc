import { ChangeDetectionStrategy, Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import {
  phosphorCheckCircle,
  phosphorInfo,
  phosphorWarning,
  phosphorXCircle,
  phosphorBell,
  phosphorArrowsClockwise,
  phosphorCaretRight,
  phosphorHeart,
} from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "icon-demo",
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [NgIcon],
  providers: [
    provideIcons({
      phosphorCheckCircle,
      phosphorInfo,
      phosphorWarning,
      phosphorXCircle,
      phosphorBell,
      phosphorArrowsClockwise,
      phosphorCaretRight,
      phosphorHeart,
    }),
  ],
  template: `
    <div class="icon-showcase">
      <div class="icon-grid">
        @for (icon of icons; track icon.name) {
          <div class="icon-item">
            <ng-icon [name]="icon.name" [size]="icon.size" [color]="icon.color" />
          </div>
        }
      </div>
    </div>
  `,
  styles: [
    `
      .icon-showcase {
        padding: 1rem;
        max-width: 1200px;
        margin: 0 auto;
      }

      .icon-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
        gap: 1rem;
        align-items: center;
      }

      .icon-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.5rem;
        padding: 1rem;
        background: white;
        border-radius: 6px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      }

      .icon-row {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        gap: 0.75rem;
      }

      @media (max-width: 768px) {
        .icon-grid {
          grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        }

        .icon-row {
          grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
        }
      }
    `,
  ],
})
export class IconDemo {
  readonly icons = [
    { name: "phosphorCaretRight", size: "16px", color: "var(--luds-color-gray-90)" },
    { name: "phosphorArrowsClockwise", size: "24px", color: "var(--luds-color-green-50)" },
    { name: "phosphorBell", size: "32px", color: "var(--luds-color-yellow-50)" },
    { name: "phosphorXCircle", size: "40px", color: "var(--luds-color-red-50)" },
    { name: "phosphorWarning", size: "48px", color: "var(--luds-color-gray-50)" },
    { name: "phosphorInfo", size: "56px", color: "var(--luds-color-blue-50)" },
    { name: "phosphorCheckCircle", size: "64px", color: "var(--luds-color-purple-50)" },
    { name: "phosphorHeart", size: "72px", color: "var(--luds-color-magenta-50)"}
  ];
}
