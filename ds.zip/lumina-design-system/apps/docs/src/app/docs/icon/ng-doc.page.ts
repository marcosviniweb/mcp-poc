import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { IconDemo } from "./demos/icon-demo.component";

const IconPage: NgDocPage = {
  title: `Icon`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  demos: { IconDemo },
};

export default IconPage;
