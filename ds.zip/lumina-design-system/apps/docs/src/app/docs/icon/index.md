O Lumina Design System utiliza a biblioteca **ng-icons** para fornecer uma solução robusta e flexível para o uso de ícones em aplicações Angular.

## Preview

{{ NgDocActions.demo("IconDemo") }}

## Por que ng-icons?

A biblioteca ng-icons oferece diversos benefícios importantes:

- **Tree Shaking**: Apenas os ícones que você realmente utiliza são incluídos no bundle final, otimizando o tamanho da aplicação
- **Múltiplas Famílias de Ícones**: Acesso a mais de 50.000 ícones de bibliotecas populares como Font Awesome, Material Design, Heroicons, Phosphor Icons e muitas outras
- **Sem Scripts Externos**: Não é necessário declarar importações de scripts de fontes externas, simplificando a configuração
- **Tipagem TypeScript**: Todos os ícones são tipados, proporcionando melhor experiência de desenvolvimento
- **Performance**: Renderização otimizada através de componentes Angular nativos

## Pacotes Utilizados

No nosso design system, utilizamos principalmente:

- **@ng-icons/core**: Pacote principal que fornece o componente `NgIcon` e utilitários
- **@ng-icons/phosphor-icons**: Biblioteca de ícones Phosphor, utilizada em nossos componentes internos e exemplos

## Importação e Configuração

### Importação Básica

```typescript name="app.component.ts" group="basic-usage"
import { NgIcon, provideIcons } from '@ng-icons/core';
import { phosphorHeart, phosphorStar } from '@ng-icons/phosphor-icons/regular';

@Component({
  selector: 'app-root',
  template: `
    <ng-icon name="phosphorHeart"></ng-icon>
    <ng-icon name="phosphorStar"></ng-icon>
  `,
  imports: [NgIcon],
  providers: [provideIcons({ phosphorHeart, phosphorStar })],
})
export class AppComponent {}
```

## Flexibilidade para Desenvolvedores

Embora utilizemos Phosphor Icons em nossos componentes, **você tem total liberdade** para escolher qualquer família de ícones disponível na biblioteca ng-icons para seus próprios componentes e aplicações.

### Exemplos com Outras Famílias

```typescript name="multiple-families.ts" group="multiple-families"
import { NgIcon, provideIcons } from '@ng-icons/core';
import { featherHome, featherSettings } from '@ng-icons/feather-icons';
import { heroUsers, heroChartBar } from '@ng-icons/heroicons/outline';
import { matFavorite, matShare } from '@ng-icons/material-icons/baseline';

@Component({
  template: `
    <!-- Feather Icons -->
    <ng-icon name="featherHome" />
    <ng-icon name="featherSettings" />
    
    <!-- Heroicons -->
    <ng-icon name="heroUsers" />
    <ng-icon name="heroChartBar" />
    
    <!-- Material Icons -->
    <ng-icon name="matFavorite" />
    <ng-icon name="matShare" />
  `,
  imports: [NgIcon],
  providers: [provideIcons({ 
    featherHome, 
    featherSettings,
    heroUsers, 
    heroChartBar,
    matFavorite, 
    matShare 
  })],
})
export class MultipleIconsComponent {}
```

## Customização de Tamanho e Estilo

O componente `ng-icon` aceita propriedades CSS padrão:

```typescript name="custom-styling.ts" group="styling"
@Component({
  template: `
    <!-- Tamanho customizado -->
    <ng-icon name="phosphorHeart" size="24px" />
    
    <!-- Cor customizada -->
    <ng-icon name="phosphorStar" color="red" />
    
    <!-- Classes CSS -->
    <ng-icon name="phosphorUser" class="my-icon-class" />
  `,
  styles: [`
    .my-icon-class {
      font-size: 2rem;
      color: var(--primary-color);
    }
  `]
})
export class StyledIconsComponent {}
```

## Documentação Oficial

Para informações mais detalhadas, consulte a [documentação oficial do ng-icons](https://ng-icons.github.io/ng-icons/), onde você encontrará:

- Lista completa de todas as famílias de ícones disponíveis
- Exemplos avançados de uso
- Configurações específicas para diferentes cenários
- Guias de migração e otimização

## Instalação de Novos Pacotes

Se você quiser utilizar uma família de ícones diferente, instale o pacote correspondente:

```bash
npm install @ng-icons/feather-icons
# ou
npm install @ng-icons/heroicons
# ou
npm install @ng-icons/material-icons
```

Em seguida, importe e configure os ícones conforme mostrado nos exemplos acima.
