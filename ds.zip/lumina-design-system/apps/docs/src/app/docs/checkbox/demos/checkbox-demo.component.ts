import { Component, signal } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsCheckbox } from "@luds/ui/blocks/checkbox";
import { phosphorCheck } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "checkbox-demo",
  imports: [LudsCheckbox, NgIcon],
  providers: [provideIcons({ phosphorCheck })],
  template: `
    <div ludsCheckboxOption>
      <button
        ludsCheckbox
        id="notification-by-email"
        [ludsCheckboxChecked]="checked()"
        (ludsCheckboxCheckedChange)="checked.set($event)"
      >
        @if (checked()) {
          <ng-icon name="phosphorCheck"></ng-icon>
        }
      </button>
      <label ludsCheckboxLabel for="notification-by-email" class="luds-body-large-default">
        Receber Notificações por E-mail
        <span ludsCheckboxDescription class="luds-note-large-default"
          >Marque esta opção se desejar ser avisado sempre que houver atualizações importantes na sua conta.</span
        >
      </label>
    </div>
  `,
  standalone: true,
})
export class CheckboxDemoComponent {
  readonly checked = signal(false);
}
