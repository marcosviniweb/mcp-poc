import { Component, signal, computed } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsCheckbox } from "@luds/ui/blocks/checkbox";
import { BooleanInput } from "@angular/cdk/coercion";
import { phosphorCheck, phosphorMinus } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "subgroup-checkbox-demo",
  imports: [LudsCheckbox, NgIcon],
  providers: [provideIcons({ phosphorCheck, phosphorMinus })],
  standalone: true,
  template: `
    <div ludsCheckboxOption>
      <button
        ludsCheckbox
        [ludsCheckboxChecked]="allSelected()"
        (ludsCheckboxCheckedChange)="onChange('all', $event)"
        [ludsCheckboxIndeterminate]="someSelected()"
        id="all"
      >
        @if (allSelected()) {
          <ng-icon name="phosphorCheck"></ng-icon>
        } @else if (someSelected()) {
          <ng-icon name="phosphorMinus"></ng-icon>
        }
      </button>
      <label ludsCheckboxLabel for="all" class="luds-body-large-default">Todas as notificações</label>
    </div>

    <div ludsCheckboxSubgroup>
      @for (option of notificationOptions(); track option.id) {
        <div ludsCheckboxOption>
          <button
            ludsCheckbox
            [ludsCheckboxChecked]="option.checked"
            (ludsCheckboxCheckedChange)="onChange(option.id, $event)"
            [id]="option.id"
          >
            @if (option.checked) {
              <ng-icon name="phosphorCheck"></ng-icon>
            }
          </button>
          <label ludsCheckboxLabel [for]="option.id" class="luds-body-large-default">{{ option.label }}</label>
        </div>
      }
    </div>
  `,
})
export class SubgroupCheckboxDemoComponent {
  readonly notificationOptions = signal<Option[]>([
    { id: "sms", label: "SMS", checked: false },
    { id: "email", label: "E-mail", checked: true },
    { id: "push", label: "Notificações por push", checked: false },
  ]);

  readonly allSelected = computed(() => this.notificationOptions().every((opt) => opt.checked));

  readonly someSelected = computed(() => {
    const opts = this.notificationOptions();
    return opts.some((o) => o.checked) && !opts.every((o) => o.checked);
  });

  onChange(id: string, checked: BooleanInput) {
    if (id === "all") {
      this.notificationOptions.update((options) => options.map((opt) => ({ ...opt, checked })));
    } else {
      this.notificationOptions.update((options) => options.map((opt) => (opt.id === id ? { ...opt, checked } : opt)));
    }
  }
}

interface Option {
  id: string;
  label: string;
  checked: BooleanInput;
}
