import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsFormField } from "@luds/ui/blocks/form-field";
import { LudsCheckbox, LudsCheckboxValueAccessor } from "@luds/ui/blocks/checkbox";
import { FormControl, ReactiveFormsModule, Validators } from "@angular/forms";
import { phosphorCheck } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "error-checkbox-demo",
  imports: [LudsCheckbox, LudsCheckboxValueAccessor, LudsFormField, ReactiveFormsModule, NgIcon],
  providers: [provideIcons({ phosphorCheck })],
  standalone: true,
  template: `
    <form ludsFormField>
      <div ludsCheckboxOption>
        <button
          ludsCheckbox
          [ludsCheckboxChecked]="optionControl.value"
          [formControl]="optionControl"
          id="review-information"
        >
          @if (optionControl.value) {
            <ng-icon name="phosphorCheck"></ng-icon>
          }
        </button>
        <label ludsCheckboxLabel for="review-information" class="luds-body-large-default">
          Confirmar Revisão das Informações
          <span ludsCheckboxDescription class="luds-note-large-default">
            É necessário confirmar que você revisou os dados informados antes de prosseguir.
          </span>
        </label>
      </div>
    </form>
  `,
})
export class ErrorCheckboxDemoComponent {
  optionControl = new FormControl(false, Validators.requiredTrue);
}
