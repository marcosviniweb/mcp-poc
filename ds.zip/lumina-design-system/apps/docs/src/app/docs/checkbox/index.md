{{ NgDocApi.details("libs/ui/blocks/checkbox/src/checkbox/checkbox.ts#LudsCheckbox") }}

{{ JSDoc.description("libs/ui/blocks/checkbox/src/checkbox/checkbox.ts#LudsCheckbox") }}

## Playground

{{ NgDocActions.playground("CheckboxPlayground") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsCheckbox } from '@luds/ui/blocks/checkbox';

@Component({
  standalone: true,
  imports: [LudsCheckbox],
  templateUrl: './my-component.html',
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<button
  ludsCheckbox
  [ludsCheckboxChecked]="isChecked()"
  (ludsCheckboxCheckedChange)="isChecked.setValue($event)"
>
  Aceito os termos
</button>
```

## Exemplos

### Uso simples

#### Com label e descrição

{{ NgDocActions.demo("CheckboxDemoComponent") }}

### Exemplos de uso com ReactiveForms

Para que o `ludsCheckbox` funcione corretamente com formulários reativos, é necessário importar também a diretiva `ludsCheckboxValueAccessor`.

#### Checkbox integrado ao formulário

{{ NgDocActions.demo("CheckboxReactiveFormsDemoComponent") }}

#### Checkbox com estado de erro

{{ NgDocActions.demo("ErrorCheckboxDemoComponent") }}

### Checkboxes aninhados com estado indeterminado dinâmico

{{ NgDocActions.demo("SubgroupCheckboxDemoComponent") }}
