import { signal } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsCheckbox } from "@luds/ui/blocks/checkbox";
import { LudsFormField, LudsLabel } from "@luds/ui/blocks/form-field";
import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { CheckboxDemoComponent } from "./demos/checkbox-demo.component";
import { CheckboxReactiveFormsDemoComponent } from "./demos/checkbox-reactive-forms-demo.component";
import { ErrorCheckboxDemoComponent } from "./demos/error-checkbox.demo.component";
import { SubgroupCheckboxDemoComponent } from "./demos/subgroup-checkbox.demo.component";
import { phosphorCheck, phosphorMinus } from "@ng-icons/phosphor-icons/regular";

const Checkbox: NgDocPage = {
  title: `Checkbox`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  demos: {
    CheckboxDemoComponent,
    ErrorCheckboxDemoComponent,
    SubgroupCheckboxDemoComponent,
    CheckboxReactiveFormsDemoComponent,
  },
  imports: [LudsFormField, LudsLabel, NgIcon],
  providers: [provideIcons({ phosphorCheck, phosphorMinus })],
  playgrounds: {
    CheckboxPlayground: {
      target: LudsCheckbox,
      selectors: "[ludsCheckbox]",
      template: `
        <div ludsCheckboxOption>
          <button
            ludsCheckbox
            id="profile-visibility"
            (ludsCheckboxCheckedChange)="properties['checked'] = $event"
          >
            @if (properties['checked']) {
            <ng-icon  name="phosphorCheck"></ng-icon>
            } @else if (properties['indeterminate']) {
            <ng-icon  name="phosphorMinus"></ng-icon>
            }
          </button>
          <label ludsCheckboxLabel for="profile-visibility" class="luds-body-large-default">
            Exibir meu perfil publicamente
            <span ludsCheckboxDescription class="luds-note-large-default"
              >Se ativado, seu nome e foto de perfil poderão ser visualizados por outros usuários da plataforma.</span
            >
          </label>
        </div>
      `,
      hiddenInputs: ["required", "disabled"],
      data: {
        checked: signal(false),
      },
    },
  },
};

export default Checkbox;
