import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { FormControl, ReactiveFormsModule } from "@angular/forms";
import { LudsFormField } from "@luds/ui/blocks/form-field";
import { LudsCheckbox, LudsCheckboxValueAccessor } from "@luds/ui/blocks/checkbox";
import { CommonModule } from "@angular/common";
import { phosphorCheck } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "checkbox-reactive-forms-demo",
  imports: [CommonModule, LudsCheckbox, LudsCheckboxValueAccessor, LudsFormField, ReactiveFormsModule, NgIcon],
  providers: [provideIcons({ phosphorCheck })],
  template: `
    <div ludsFormField>
      <div ludsCheckboxOption>
        <button ludsCheckbox id="two-factor" [ludsCheckboxChecked]="optionControl.value" [formControl]="optionControl">
          @if (optionControl.value) {
            <ng-icon name="phosphorCheck"></ng-icon>
          }
        </button>
        <label ludsCheckboxLabel for="two-factor" class="luds-body-large-default">
          Ativar Autenticação em Dois Fatores
          <span ludsCheckboxDescription class="luds-note-large-default"
            >Reforça a segurança da sua conta solicitando um código adicional ao fazer login em novos
            dispositivos.</span
          >
        </label>
      </div>
    </div>
  `,
  standalone: true,
})
export class CheckboxReactiveFormsDemoComponent {
  readonly optionControl = new FormControl(false);
}
