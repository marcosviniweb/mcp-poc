import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsChip } from "@luds/ui/blocks/chip";
import { NgDocPage } from "@ng-doc/core";
import { ChipDemoCloseableComponent } from "./demos/chip-closeable-demo.component";
import { ChipDemoBadgeComponent } from "./demos/chip-demo-badge.component";
import { ChipDemoSizeComponent } from "./demos/chip-demo-size-default.component";
import { ChipDemoVariantComponent } from "./demos/chip-demo-variant-primary.component";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { phosphorX } from "@ng-icons/phosphor-icons/regular";

const Chip: NgDocPage = {
  title: `Chip`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  imports: [LudsChip, NgIcon],
  providers: [provideIcons({ phosphorX })],

  demos: {
    ChipDemoSizeComponent,
    ChipDemoVariantComponent,
    ChipDemoCloseableComponent,
    ChipDemoBadgeComponent,
  },
  playgrounds: {
    ChipStandardPlayground: {
      target: LudsChip,
      selectors: "[ludsChip]",
      hiddenInputs: ["disabled"],
      template: `
        <span ludsChip #chip="ludsChip">
          <p [class]="properties['size'] === 'default' ? 'luds-label-large-bold' : 'luds-label-medium-bold'">Content</p>
          @if (chip.closeable()) {
            <ng-icon ludsChipCloseIcon  name="phosphorX"></ng-icon>
          }
        </span>`,
    },
  },
};

export default Chip;
