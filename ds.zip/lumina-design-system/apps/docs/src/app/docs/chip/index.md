{{ NgDocApi.details("libs/ui/blocks/chip/src/chip.ts#LudsChip") }}

{{ JSDoc.description("libs/ui/blocks/chip/src/chip.ts#LudsChip") }}

## Playground

{{ NgDocActions.playground("ChipStandardPlayground") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsChip } from '@luds/ui/blocks/chip';

@Component({
  standalone: true,
  imports: [LudsChip],
  templateUrl: './my-component.html',
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<span ludsChip>Chip</span>
```

## Exemplos

### Variantes

{{ NgDocActions.demo("ChipDemoVariantComponent") }}

Veja a documentação da API: `LudsChipVariant`

### Tamanhos

{{ NgDocActions.demo("ChipDemoSizeComponent") }}

Veja a documentação da API: `LudsChipSize`

### Closeable

O evento `closed` é emitido quando o chip é fechado pelo usuário.

{{ NgDocActions.demo("ChipDemoCloseableComponent") }}

### Badge

{{ NgDocActions.demo("ChipDemoBadgeComponent") }}
