import { Component } from "@angular/core";
import { LudsChip } from "@luds/ui/blocks/chip";

@Component({
  selector: "chip-demo-size-default",
  imports: [LudsChip],
  standalone: true,
  styles: `
    .demo-chip-container {
      display: flex;
      gap: 8px;
    }
  `,
  template: `
    <div class="demo-chip-container">
      <span ludsChip size="small" aria-label="Chip">
        <p class="luds-label-medium-default">Small</p>
      </span>
      <span ludsChip size="default" aria-label="Chip">
        <p class="luds-label-large-default">Default</p>
      </span>
    </div>
  `,
})
export class ChipDemoSizeComponent {}
