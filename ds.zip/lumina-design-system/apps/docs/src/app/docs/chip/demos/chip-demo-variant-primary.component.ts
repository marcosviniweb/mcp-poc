import { Component } from '@angular/core';
import { LudsChip } from '@luds/ui/blocks/chip';

@Component({
  selector: "chip-demo-variant-primary",
  imports: [LudsChip],
  standalone: true,
  styles: `
    .demo-chip-container {
      display: flex;
      gap: 8px;
    }
  `,
  template: `
    <div class="demo-chip-container">
      <span ludsChip variant="positive" aria-label="Chip positive">
        <p class="luds-label-large-default">Positive</p>
      </span>

      <span ludsChip variant="negative" aria-label="Chip negative">
        <p class="luds-label-large-default">Negative</p>
      </span>
    </div>
  `,
})
export class ChipDemoVariantComponent {}
