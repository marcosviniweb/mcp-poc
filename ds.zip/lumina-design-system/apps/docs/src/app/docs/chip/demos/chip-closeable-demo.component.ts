import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsChip } from "@luds/ui/blocks/chip";
import { phosphorX } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "chip-closeable-demo",
  imports: [LudsChip, NgIcon],
  providers: [provideIcons({ phosphorX })],
  standalone: true,
  template: `
    <span ludsChip #chip="ludsChip" (closed)="teste()" [closeable]="true" aria-label="Chip fechável">
      <p class="luds-label-large-default">Closeable</p>
      @if (chip.closeable()) {
        <ng-icon ludsChipCloseIcon name="phosphorX" tabindex="0" aria-label="Fechar"></ng-icon>
      }
    </span>
  `,
})
export class ChipDemoCloseableComponent {
  teste() {
    alert("teste");
  }
}
