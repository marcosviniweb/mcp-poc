export { ChipDemoCloseableComponent } from "./chip-closeable-demo.component";
export { ChipDemoBadgeComponent } from "./chip-demo-badge.component";
export { ChipDemoSizeComponent } from "./chip-demo-size-default.component";
export { ChipDemoVariantComponent } from "./chip-demo-variant-primary.component";
