import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsBadge } from "@luds/ui/blocks/badge";
import { LudsChip } from "@luds/ui/blocks/chip";
import { phosphorX } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "chip-demo-badge",
  imports: [LudsChip, LudsBadge, NgIcon],
  providers: [provideIcons({ phosphorX })],
  standalone: true,
  styles: `
    .demo-chip-row {
      display: flex;
      gap: 8px;
    }

    .demo-chip-row-with-margin {
      display: flex;
      margin-bottom: 8px;
      gap: 8px;
    }
  `,
  template: `
    <div class="demo-chip-row-with-margin">
      <span ludsChip aria-label="Chip com badge">
        <div ludsBadgeContainer>
          <div ludsBadge aria-label="notificação" variant="magenta-dark">
            <p class="luds-label-medium-default">999</p>
          </div>
        </div>
        <p class="luds-label-large-default">Badge</p>
      </span>
      <span ludsChip variant="negative" aria-label="Chip com badge">
        <div ludsBadgeContainer>
          <div ludsBadge aria-label="notificação">
            <p class="luds-label-medium-default">999</p>
          </div>
        </div>
        <p class="luds-label-large-default">Badge</p>
      </span>
    </div>
    <div class="demo-chip-row">
      <span ludsChip #chip="ludsChip" (closed)="closeChip()" [closeable]="true" aria-label="Chip fechável com badge">
        <div ludsBadgeContainer>
          <div ludsBadge aria-label="notificação" variant="magenta-dark">
            <p class="luds-label-medium-default">999</p>
          </div>
        </div>
        <p class="luds-label-large-default">Badge Closeable</p>
        @if (chip.closeable()) {
          <ng-icon ludsChipCloseIcon name="phosphorX" tabindex="0" aria-label="Fechar"></ng-icon>
        }
      </span>
      <span
        ludsChip
        #chip="ludsChip"
        (closed)="closeChip()"
        [closeable]="true"
        variant="negative"
        aria-label="Chip fechável com badge"
      >
        <div ludsBadgeContainer>
          <div ludsBadge aria-label="notificação">
            <p class="luds-label-medium-default">999</p>
          </div>
        </div>
        <p class="luds-label-large-default">Badge Closeable</p>
        @if (chip.closeable()) {
          <ng-icon ludsChipCloseIcon name="phosphorX" tabindex="0" aria-label="Fechar"></ng-icon>
        }
      </span>
    </div>
  `,
})
export class ChipDemoBadgeComponent {
  closeChip() {
    alert("Chip fechado");
  }
}
