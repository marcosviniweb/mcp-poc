import { LudsButton } from "@luds/ui/blocks/button";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { ButtonDemoSizeDefaultComponent } from "./demos/button-demo-size-default.component";
import { ButtonDemoVariantPrimaryComponent } from "./demos/button-demo-variant-primary.component";
import { ButtonDemoWithIconsComponent } from "./demos/button-demo-with-icons.component";
import { IconButtonDemoComponent } from "./demos/icon-button-demo.component";
import { phosphorArrowsClockwise } from "@ng-icons/phosphor-icons/regular";

const Button: NgDocPage = {
  title: `Button`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  imports: [LudsButton, NgIcon],
  providers: [provideIcons({ phosphorArrowsClockwise })],
  demos: {
    ButtonDemoSizeDefaultComponent,
    ButtonDemoVariantPrimaryComponent,
    ButtonDemoWithIconsComponent,
    IconButtonDemoComponent,
  },
  playgrounds: {
    ButtonStandardPlayground: {
      target: LudsButton,
      selectors: "button[ludsButton]",
      hiddenInputs: ["disabled"],
      template: `
      <button ludsButton buttonType="button">
        {{ content.iconLeft }}
        Button Examples
        {{ content.iconRight }}
      </button>`,
      content: {
        iconRight: {
          label: "icone à direita",
          template: '<ng-icon  name="phosphorArrowsClockwise"></ng-icon>',
        },
        iconLeft: {
          label: "icone à esquerda",
          template: '<ng-icon  name="phosphorArrowsClockwise"></ng-icon>',
        },
      },
    },
    ButtonIconPlayground: {
      target: LudsButton,
      selectors: "button[ludsButton]",
      hiddenInputs: ["disabled"],
      template: `
      <button ludsButton buttonType="icon-button" aria-label="Atualizar">
        <ng-icon  name="phosphorArrowsClockwise"></ng-icon>
      </button>`,
    },
  },
};

export default Button;
