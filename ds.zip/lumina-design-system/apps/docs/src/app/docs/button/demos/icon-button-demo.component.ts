import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { phosphorArrowsClockwise } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "icon-button-demo",
  imports: [LudsButton, NgIcon],
  providers: [provideIcons({ phosphorArrowsClockwise })],
  host: {
    "[attr.data-testid]": '"luds-button-component-demo"',
  },
  template: `
    <div style="display: grid; gap: 10px;">
      <button ludsButton data-testid="luds-button-label">Label</button>
      <button ludsButton buttonType="icon-button" data-testid="luds-button-icon-types" aria-label="Atualizar">
        <ng-icon name="phosphorArrowsClockwise"></ng-icon>
      </button>
    </div>
  `,
  standalone: true,
})
export class IconButtonDemoComponent {}
