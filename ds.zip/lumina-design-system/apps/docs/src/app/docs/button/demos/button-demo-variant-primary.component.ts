import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { phosphorArrowsClockwise } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "button-demo-variant-primary",
  imports: [LudsButton, NgIcon],
  providers: [provideIcons({ phosphorArrowsClockwise })],
  standalone: true,
  host: {
    "[attr.data-testid]": '"luds-button-variant-demo"',
  },
  template: `
    <div>
      <div style="display: flex; gap: 10px">
        <button ludsButton data-testid="luds-button-primary">Primary</button>
        <button ludsButton variant="secondary" data-testid="luds-button-secondary">Secondary</button>
        <button ludsButton variant="tertiary" data-testid="luds-button-tertiary">Tertiary</button>
      </div>

      <div style="display: flex; gap: 10px; margin-top: 10px">
        <button ludsButton buttonType="icon-button" data-testid="luds-button-icon-primary" aria-label="Atualizar">
          <ng-icon name="phosphorArrowsClockwise"></ng-icon>
        </button>

        <button
          ludsButton
          variant="secondary"
          buttonType="icon-button"
          data-testid="luds-button-icon-secondary"
          aria-label="Atualizar"
        >
          <ng-icon name="phosphorArrowsClockwise"></ng-icon>
        </button>
        <button
          ludsButton
          variant="tertiary"
          buttonType="icon-button"
          data-testid="luds-button-icon-tertiary"
          aria-label="Atualizar"
        >
          <ng-icon name="phosphorArrowsClockwise"></ng-icon>
        </button>
      </div>
    </div>
  `,
})
export class ButtonDemoVariantPrimaryComponent {}
