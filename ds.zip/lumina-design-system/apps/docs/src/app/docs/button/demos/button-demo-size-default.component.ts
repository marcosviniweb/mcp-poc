import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { phosphorArrowsClockwise } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "button-demo-size-default",
  imports: [LudsButton, NgIcon],
  providers: [provideIcons({ phosphorArrowsClockwise })],
  standalone: true,
  host: {
    "[attr.data-testid]": '"luds-button-size-demo"',
  },
  template: `
    <div style="display: flex; gap: 10px;">
      <button ludsButton data-testid="luds-button-default">Default</button>
      <button ludsButton data-testid="luds-button-small" size="small">Small</button>
    </div>
    <div style="display: flex; gap: 10px; margin-top: 10px;">
      <button ludsButton buttonType="icon-button" data-testid="luds-button-icon" aria-label="Atualizar">
        <ng-icon name="phosphorArrowsClockwise"></ng-icon>
      </button>
      <button
        ludsButton
        data-testid="luds-button-icon-small"
        buttonType="icon-button"
        size="small"
        aria-label="Atualizar"
      >
        <ng-icon name="phosphorArrowsClockwise"></ng-icon>
      </button>
    </div>
  `,
})
export class ButtonDemoSizeDefaultComponent {}
