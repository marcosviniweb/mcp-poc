{{ NgDocApi.details("libs/ui/blocks/button/src/button.ts#LudsButton") }}

{{ JSDoc.description("libs/ui/blocks/button/src/button.ts#LudsButton") }}

## Playground

{{ NgDocActions.playground("ButtonStandardPlayground") }}
{{ NgDocActions.playground("ButtonIconPlayground") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsButton } from '@luds/ui/blocks/button';

@Component({
  standalone: true,
  imports: [LudsButton],
  templateUrl: './my-component.html',
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<button ludsButton>Button</button>
```

## Exemplos

### Tipos

{{ NgDocActions.demo("IconButtonDemoComponent") }}

Veja a documentação da API: `ludsButtonType`

### Variantes

{{ NgDocActions.demo("ButtonDemoVariantPrimaryComponent") }}

Veja a documentação da API: `ludsButtonVariant`

### Tamanhos

{{ NgDocActions.demo("ButtonDemoSizeDefaultComponent") }}

Veja a documentação da API: `ludsButtonSize`

### Ícones

{{ NgDocActions.demo("ButtonDemoWithIconsComponent") }}
