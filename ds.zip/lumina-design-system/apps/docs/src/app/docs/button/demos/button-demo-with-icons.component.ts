import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { phosphorArrowsClockwise } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "button-demo-with-icons",
  standalone: true,
  host: {
    "[attr.data-testid]": '"luds-button-icons-demo"',
  },
  imports: [LudsButton, NgIcon],
  providers: [provideIcons({ phosphorArrowsClockwise })],
  template: `
    <div style="display: flex; gap: 10px;">
      <button ludsButton data-testid="luds-button-left">
        <ng-icon name="phosphorArrowsClockwise"></ng-icon>
        Ícone à esquerda
      </button>

      <button ludsButton data-testid="luds-button-right">
        Ícone à direita
        <ng-icon name="phosphorArrowsClockwise"></ng-icon>
      </button>
    </div>
  `,
})
export class ButtonDemoWithIconsComponent {}
