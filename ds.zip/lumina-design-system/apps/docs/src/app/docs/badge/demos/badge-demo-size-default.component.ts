import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsBadge } from "@luds/ui/blocks/badge";
import { phosphorBell } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "badge-demo-size-default",
  imports: [LudsBadge, NgIcon],
  providers: [provideIcons({ phosphorBell })],
  standalone: true,
  template: `
    <div style="display: flex; gap: 20px; flex-direction: column;">
      <div ludsBadgeContainer>
        <div ludsBadge data-testid="luds-badge-magenta-default" aria-label="999 notificações">
          <p class="luds-label-medium-default">999</p>
        </div>
      </div>
      <div ludsBadgeContainer>
        <div
          ludsBadge
          data-testid="luds-badge-success-small"
          variant="success"
          size="small"
          aria-label="Status positivo"
        ></div>
      </div>
      <div ludsBadgeContainer>
        <ng-icon name="phosphorBell"></ng-icon>
        <div
          ludsBadge
          data-testid="luds-badge-error-small"
          variant="error"
          size="dot"
          aria-label="Notificação crítica não lida"
        ></div>
      </div>
    </div>
  `,
})
export class BadgeDemoSizeComponent {}
