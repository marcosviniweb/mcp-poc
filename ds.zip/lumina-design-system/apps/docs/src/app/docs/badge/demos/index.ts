export { BadgeDemoSizeComponent } from './badge-demo-size-default.component';
export { BadgeDemoVariantComponent } from './badge-demo-variant.component';
