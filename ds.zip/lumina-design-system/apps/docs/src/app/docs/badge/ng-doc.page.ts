import { LudsBadge } from "@luds/ui/blocks/badge";
import { NgDocPage } from "@ng-doc/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { BadgeDemoSizeComponent } from "./demos/badge-demo-size-default.component";
import { BadgeDemoVariantComponent } from "./demos/badge-demo-variant.component";
import { phosphorBell } from "@ng-icons/phosphor-icons/regular";

export type LudsBadgeSize = "default" | "small" | "dot";

const Badge: NgDocPage = {
  title: `Badge`,
  mdFile: "./index.md",
  category: ComponentsCategory,

  demos: { BadgeDemoSizeComponent, BadgeDemoVariantComponent },
  imports: [LudsBadge, NgIcon],
  providers: [provideIcons({ phosphorBell })],
  playgrounds: {
    BadgePlayground: {
      target: LudsBadge,
      template: `
      <div ludsBadgeContainer>
        <div ludsBadge aria-label="notificação">
         <p class="luds-label-medium-default">999</p>
        </div>
      </div>
      `,
    },
    BadgeDotPlayground: {
      target: LudsBadge,
      template: `
      <div ludsBadgeContainer>
        <ng-icon  name="phosphorBell"></ng-icon>
        <div ludsBadge size="dot" aria-label="notificação"></div>
      </div>
 `,
    },
  },
};

export default Badge;
