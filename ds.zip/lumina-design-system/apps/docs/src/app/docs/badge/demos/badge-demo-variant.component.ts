import { Component } from "@angular/core";
import { LudsBadge } from "@luds/ui/blocks/badge";

@Component({
  selector: "badge-demo-variant",
  imports: [LudsBadge],
  standalone: true,
  template: `
    <div>
      <div style="display: flex; gap: 10px; flex-wrap: wrap">
        <div ludsBadgeContainer>
          <div ludsBadge variant="magenta-dark" data-testid="luds-badge-magenta-dark" aria-label="1 nova notificação importante">
            <p class="luds-label-medium-default">1</p>
          </div>
        </div>
        <div ludsBadgeContainer>
          <div ludsBadge variant="magenta" data-testid="luds-badge-magenta" aria-label="9 mensagens novas">
            <p class="luds-label-medium-default">9</p>
          </div>
        </div>
        <div ludsBadgeContainer>
          <div ludsBadge variant="purple" data-testid="luds-badge-purple" aria-label="19 atualizações pendentes">
            <p class="luds-label-medium-default">19</p>
          </div>
        </div>
        <div ludsBadgeContainer>
          <div ludsBadge variant="warning" data-testid="luds-badge-warning" aria-label="56 alertas de atenção">
            <p class="luds-label-medium-default">56</p>
          </div>
        </div>
        <div ludsBadgeContainer>
          <div ludsBadge variant="success" data-testid="luds-badge-success" aria-label="82 tarefas concluídas">
            <p class="luds-label-medium-default">82</p>
          </div>
        </div>
        <div ludsBadgeContainer>
          <div ludsBadge variant="info" data-testid="luds-badge-info" aria-label="100 novas informações">
            <p class="luds-label-medium-default">100</p>
          </div>
        </div>
        <div ludsBadgeContainer>
          <div ludsBadge variant="error" data-testid="luds-badge-error" aria-label="1000 erros encontrados">
            <p class="luds-label-medium-default">1000</p>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class BadgeDemoVariantComponent {}
