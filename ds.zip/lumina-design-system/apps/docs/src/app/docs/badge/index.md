{{ NgDocApi.details("libs/ui/blocks/badge/src/badge.ts#LudsBadge") }}

{{ JSDoc.description("libs/ui/blocks/badge/src/badge.ts#LudsBadge") }}

## Playground

{{ NgDocActions.playground("BadgePlayground") }}
{{ NgDocActions.playground("BadgeDotPlayground") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsBadge } from "@luds/ui/blocks/badge";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { phosphorBell } from "@ng-icons/phosphor-icons/regular";

@Component({
  standalone: true,
  imports: [LudsBadge, NgIcon],
  providers: [provideIcons({ phosphorBell })],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<div ludsBadgeContainer>
  <ng-icon name="phosphorBell"></ng-icon>
  <div ludsBadge>
    <p class="luds-label-medium-default">100</p>
  </div>
</div>
```

## Exemplos

### Variantes

{{ NgDocActions.demo("BadgeDemoVariantComponent") }}

Veja a documentação da API: `LudsBadgeVariant`

### Tamanhos

O tamanho `dot` deve ser usado apenas com icons ou icon buttons.

{{ NgDocActions.demo("BadgeDemoSizeComponent") }}

Veja a documentação da API: `LudsBadgeSize`
