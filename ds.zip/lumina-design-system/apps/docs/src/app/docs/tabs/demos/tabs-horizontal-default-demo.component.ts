import { Component } from "@angular/core";
import { LudsBadge } from "@luds/ui/blocks/badge";
import { LudsTabButton, LudsTabList, LudsTabPanel, LudsTabs } from "@luds/ui/blocks/tabs";

@Component({
  selector: "tabs-horizontal-default-demo-component",
  imports: [LudsTabs, LudsTabButton, LudsTabPanel, LudsBadge, LudsTabList],
  template: `
    <div ludsTabs [ludsTabsOrientation]="'horizontal'">
      <div ludsTabList>
        <button ludsTabButton ludsTabButtonValue="tab1">
          Tab Um
          <div ludsBadgeContainer>
            <div ludsBadge aria-label="notificação">
              <p class="luds-label-medium-default">999</p>
            </div>
          </div>
        </button>
        <button ludsTabButton ludsTabButtonValue="tab2">Tab Dois</button>
        <button ludsTabButton ludsTabButtonValue="tab3">Tab Três</button>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab1">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Visão Geral</h1>
          <h2 class="luds-body-small-default">Dashboard principal</h2>
        </div>
        <div>
          <span>
            Bem-vindo ao sistema de gerenciamento! Aqui você encontra um resumo completo de todas as atividades,
            métricas importantes e notificações pendentes. Use este painel para ter uma visão geral do estado atual do
            sistema e acessar rapidamente as funcionalidades mais utilizadas.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab2">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Configurações</h1>
          <h2 class="luds-body-small-default">Personalize sua experiência</h2>
        </div>
        <div>
          <span>
            Configure as preferências do sistema, ajuste as notificações, gerencie permissões de usuário e personalize a
            interface de acordo com suas necessidades. Todas as alterações são salvas automaticamente e aplicadas
            imediatamente.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab3">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Relatórios</h1>
          <h2 class="luds-body-small-default">Análise de dados e estatísticas</h2>
        </div>
        <div>
          <span>
            Acesse relatórios detalhados, gráficos interativos e análises estatísticas. Exporte dados em diversos
            formatos, agende relatórios automáticos e visualize tendências históricas para tomada de decisões
            estratégicas.
          </span>
        </div>
      </div>
    </div>
  `,
  standalone: true,
})
export class TabsHorizontalDefaultDemoComponent {}
