import { LudsBadge } from "@luds/ui/blocks/badge";
import { LudsTabButton, LudsTabList, LudsTabPanel, LudsTabs } from "@luds/ui/blocks/tabs";
import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import {
  TabsHorizontalDefaultDemoComponent,
  TabsHorizontalSmallDemoComponent,
  TabsValueChangeDemoComponent,
  TabsVerticalDefaultDemoComponent,
  TabsVerticalSmallDemoComponent
} from "./demos";

const Tabs: NgDocPage = {
  title: `Tabs`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  imports: [LudsTabButton, LudsTabPanel, LudsTabs, LudsTabList, LudsBadge],
  demos: {
    TabsHorizontalDefaultDemoComponent,
    TabsHorizontalSmallDemoComponent,
    TabsVerticalDefaultDemoComponent,
    TabsVerticalSmallDemoComponent,
    TabsValueChangeDemoComponent
  },
};


export default Tabs;
