export { TabsHorizontalDefaultDemoComponent } from "./tabs-horizontal-default-demo.component";
export { TabsHorizontalSmallDemoComponent } from "./tabs-horizontal-small-demo.component";
export { TabsVerticalDefaultDemoComponent } from "./tabs-vertical-default-demo.component";
export { TabsVerticalSmallDemoComponent } from "./tabs-vertical-small-demo.component";
export { TabsValueChangeDemoComponent } from "./tabs-value-change-demo.component";
