import { Component } from "@angular/core";
import { LudsBadge } from "@luds/ui/blocks/badge";
import { LudsTabButton, LudsTabList, LudsTabPanel, LudsTabs } from "@luds/ui/blocks/tabs";

@Component({
  selector: "tabs-horizontal-small-demo-component",
  imports: [LudsTabs, LudsTabButton, LudsTabPanel, LudsBadge, LudsTabList],
  template: `
    <div ludsTabs [ludsTabsOrientation]="'horizontal'" [ludsTabsSize]="'small'">
      <div ludsTabList>
        <button ludsTabButton ludsTabButtonValue="tab1">
          Tab Um
          <div ludsBadgeContainer>
            <div ludsBadge aria-label="notificação">
              <p class="luds-label-medium-default">999</p>
            </div>
          </div>
        </button>
        <button ludsTabButton ludsTabButtonValue="tab2">Tab Dois</button>
        <button ludsTabButton ludsTabButtonValue="tab3">Tab Três</button>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab1">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Receitas</h1>
          <h2 class="luds-body-small-default">Controle de receitas</h2>
        </div>
        <div>
          <span>
            Monitore todas as receitas e entradas financeiras. Categorize por fonte, acompanhe tendências mensais e
            projete crescimento futuro com base em dados históricos precisos.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab2">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Despesas</h1>
          <h2 class="luds-body-small-default">Controle de gastos</h2>
        </div>
        <div>
          <span>
            Registre e categorize todas as despesas operacionais. Identifique oportunidades de economia, controle
            orçamentos departamentais e mantenha a saúde financeira da empresa.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab3">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Balanço</h1>
          <h2 class="luds-body-small-default">Demonstrativo financeiro</h2>
        </div>
        <div>
          <span>
            Visualize o balanço financeiro completo com relatórios detalhados. Analise lucros, prejuízos, fluxo de caixa
            e tome decisões estratégicas baseadas em informações confiáveis.
          </span>
        </div>
      </div>
    </div>
  `,
  standalone: true,
})
export class TabsHorizontalSmallDemoComponent {}
