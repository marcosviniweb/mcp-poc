{{ NgDocApi.details("libs/ui/blocks/tabs/src/tabs/tabs.ts#LudsTabs") }}

{{ JSDoc.description("libs/ui/blocks/tabs/src/tabs/tabs.ts#LudsTabs") }}

## Preview
{{ NgDocActions.demo("TabsHorizontalDefaultDemoComponent") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsTabButton, LudsTabPanel, LudsTabs, LudsTabList } from "@luds/ui/blocks/tabs";

@Component({
  standalone: true,
  imports: [LudsTabButton, LudsTabPanel, LudsTabs, LudsTabList],
  templateUrl: "./my-component.html",
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<div ludsTabs [ludsTabsOrientation]="'horizontal'">
  <div ludsTabList>
    <button ludsTabButton ludsTabButtonValue="tab1">Tab Um</button>
    <button ludsTabButton ludsTabButtonValue="tab2">Tab Dois</button>
    <button ludsTabButton ludsTabButtonValue="tab3">Tab Três</button>
  </div>
  <div ludsTabPanel ludsTabPanelValue="tab1">
    <div>Conteúdo Tab Um</div>
  </div>
  <div ludsTabPanel ludsTabPanelValue="tab2">
    <div>Conteúdo Tab Dois</div>
  </div>
  <div ludsTabPanel ludsTabPanelValue="tab3">
    <div>Conteúdo Tab Três</div>
  </div>
</div>
```

## Exemplos

### Tabs Horizontal

#### Default

{{ NgDocActions.demo("TabsHorizontalDefaultDemoComponent") }}

#### Small

{{ NgDocActions.demo("TabsHorizontalSmallDemoComponent") }}
Veja a documentação da API: `LudsOrientation`

### Tabs Vertical

#### Default

{{ NgDocActions.demo("TabsVerticalDefaultDemoComponent") }}

#### Small

{{ NgDocActions.demo("TabsVerticalSmallDemoComponent") }}
Veja a documentação da API: `LudsTabsSize`

## Eventos

### Value Change

 - Emite o valor da tab selecionada quando ela muda.
 
{{ NgDocActions.demo("TabsValueChangeDemoComponent") }}
Veja a documentação da API: `LudsTabs`
