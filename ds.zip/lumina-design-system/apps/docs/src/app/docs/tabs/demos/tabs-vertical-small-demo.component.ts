import { Component } from "@angular/core";
import { LudsBadge } from "@luds/ui/blocks/badge";
import { LudsTabButton, LudsTabList, LudsTabPanel, LudsTabs } from "@luds/ui/blocks/tabs";

@Component({
  selector: "tabs-vertical-small-demo-component",
  imports: [LudsTabs, LudsTabButton, LudsTabPanel, LudsBadge, LudsTabList],
  template: `
    <div ludsTabs [ludsTabsOrientation]="'vertical'" [ludsTabsSize]="'small'">
      <div ludsTabList>
        <button ludsTabButton ludsTabButtonValue="tab1">
          Tab Um
          <div ludsBadgeContainer>
            <div ludsBadge aria-label="notificação">
              <p class="luds-label-medium-default">999</p>
            </div>
          </div>
        </button>
        <button ludsTabButton ludsTabButtonValue="tab2">Tab Dois</button>
        <button ludsTabButton ludsTabButtonValue="tab3">Tab Três</button>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab1">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Projetos</h1>
          <h2 class="luds-body-small-default">Gerenciamento de projetos ativos</h2>
        </div>
        <div>
          <span>
            Visualize e gerencie todos os seus projetos em andamento. Acompanhe o progresso, defina prioridades e
            coordene as equipes para garantir entregas no prazo. Interface compacta para máxima produtividade.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab2">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Tarefas</h1>
          <h2 class="luds-body-small-default">Lista de tarefas pendentes</h2>
        </div>
        <div>
          <span>
            Organize suas tarefas diárias, defina prazos e marque como concluídas. Sistema intuitivo de priorização que
            ajuda você a focar no que realmente importa e aumentar sua produtividade.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab3">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Equipe</h1>
          <h2 class="luds-body-small-default">Membros da equipe</h2>
        </div>
        <div>
          <span>
            Gerencie membros da equipe, atribua responsabilidades e monitore a performance individual. Facilite a
            comunicação e colaboração entre os membros para otimizar os resultados.
          </span>
        </div>
      </div>
    </div>
  `,
  standalone: true,
})
export class TabsVerticalSmallDemoComponent {}
