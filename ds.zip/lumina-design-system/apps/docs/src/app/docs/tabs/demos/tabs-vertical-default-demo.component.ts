import { Component } from "@angular/core";
import { LudsBadge } from "@luds/ui/blocks/badge";
import { LudsTabButton, LudsTabList, LudsTabPanel, LudsTabs } from "@luds/ui/blocks/tabs";

@Component({
  selector: "tabs-vertical-default-demo-component",
  imports: [LudsTabs, LudsTabButton, LudsTabPanel, LudsBadge, LudsTabList],
  template: `
    <div ludsTabs [ludsTabsOrientation]="'vertical'">
      <div ludsTabList>
        <button ludsTabButton ludsTabButtonValue="tab1">
          Tab Um
          <div ludsBadgeContainer>
            <div ludsBadge aria-label="notificação">
              <p class="luds-label-medium-default">999</p>
            </div>
          </div>
        </button>
        <button ludsTabButton ludsTabButtonValue="tab2">Tab Dois</button>
        <button ludsTabButton ludsTabButtonValue="tab3">Tab Três</button>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab1">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Produtos</h1>
          <h2 class="luds-body-small-default">Catálogo de produtos</h2>
        </div>
        <div>
          <span>
            Gerencie seu catálogo completo de produtos com facilidade. Adicione novos itens, atualize preços, controle
            estoque e organize categorias para uma experiência de compra otimizada.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab2">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Pedidos</h1>
          <h2 class="luds-body-small-default">Gerenciamento de pedidos</h2>
        </div>
        <div>
          <span>
            Acompanhe todos os pedidos em tempo real, desde a confirmação até a entrega. Gerencie status, processe
            pagamentos e mantenha os clientes informados sobre o andamento.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab3">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Clientes</h1>
          <h2 class="luds-body-small-default">Base de clientes</h2>
        </div>
        <div>
          <span>
            Mantenha um relacionamento próximo com seus clientes. Acesse histórico de compras, preferências, dados de
            contato e implemente estratégias de fidelização eficazes.
          </span>
        </div>
      </div>
    </div>
  `,
  standalone: true,
})
export class TabsVerticalDefaultDemoComponent {}
