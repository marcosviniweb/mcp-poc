import { Component } from "@angular/core";
import { LudsBadge } from "@luds/ui/blocks/badge";
import { LudsTabButton, LudsTabList, LudsTabPanel, LudsTabs } from "@luds/ui/blocks/tabs";

@Component({
  selector: "tabs-value-change-demo-component",
  imports: [LudsTabs, LudsTabButton, LudsTabPanel, LudsBadge, LudsTabList],
  template: `
    <div ludsTabs [ludsTabsOrientation]="'horizontal'" (ludsTabsValueChange)="onTabChange($event)">
      <div ludsTabList>
        <button ludsTabButton ludsTabButtonValue="tab1">
          Tab Um
          <div ludsBadgeContainer>
            <div ludsBadge aria-label="notificação">
              <p class="luds-label-medium-default">999</p>
            </div>
          </div>
        </button>
        <button ludsTabButton ludsTabButtonValue="tab2">Tab Dois</button>
        <button ludsTabButton ludsTabButtonValue="tab3">Tab Três</button>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab1">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Analytics</h1>
          <h2 class="luds-body-small-default">Métricas em tempo real</h2>
        </div>
        <div>
          <span>
            Monitore métricas essenciais em tempo real com dashboards interativos. Acompanhe KPIs importantes,
            identifique tendências e tome decisões baseadas em dados concretos.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab2">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Performance</h1>
          <h2 class="luds-body-small-default">Indicadores de performance</h2>
        </div>
        <div>
          <span>
            Analise indicadores de performance do sistema, tempo de resposta e disponibilidade. Identifique gargalos e
            otimize recursos para melhorar a experiência do usuário.
          </span>
        </div>
      </div>
      <div ludsTabPanel ludsTabPanelValue="tab3">
        <div ludsTabPanelHeader>
          <h1 class="luds-title-small">Alertas</h1>
          <h2 class="luds-body-small-default">Sistema de notificações</h2>
        </div>
        <div>
          <span>
            Configure alertas personalizados para eventos críticos. Receba notificações instantâneas sobre problemas,
            limite de recursos ou anomalias no sistema para ação imediata.
          </span>
        </div>
      </div>
    </div>
  `,
  standalone: true,
})
export class TabsValueChangeDemoComponent {
  onTabChange(value: string | undefined): void {
    alert("Tab selecionada: " + value);
  }
}
