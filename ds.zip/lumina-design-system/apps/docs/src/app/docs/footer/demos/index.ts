export { FooterDemoComponent } from './footer-demo.component';
