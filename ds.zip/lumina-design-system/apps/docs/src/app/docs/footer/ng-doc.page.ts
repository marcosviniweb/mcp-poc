import { NgDocPage } from '@ng-doc/core';
import ComponentsCategory from 'apps/docs/src/categories/components/ng-doc.category';
import { FooterDemoComponent } from './demos/footer-demo.component';

const Footer: NgDocPage = {
  title: `Footer`,
  mdFile: './index.md',
  category: ComponentsCategory,

  demos: {
    FooterDemoComponent,
  }
};

export default Footer;
