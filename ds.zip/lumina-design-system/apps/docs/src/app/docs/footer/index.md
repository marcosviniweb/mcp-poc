{{ NgDocApi.details("libs/ui/blocks/footer/src/footer.ts#LudsFooter") }}

{{ JSDoc.description("libs/ui/blocks/footer/src/footer.ts#LudsFooter") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsFooter } from '@luds/ui/blocks/footer';

@Component({
  standalone: true,
  imports: [LudsFooter],
  templateUrl: './my-component.html',
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
      <footer ludsFooter>
        <p class="luds-note-medium-default">© Serasa Experian | nome do produto</p>
        <div ludsFooterLinks>
            <a class="luds-note-medium-link" href="">Termos de uso</a>
            <a class="luds-note-medium-link" href="">Central de ajuda</a>
        </div>
      </footer>
```

## Exemplos

{{ NgDocActions.demo("FooterDemoComponent") }}

