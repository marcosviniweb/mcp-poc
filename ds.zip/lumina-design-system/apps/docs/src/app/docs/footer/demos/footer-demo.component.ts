import { Component } from '@angular/core';
import { LudsFooter } from '@luds/ui/blocks/footer';

@Component({
  selector: 'footer-demo',
  imports: [LudsFooter],
  standalone: true,
  template: `
      <footer ludsFooter>
        <p class="luds-note-medium-default">© Serasa Experian | nome do produto</p>
        <div ludsFooterLinks>
            <a class="luds-note-medium-link" href="">Termos de uso</a>
            <a class="luds-note-medium-link" href="">Central de ajuda</a>
        </div>
      </footer>
  `,
})
export class FooterDemoComponent {}
