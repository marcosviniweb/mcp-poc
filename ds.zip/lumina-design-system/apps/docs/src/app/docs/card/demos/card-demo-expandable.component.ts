import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsButton } from "@luds/ui/blocks/button";
import {
  LudsCard,
  LudsCardExpandable,
  LudsCardExpandContainer,
  LudsCardExpandIcon,
  LudsCardHeader,
  LudsCardHeaderBar,
  LudsCardIcon,
  LudsCardAction,
  LudsCardContainer,
  LudsCardBody,
  LudsCardTitle,
  LudsCardDescription,
  LudsCardFooter,
} from "@luds/ui/blocks/card";
import { phosphorArrowsClockwise, phosphorArrowsOut } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "card-demo-expandable",
  standalone: true,
  imports: [
    LudsButton,
    NgIcon,
    LudsCard,
    LudsCardExpandable,
    LudsCardExpandContainer,
    LudsCardExpandIcon,
    LudsCardHeader,
    LudsCardHeaderBar,
    LudsCardIcon,
    LudsCardAction,
    LudsCardContainer,
    LudsCardBody,
    LudsCardTitle,
    LudsCardDescription,
    LudsCardFooter,
  ],
  providers: [
    provideIcons({
      phosphorArrowsClockwise,
      phosphorArrowsOut,
    }),
  ],
  template: `
    <div class="demo-container">
      <h3>Grupo 1 - Container Isolado</h3>
      <div class="cards-container" ludsCardExpandContainer>
        <!-- Card 1.1 - Expansível no Grupo 1 -->
        <section ludsCard ludsCardExpandable>
          <div ludsCardContainer>
            <div ludsCardHeaderBar>
                            <div ludsCardHeader>
              <p ludsCardTitle class="luds-title-small">Card Grupo 1A</p>
              <p ludsCardDescription class="luds-body-medium-default">
                Este card pertence ao Grupo 1. Apenas um card por grupo pode estar expandido.
              </p>
            </div>
              <button buttonType="icon-button" ludsButton variant="tertiary" ludsCardExpandIcon>
                <ng-icon name="phosphorArrowsOut"></ng-icon>
              </button>
            </div>

            <div ludsCardFooter>
              <button ludsButton [variant]="'primary'" [size]="'small'">Ação 1A</button>
            </div>
          </div>
        </section>
        <section ludsCard ludsCardExpandable>
          <div ludsCardContainer>
            <div ludsCardHeaderBar>
              <ng-icon name="phosphorArrowsClockwise" ludsCardIcon></ng-icon>
              <button buttonType="icon-button" ludsButton variant="tertiary" ludsCardExpandIcon>
                <ng-icon name="phosphorArrowsOut"></ng-icon>
              </button>
            </div>
            <div ludsCardHeader>
              <p ludsCardTitle class="luds-title-small">Card Grupo 1A</p>
              <p ludsCardDescription class="luds-body-medium-default">
                Este card pertence ao Grupo 1. Apenas um card por grupo pode estar expandido.
              </p>
            </div>

            <div ludsCardFooter>
              <button ludsButton [variant]="'primary'" [size]="'small'">Ação 1A</button>
            </div>
          </div>
        </section>
        <section ludsCard ludsCardExpandable>
          <div ludsCardContainer>
            <div ludsCardHeaderBar>
              <ng-icon name="phosphorArrowsClockwise" ludsCardIcon></ng-icon>
              <button buttonType="icon-button" ludsButton variant="tertiary" ludsCardExpandIcon>
                <ng-icon name="phosphorArrowsOut"></ng-icon>
              </button>
            </div>
            <div ludsCardHeader>
              <p ludsCardTitle class="luds-title-small">Card Grupo 1A</p>
              <p ludsCardDescription class="luds-body-medium-default">
                Este card pertence ao Grupo 1. Apenas um card por grupo pode estar expandido.
              </p>
            </div>

            <div ludsCardFooter>
              <button ludsButton [variant]="'primary'" [size]="'small'">Ação 1A</button>
            </div>
          </div>
        </section>
      </div>
      <div class="cards-container" ludsCardExpandContainer>
        <!-- Card 1.1 - Expansível no Grupo 1 -->
        <section ludsCard ludsCardExpandable>
          <div ludsCardContainer>
            <div ludsCardHeaderBar>
              <ng-icon name="phosphorArrowsClockwise" ludsCardIcon></ng-icon>
              <button buttonType="icon-button" ludsButton variant="tertiary" ludsCardExpandIcon>
                <ng-icon name="phosphorArrowsOut"></ng-icon>
              </button>
            </div>
            <div ludsCardHeader>
              <p ludsCardTitle class="luds-title-small">Card Grupo 1A</p>
              <p ludsCardDescription class="luds-body-medium-default">
                Este card pertence ao Grupo 1. Apenas um card por grupo pode estar expandido.
              </p>
            </div>

            <div ludsCardFooter>
              <button ludsButton [variant]="'primary'" [size]="'small'">Ação 1A</button>
            </div>
          </div>
        </section>
        <section ludsCard ludsCardExpandable>
          <div ludsCardContainer>
            <div ludsCardHeaderBar>
              <ng-icon name="phosphorArrowsClockwise" ludsCardIcon></ng-icon>
              <button buttonType="icon-button" ludsButton variant="tertiary" ludsCardExpandIcon>
                <ng-icon name="phosphorArrowsOut"></ng-icon>
              </button>
            </div>
            <div ludsCardHeader>
              <p ludsCardTitle class="luds-title-small">Card Grupo 1A</p>
              <p ludsCardDescription class="luds-body-medium-default">
                Este card pertence ao Grupo 1. Apenas um card por grupo pode estar expandido.
              </p>
            </div>

            <div ludsCardFooter>
              <button ludsButton [variant]="'primary'" [size]="'small'">Ação 1A</button>
            </div>
          </div>
        </section>
        <section ludsCard ludsCardExpandable>
          <div ludsCardContainer>
            <div ludsCardHeaderBar>
              <ng-icon name="phosphorArrowsClockwise" ludsCardIcon></ng-icon>
              <button buttonType="icon-button" ludsButton variant="tertiary" ludsCardExpandIcon>
                <ng-icon name="phosphorArrowsOut"></ng-icon>
              </button>
            </div>
            <div ludsCardHeader>
              <p ludsCardTitle class="luds-title-small">Card Grupo 1A</p>
              <p ludsCardDescription class="luds-body-medium-default">
                Este card pertence ao Grupo 1. Apenas um card por grupo pode estar expandido.
              </p>
            </div>

            <div ludsCardFooter>
              <button ludsButton [variant]="'secondary'" [size]="'small'">Ação 1A</button>
              <button ludsButton [variant]="'primary'" [size]="'small'">Ação 1B</button>
            </div>
          </div>
        </section>
      </div>
    </div>
  `,
  styles: `
    .demo-container {
      display: flex;
      flex-direction: column;
      gap: 24px;
    }

    .demo-container h3 {
      margin: 0 0 12px 0;
      color: #333;
      font-size: 16px;
      font-weight: 600;
    }

    .cards-container {
      display: flex;
      gap: 16px;
      flex-wrap: wrap;
      align-items: flex-start;
      padding: 16px;
      border: 2px dashed #e0e0e0;
      border-radius: 8px;
    }

    /* Card normal - tamanho padrão */
    [ludsCard] {
      width: 280px;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      transform-origin: center;
    }

    /* Card expandido - comportamento similar ao fullscreen */
    [ludsCard][data-expanded] {
      width: 400px;
      z-index: 10;
      position: relative;
    }

    /* Estilo para o botão de expansão */
    [ludsCard] [ludsCardExpandIcon] {
      transition: all 0.3s ease;
      cursor: pointer;
      pointer-events: auto;
      z-index: 10;
      position: relative;
      display: inline-block;
    }

    /* Garante que a área de ação seja clicável */
    [ludsCardAction] {
      pointer-events: auto;
      z-index: 5;
      position: relative;
    }
  `,
})
export class CardDemoExpandableComponent {}
