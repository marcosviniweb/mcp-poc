import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsButton } from "@luds/ui/blocks/button";
import {
  phosphorArrowsClockwise,
  phosphorArrowsOutSimple,
  phosphorCaretRight,
  phosphorInfo,
  phosphorX,
} from "@ng-icons/phosphor-icons/regular";
import {
  LudsCard,
  LudsCardBody,
  LudsCardContainer,
  LudsCardDescription,
  LudsCardHeader,
  LudsCardIcon,
  LudsCardTitle,
} from "@luds/ui/blocks/card";
import { LudsTag } from "@luds/ui/blocks/tag";
import { LudsChip } from "@luds/ui/blocks/chip";

@Component({
  selector: "card-demo-medium",
  imports: [
    LudsButton,
    LudsTag,
    LudsChip,
    LudsCard,
    LudsCardHeader,
    LudsCardIcon,
    LudsCardContainer,
    LudsCardBody,
    LudsCardTitle,
    LudsCardDescription,
    NgIcon,
  ],
  providers: [
    provideIcons({ phosphorArrowsClockwise, phosphorInfo, phosphorCaretRight, phosphorX, phosphorArrowsOutSimple }),
  ],
  template: `
    <div class="demo-container">
      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeaderBar>
            <ng-icon name="phosphorArrowsClockwise" ludsCardIcon></ng-icon>
          </div>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
          <div ludsCardBody>
            <p ludsCardOptionalText>{{ "{" }}500{{ "}" }} empresas do seu setor estão usando</p>
          </div>
          <div ludsCardFooter>
            <button ludsButton size="small">Adicionar</button>
          </div>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeaderBar>
            <ng-icon name="phosphorArrowsClockwise" ludsCardIcon></ng-icon>
          </div>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
          <div ludsCardBody>
            <p ludsCardOptionalText>{{ "{" }}500{{ "}" }} empresas do seu setor estão usando</p>
          </div>
        </div>
        <div ludsCardAction>
          <button ludsButton type="icon-button" size="small" variant="tertiary">
            <ng-icon name="phosphorCaretRight"></ng-icon>
          </button>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
          <div ludsCardBody>
            <p ludsCardOptionalText>{{ "{" }}500{{ "}" }} empresas do seu setor estão usando</p>
          </div>
          <div ludsCardFooter>
            <button ludsButton size="small">Adicionar</button>
          </div>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
          <div ludsCardBody>
            <p ludsCardOptionalText>{{ "{" }}500{{ "}" }} empresas do seu setor estão usando</p>
          </div>
        </div>
        <div ludsCardAction>
          <button ludsButton type="icon-button" size="small" variant="tertiary">
            <ng-icon name="phosphorCaretRight"></ng-icon>
          </button>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
          <div ludsCardFooter>
            <button ludsButton size="small">Adicionar</button>
          </div>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
        </div>
        <div ludsCardAction>
          <button ludsButton type="icon-button" size="small" variant="tertiary">
            <ng-icon name="phosphorCaretRight"></ng-icon>
          </button>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeaderBar>
            <span ludsTag size="small" type="info" background="soft">
              <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
              <p class="luds-label-large-bold">title</p>
            </span>
          </div>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
          <div ludsCardFooter>
            <button ludsButton size="small">Adicionar</button>
          </div>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeaderBar>
            <span ludsTag size="small" type="info" background="soft">
              <ng-icon ludsTagIcon name="phosphorInfo"></ng-icon>
              <p class="luds-label-large-bold">title</p>
            </span>
          </div>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
        </div>
        <div ludsCardAction>
          <button ludsButton type="icon-button" size="small" variant="tertiary">
            <ng-icon name="phosphorCaretRight"></ng-icon>
          </button>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
          <div ludsCardBody>
            <span ludsChip #chip="ludsChip" size="small" [closeable]="true" aria-label="Chip fechável">
              <p class="luds-label-large-default">content</p>
              @if (chip.closeable()) {
                <ng-icon ludsChipCloseIcon name="phosphorX" tabindex="0" aria-label="Fechar"></ng-icon>
              }
            </span>
          </div>
          <div ludsCardFooter>
            <button ludsButton size="small">Adicionar</button>
          </div>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
          <div ludsCardBody>
            <span ludsChip #chip="ludsChip" size="small" [closeable]="true" aria-label="Chip fechável">
              <p class="luds-label-large-default">content</p>
              @if (chip.closeable()) {
                <ng-icon ludsChipCloseIcon name="phosphorX" tabindex="0" aria-label="Fechar"></ng-icon>
              }
            </span>
          </div>
        </div>
        <div ludsCardAction>
          <button ludsButton type="icon-button" size="small" variant="tertiary">
            <ng-icon name="phosphorCaretRight"></ng-icon>
          </button>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeaderBar>
            <div ludsCardHeader>
              <h3 ludsCardTitle>Title</h3>
              <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
            </div>
            <button buttonType="icon-button" size="small" ludsButton variant="tertiary" ludsCardExpandIcon>
              <ng-icon name="phosphorArrowsOutSimple"></ng-icon>
            </button>
          </div>
          <div ludsCardFooter>
            <button ludsButton size="small">Adicionar</button>
          </div>
        </div>
      </section>

      <section ludsCard size="medium">
        <div ludsCardContainer>
          <div ludsCardHeader>
            <h3 ludsCardTitle>Title</h3>
            <p ludsCardDescription>Texto descritivo, explicativo e resumido da feature/oferta de até três linhas.</p>
          </div>
        </div>
        <div ludsCardAction>
          <button ludsButton type="icon-button" size="small" variant="tertiary">
            <ng-icon name="phosphorCaretRight"></ng-icon>
          </button>
          <button buttonType="icon-button" size="small" ludsButton variant="tertiary" ludsCardExpandIcon>
            <ng-icon name="phosphorArrowsOutSimple"></ng-icon>
          </button>
        </div>
      </section>
    </div>
  `,
  standalone: true,
  styles: `
    .demo-container {
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      gap: 24px;
    }

    [ludsCard] {
      width: 280px;
    }
  `,
})
export class CardDemoMediumComponent {}
