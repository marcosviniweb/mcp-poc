O Card é um componente visual utilizado para agrupar e exibir informações de forma clara, compacta e organizada. Ele oferece uma estrutura modular que facilita a leitura e a interação do usuário com o conteúdo apresentado.

### Exemplos de Cards Small

{{ NgDocActions.demo("CardDemoSmallComponent") }}

### Exemplos de Cards Medium

{{ NgDocActions.demo("CardDemoMediumComponent") }}

### Exemplos de Cards Large

{{ NgDocActions.demo("CardDemoLargeComponent") }}

### Exemplos de Baixo Contraste

{{ NgDocActions.demo("CardDemoLowContrastComponent", {class: "card-low-contrast-demo"}) }}

### Exemplo com ícone expansível

{{ NgDocActions.demo("CardDemoExpandableComponent") }}
