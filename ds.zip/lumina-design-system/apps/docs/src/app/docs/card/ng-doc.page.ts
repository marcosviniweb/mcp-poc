import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { CardDemoExpandableComponent } from "./demos/card-demo-expandable.component";
import { CardDemoSmallComponent, CardDemoMediumComponent, CardDemoLargeComponent, CardDemoLowContrastComponent } from "./demos";

const Card: NgDocPage = {
  title: `Card`,
  mdFile: "./index.md",
  category: ComponentsCategory,

  demos: {
    CardDemoSmallComponent,
    CardDemoMediumComponent,
    CardDemoLargeComponent,
    CardDemoExpandableComponent,
    CardDemoLowContrastComponent
  },
};

export default Card;
