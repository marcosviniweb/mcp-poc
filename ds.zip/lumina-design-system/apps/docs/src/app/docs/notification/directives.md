---
title: Diretivas
route: diretivas
keyword: NotificationDirectivesPage
---

Para casos que requerem maior flexibilidade na estrutura HTML ou customizações específicas do sistema de Notificações, você pode utilizar as diretivas de baixo nível do sistema de Menu.

O template Notification é essencialmente um caso de uso específico do [Menu](/components/menu/directives), portanto, todas as funcionalidades de diretivas estão disponíveis:

- **`ludsMenuTrigger`**: Diretiva para o elemento que abre o menu
- **`ludsMenu`**: Container principal do menu
- **`ludsMenuArrow`**: Seta do menu (opcional)
- **`ludsMenuHeader`**: Cabeçalho do menu
- **`ludsMenuContent`**: Container dos itens
- **`ludsMenuItem`**: Itens individuais do menu

## Exemplo Prático

Aqui está um exemplo completo de como criar um componente de notificação customizado usando as diretivas:

{{ NgDocActions.demo("BlockNotificationDemo") }}

## Documentação Completa

Para informações detalhadas sobre todas as diretivas, configurações avançadas e exemplos práticos, consulte a **[documentação de diretivas do Menu](/components/menu/diretivas)**.

Lá você encontrará:

- Estrutura completa das diretivas
- Configurações de posicionamento (`provideMenuConfig`)
- Headers horizontais e verticais
- Controle de setas
- Separadores entre itens
- Exemplos complexos e casos de uso avançados

Para casos simples, recomendamos usar os [componentes fechados](/templates/notification) que já oferecem uma solução pronta e padronizada.
