import { NgDocPage } from '@ng-doc/core';
import TemplatesCategory from 'apps/docs/src/categories/templates/ng-doc.category';
import { NotificationDemo, EmptyNotificationDemo, BlockNotificationDemo } from './demos';

/**
 * @status:info NEW
 */
const Notification: NgDocPage = {
  title: `Notification`,
  mdFile: ['./index.md', './directives.md'],
  category: TemplatesCategory,
  demos: { NotificationDemo, EmptyNotificationDemo, BlockNotificationDemo },
};

export default Notification;