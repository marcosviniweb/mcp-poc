import { Component, signal, ChangeDetectionStrategy } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsMenuTrigger } from "@luds/ui/blocks/menu";
import { LudsButton } from "@luds/ui/blocks/button";
import { Notification, NotificationItem, INotification } from "@luds/ui/components/notification";
import { phosphorBellSimple } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "notification-demo",
  imports: [LudsMenuTrigger, LudsButton, Notification, NotificationItem, NgIcon],
  providers: [provideIcons({ phosphorBellSimple })],
  template: `
    <button
      [ludsMenuTrigger]="menu"
      ludsButton
      variant="tertiary"
      buttonType="icon-button"
      #menuTrigger="ludsMenuTrigger"
    >
      <ng-icon name="phosphorBellSimple"></ng-icon>
    </button>
    <ng-template #menu>
      <luds-notification (markAllAsRead)="markAllAsRead()">
        @for (notification of notifications(); track notification.id) {
          <luds-notification-item
            (markAsRead)="markAsRead(notification.id)"
            [id]="notification.id"
            [title]="notification.title"
            [timestamp]="notification.timestamp"
            [isRead]="notification.isRead"
          >
            {{ notification.content }}
          </luds-notification-item>
        }
      </luds-notification>
    </ng-template>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
})
export class NotificationDemo {
  protected readonly notifications = signal<INotification[]>([
    {
      id: "1",
      title: "Nova consulta ao CPF realizada",
      content: "Sua consulta ao CPF 123.456.789-00 foi processada com sucesso. Acesse o relatório completo.",
      timestamp: "14:32",
      isRead: false,
    },
    {
      id: "2",
      title: "Score atualizado",
      content: "Seu Serasa Score foi atualizado para 650 pontos. Veja as dicas para melhorar ainda mais.",
      timestamp: "13:45",
      isRead: false,
    },
    {
      id: "3",
      title: "Alerta de negativação",
      content: "Identificamos uma nova negativação em seu CPF. Verifique os detalhes e regularize se necessário.",
      timestamp: "10/09",
      isRead: false,
    },
    {
      id: "4",
      title: "Relatório mensal disponível",
      content: "Seu relatório de crédito de setembro está pronto. Acompanhe seu histórico financeiro.",
      timestamp: "09/09",
      isRead: true,
    },
  ]);

  protected markAsRead(notificationId: string): void {
    this.notifications.update((notifications) =>
      notifications.map((notification) =>
        notification.id === notificationId ? { ...notification, isRead: true } : notification,
      ),
    );
  }

  protected markAllAsRead(): void {
    this.notifications.update((notifications) =>
      notifications.map((notification) => ({ ...notification, isRead: true })),
    );
  }
}
