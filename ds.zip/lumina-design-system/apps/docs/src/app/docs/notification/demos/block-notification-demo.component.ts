import { Component, signal, computed, ChangeDetectionStrategy } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsMenuTrigger, LudsMenu, LudsMenuItem, LudsMenuArrow, provideMenuConfig } from "@luds/ui/blocks/menu";
import { LudsButton } from "@luds/ui/blocks/button";
import { LudsBadge } from "@luds/ui/blocks/badge";
import { FocusOrigin } from "@angular/cdk/a11y";
import { phosphorBellSimple, phosphorWarningCircle, phosphorCaretRight } from "@ng-icons/phosphor-icons/regular";

interface INotification {
  id: string;
  title: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

@Component({
  selector: "block-notification-demo",
  imports: [LudsMenuTrigger, LudsMenu, LudsMenuItem, LudsButton, LudsMenuArrow, LudsBadge, NgIcon],
  providers: [
    provideMenuConfig({
      autoplacement: false,
      flip: false,
    }),
    provideIcons({ phosphorBellSimple, phosphorWarningCircle, phosphorCaretRight }),
  ],
  template: `
    <button
      [ludsMenuTrigger]="menu"
      ludsButton
      variant="tertiary"
      buttonType="icon-button"
      #menuTrigger="ludsMenuTrigger"
    >
      <ng-icon name="phosphorBellSimple"></ng-icon>
    </button>
    <ng-template #menu>
      <div ludsMenu>
        <div ludsMenuArrow></div>
        <div ludsMenuHeader data-direction="row">
          <span class="luds-body-large-bold">Notificações</span>
          @if (notifications().length > 0) {
            <button ludsButton variant="tertiary" (click)="markAllAsRead($event, menuTrigger)">
              Marcar como lidas
            </button>
          }
        </div>

        <div ludsMenuContent>
          @if (notifications().length === 0) {
            <div ludsNotificationEmpty>
              <ng-icon name="phosphorWarningCircle"></ng-icon>
              <div>
                <p class="luds-title-small">Ainda não temos nada por aqui</p>
                <p class="luds-body-small-default">Te avisamos quando tiver algo para fazer</p>
              </div>
            </div>
          } @else {
            @for (notification of notifications(); track notification.id) {
              <button ludsMenuItem data-separator="true" (click)="markAsRead(notification.id)">
                <div ludsNotificationItem>
                  <div ludsNotificationItemContent>
                    <div
                      ludsNotificationItemTitle
                      [class]="notification.isRead ? 'luds-label-medium-default' : 'luds-label-medium-bold'"
                      [class.unread]="!notification.isRead"
                    >
                      @if (!notification.isRead) {
                        <div ludsBadgeContainer>
                          <div ludsBadge variant="purple" size="small" aria-label="Notificação não lida"></div>
                        </div>
                      }
                      {{ notification.title }}
                    </div>
                    <p class="luds-body-medium-default">
                      {{ notification.content }}
                    </p>
                    <span ludsNotificationItemTimestamp class="luds-label-medium-default">
                      {{ notification.timestamp }}
                    </span>
                  </div>
                  <button ludsButton buttonType="icon-button" variant="tertiary">
                    <ng-icon name="phosphorCaretRight"></ng-icon>
                  </button>
                </div>
              </button>
            }
          }
        </div>
      </div>
    </ng-template>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
})
export class BlockNotificationDemo {
  protected readonly notifications = signal<INotification[]>([
    {
      id: "1",
      title: "Nova consulta ao CPF realizada",
      content: "Sua consulta ao CPF 123.456.789-00 foi processada com sucesso. Acesse o relatório completo.",
      timestamp: "14:32",
      isRead: false,
    },
    {
      id: "2",
      title: "Score atualizado",
      content: "Seu Serasa Score foi atualizado para 650 pontos. Veja as dicas para melhorar ainda mais.",
      timestamp: "13:45",
      isRead: false,
    },
    {
      id: "3",
      title: "Alerta de negativação",
      content: "Identificamos uma nova negativação em seu CPF. Verifique os detalhes e regularize se necessário.",
      timestamp: "10/09",
      isRead: false,
    },
    {
      id: "4",
      title: "Relatório mensal disponível",
      content: "Seu relatório de crédito de setembro está pronto. Acompanhe seu histórico financeiro.",
      timestamp: "09/09",
      isRead: true,
    },
  ]);

  protected markAsRead(notificationId: string): void {
    this.notifications.update((notifications) =>
      notifications.map((notification) =>
        notification.id === notificationId ? { ...notification, isRead: true } : notification,
      ),
    );
  }

  protected markAllAsRead(event: MouseEvent, menuTrigger: LudsMenuTrigger): void {
    this.notifications.update((notifications) =>
      notifications.map((notification) => ({ ...notification, isRead: true })),
    );

    const origin: FocusOrigin = event.detail === 0 ? "keyboard" : "mouse";
    menuTrigger.hide(origin);
  }
}
