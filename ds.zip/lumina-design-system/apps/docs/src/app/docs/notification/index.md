---
title: Components
keyword: NotificationComponentPage
---

O template Notification oferece uma solução pronta para sistemas de notificações, utilizando os componentes fechados do sistema (`luds-notification` e `luds-notification-item`). Eles se baseiam nas diretivas do [Menu](/componentes/menu/diretivas) e focam na apresentação visual padronizada de notificações, permitindo marcar como lidas e exibir estados vazios.

## Exemplo com Notificações

{{ NgDocActions.demo("NotificationDemo") }}

## Estado Vazio

{{ NgDocActions.demo("EmptyNotificationDemo") }}

## Estrutura de Dados

```typescript name="notification-interface.ts"
interface INotification {
  id: string;
  title: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}
```

## Customização Avançada

Para casos que requerem maior flexibilidade na estrutura HTML ou funcionalidades específicas, consulte a [documentação de diretivas](/templates/notification/diretivas), que explica como usar as diretivas de baixo nível do menu.
