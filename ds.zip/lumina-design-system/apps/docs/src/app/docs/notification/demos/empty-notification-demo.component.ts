import { Component, signal, computed, ChangeDetectionStrategy } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsMenuTrigger } from "@luds/ui/blocks/menu";
import { LudsButton } from "@luds/ui/blocks/button";
import { Notification, NotificationItem, INotification } from "@luds/ui/components/notification";
import { phosphorBellSimple } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "empty-notification-demo",
  imports: [LudsMenuTrigger, LudsButton, Notification, NotificationItem, NgIcon],
  providers: [provideIcons({ phosphorBellSimple })],
  template: `
    <button [ludsMenuTrigger]="menu" ludsButton variant="tertiary" buttonType="icon-button">
      <ng-icon name="phosphorBellSimple"></ng-icon>
    </button>
    <ng-template #menu>
      <luds-notification (markAllAsRead)="markAllAsRead()">
        @for (notification of notifications(); track notification.id) {
          <luds-notification-item
            (markAsRead)="markAsRead(notification.id)"
            [id]="notification.id"
            [title]="notification.title"
            [timestamp]="notification.timestamp"
            [isRead]="notification.isRead"
          ></luds-notification-item>
        }
      </luds-notification>
    </ng-template>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
})
export class EmptyNotificationDemo {
  protected readonly notifications = signal<INotification[]>([]);

  protected readonly unreadCount = computed(() => this.notifications().filter((n) => !n.isRead).length);

  protected markAsRead(notificationId: string): void {
    this.notifications.update((notifications) =>
      notifications.map((notification) =>
        notification.id === notificationId ? { ...notification, isRead: true } : notification,
      ),
    );
  }

  protected markAllAsRead(): void {
    this.notifications.update((notifications) =>
      notifications.map((notification) => ({ ...notification, isRead: true })),
    );
  }
}
