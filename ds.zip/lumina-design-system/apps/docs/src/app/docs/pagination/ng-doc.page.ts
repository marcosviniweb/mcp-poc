import { NgIcon, provideIcons } from "@ng-icons/core";
import { NgDocPage } from "@ng-doc/core";
import ComponentsCategory from "apps/docs/src/categories/components/ng-doc.category";
import { PaginationDemoComponent } from "./demos/pagination-demo.component";
import {
  LudsPagination,
  LudsPaginationButton,
  LudsPaginationFirst,
  LudsPaginationLast,
  LudsPaginationNext,
  LudsPaginationPrevious,
} from "@luds/ui/blocks/pagination";
import { LudsButton } from "@luds/ui/blocks/button";
import { LudsPopover, LudsPopoverTrigger } from "@luds/ui/blocks/popover";
import { LudsListbox, LudsListboxOption, LudsListboxTrigger } from "@luds/ui/blocks/listbox";
import { LudsFormField } from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";
import {
  phosphorCaretDoubleLeft,
  phosphorCaretLeft,
  phosphorCaretRight,
  phosphorCaretDoubleRight,
  phosphorCaretUp,
  phosphorCaretDown,
} from "@ng-icons/phosphor-icons/regular";

const Pagination: NgDocPage = {
  title: `Pagination`,
  mdFile: "./index.md",
  category: ComponentsCategory,
  demos: { PaginationDemoComponent },
  imports: [
    LudsPagination,
    LudsPaginationFirst,
    LudsPaginationPrevious,
    LudsPaginationButton,
    LudsPaginationNext,
    LudsPaginationLast,
    LudsButton,
    LudsPopover,
    LudsPopoverTrigger,
    LudsListbox,
    LudsListboxOption,
    LudsListboxTrigger,
    LudsFormField,
    LudsInput,
    LudsButton,
    NgIcon,
  ],
  providers: [
    provideIcons({
      phosphorCaretDoubleLeft,
      phosphorCaretLeft,
      phosphorCaretRight,
      phosphorCaretDoubleRight,
      phosphorCaretUp,
      phosphorCaretDown,
    }),
  ],
  playgrounds: {
    PaginationPlayground: {
      target: LudsPagination,
      selectors: "[ludsPagination]",
      template: `
        <div ludsPaginationContainer>
          <div ludsPaginationControls>
            <span class="luds-body-medium-default">Itens por página</span>
            <div ludsFormField>
              <input
                ludsInput
                readonly
                ludsListboxTrigger
                [ludsPopoverTrigger]="dropdown"
                #popoverTrigger="ludsPopoverTrigger"
                [value]="pagination.getItemsPerPage()"
              />
              <ng-icon [name]="popoverTrigger.open() ? 'phosphorCaretUp' : 'phosphorCaretDown'"></ng-icon>
              <ng-template #dropdown>
                <div ludsPopover>
                  <div
                    ludsListbox
                    (ludsListboxValueChange)="pagination.setItemsPerPage($event[0])"
                    aria-label="Itens por página"
                  >
                    @for (option of pagination.itemsPerPageOptions(); track option) {
                    <div [ludsListboxOptionValue]="option" ludsListboxOption>
                      {{ option }}
                    </div>
                    }
                  </div>
                </div>
              </ng-template>
            </div>
            <span class="luds-body-medium-default">{{ pagination.rangeLabel() }}</span>
          </div>
          <nav
            ludsPagination
            [ludsPaginationItemsPerPageOptions]="[10,25,50,100]"
            #pagination="ludsPagination"
            style="margin: 4px 0"
            aria-label="Paginação"
          >
            <button
              ludsButton
              ludsPaginationFirst
              buttonType="icon-button"
              variant="tertiary"
              size="small"
              aria-label="Primeira página"
            >
              <ng-icon  name="phosphorCaretDoubleLeft"></ng-icon>
            </button>
            <button
              ludsButton
              ludsPaginationPrevious
              buttonType="icon-button"
              variant="tertiary"
              size="small"
              aria-label="Página anterior"
            >
              <ng-icon  name="phosphorCaretLeft"></ng-icon>
            </button>

            <ul>
              @for (p of pagination.visiblePages(); let i = $index; track p + '-' + i) {
              <li>
                @if (p !== '...') {
                <button ludsPaginationButton [ludsPaginationButtonPage]="p">
                  {{ p }}
                </button>
                } @else {
                <button
                  ludsPaginationEllipsis
                  aria-hidden="true"
                  tabindex="-1"
                ></button>
                }
              </li>
              }
            </ul>
            <button
              ludsButton
              ludsPaginationNext
              buttonType="icon-button"
              variant="tertiary"
              size="small"
              aria-label="Próxima página"
            >
              <ng-icon  name="phosphorCaretRight"></ng-icon>
            </button>
            <button
              ludsButton
              ludsPaginationLast
              buttonType="icon-button"
              variant="tertiary"
              size="small"
              aria-label="Última página"
            >
              <ng-icon  name="phosphorCaretDoubleRight"></ng-icon>
            </button>
          </nav>
        </div>
      `,
      hiddenInputs: ["disabled", "hideUnavailable"],
      defaults: {
        page: 2,
        totalItems: 50,
        rangeLabelContext: "produtos",
      },
    },
  },
};

export default Pagination;
