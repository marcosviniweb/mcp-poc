export { PaginationDemoComponent } from './pagination-demo.component';
