{{ NgDocApi.details("libs/ui/blocks/pagination/src/pagination/pagination.ts#LudsPagination") }}

{{ JSDoc.description("libs/ui/blocks/pagination/src/pagination/pagination.ts#LudsPagination") }}

## Playground

{{ NgDocActions.playground("PaginationPlayground") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsPagination } from '@luds/ui/blocks/pagination';

@Component({
  standalone: true,
  imports: [LudsPagination],
  templateUrl: './my-component.html',
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<nav
  ludsPagination
  [ludsPaginationPage]="1"
  [ludsPaginationPageCount]="10"
></nav>
```

## Exemplo

{{ NgDocActions.demo("PaginationDemoComponent") }}

Veja a documentação da API: `ludsPaginationFirst` `ludsPaginationPrevious` `ludsPaginationButton` `ludsPaginationNext` `ludsPaginationLast`
