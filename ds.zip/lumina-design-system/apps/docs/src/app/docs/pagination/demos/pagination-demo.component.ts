import { Component, signal } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { LudsButton } from "@luds/ui/blocks/button";
import { LudsFormField } from "@luds/ui/blocks/form-field";
import { LudsInput } from "@luds/ui/blocks/input";
import { LudsListbox, LudsListboxOption, LudsListboxTrigger } from "@luds/ui/blocks/listbox";
import {
  LudsPagination,
  LudsPaginationButton,
  LudsPaginationFirst,
  LudsPaginationLast,
  LudsPaginationNext,
  LudsPaginationPrevious,
} from "@luds/ui/blocks/pagination";
import { LudsPopover, LudsPopoverTrigger } from "@luds/ui/blocks/popover";
import {
  phosphorCaretDoubleLeft,
  phosphorCaretDoubleRight,
  phosphorCaretLeft,
  phosphorCaretRight,
  phosphorCaretUp,
  phosphorCaretDown,
} from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "pagination-demo",
  imports: [
    LudsPagination,
    LudsPaginationFirst,
    LudsPaginationPrevious,
    LudsPaginationButton,
    LudsPaginationNext,
    LudsPaginationLast,
    LudsButton,
    LudsInput,
    LudsListbox,
    LudsListboxOption,
    LudsListboxTrigger,
    LudsPopover,
    LudsPopoverTrigger,
    LudsFormField,
    NgIcon,
  ],
  providers: [
    provideIcons({
      phosphorCaretDoubleLeft,
      phosphorCaretLeft,
      phosphorCaretRight,
      phosphorCaretDoubleRight,
      phosphorCaretUp,
      phosphorCaretDown,
    }),
  ],
  template: `
    <div ludsPaginationContainer>
      <div ludsPaginationControls>
        <span class="luds-body-medium-default">Itens por página</span>
        <div ludsFormField>
          <input
            ludsInput
            readonly
            ludsListboxTrigger
            [ludsPopoverTrigger]="dropdown"
            #popoverTrigger="ludsPopoverTrigger"
            [value]="pagination.getItemsPerPage()"
          />
          <ng-icon [name]="popoverTrigger.open() ? 'phosphorCaretUp' : 'phosphorCaretDown'"></ng-icon>
          <ng-template #dropdown>
            <div ludsPopover>
              <div
                ludsListbox
                (ludsListboxValueChange)="pagination.setItemsPerPage($event[0])"
                aria-label="Itens por página"
              >
                @for (option of pagination.itemsPerPageOptions(); track option) {
                  <div [ludsListboxOptionValue]="option" ludsListboxOption>
                    {{ option }}
                  </div>
                }
              </div>
            </div>
          </ng-template>
        </div>
        <span class="luds-body-medium-default">{{ pagination.rangeLabel() }}</span>
      </div>
      <nav
        ludsPagination
        #pagination="ludsPagination"
        [(ludsPaginationPage)]="page"
        [ludsPaginationTotalItems]="totalItems()"
        ludsPaginationRangeLabelContext="produtos"
        style="margin: 4px 0"
        aria-label="Paginação"
      >
        <button
          ludsButton
          ludsPaginationFirst
          #first="ludsPaginationFirst"
          [disabled]="first.disabled()"
          buttonType="icon-button"
          variant="tertiary"
          size="small"
          aria-label="Primeira página"
        >
          <ng-icon name="phosphorCaretDoubleLeft"></ng-icon>
        </button>
        <button
          ludsButton
          ludsPaginationPrevious
          #previous="ludsPaginationPrevious"
          [disabled]="previous.disabled()"
          buttonType="icon-button"
          variant="tertiary"
          size="small"
          aria-label="Página anterior"
        >
          <ng-icon name="phosphorCaretLeft"></ng-icon>
        </button>

        <ul>
          @for (p of pagination.visiblePages(); let i = $index; track p + "-" + i) {
            <li>
              @if (p !== "...") {
                <button ludsPaginationButton [ludsPaginationButtonPage]="p">
                  {{ p }}
                </button>
              } @else {
                <button ludsPaginationEllipsis aria-hidden="true" tabindex="-1"></button>
              }
            </li>
          }
        </ul>
        <button
          ludsButton
          ludsPaginationNext
          #next="ludsPaginationNext"
          [disabled]="next.disabled()"
          buttonType="icon-button"
          variant="tertiary"
          size="small"
          aria-label="Próxima página"
        >
          <ng-icon name="phosphorCaretRight"></ng-icon>
        </button>
        <button
          ludsButton
          ludsPaginationLast
          #last="ludsPaginationLast"
          [disabled]="last.disabled()"
          buttonType="icon-button"
          variant="tertiary"
          size="small"
          aria-label="Última página"
        >
          <ng-icon name="phosphorCaretDoubleRight"></ng-icon>
        </button>
      </nav>
    </div>
  `,
  standalone: true,
})
export class PaginationDemoComponent {
  readonly page = signal(2);
  readonly totalItems = signal(90);
}
