import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { NgIcon, provideIcons } from "@ng-icons/core";
import { FormControl, ReactiveFormsModule } from "@angular/forms";
import { LudsDescription, LudsFormField, LudsFormFieldPrefix, LudsLabel } from "@luds/ui/blocks/form-field";
import { LudsCheckbox } from "@luds/ui/blocks/checkbox";
import { LudsInput } from "@luds/ui/blocks/input";
import { LudsListbox, LudsListboxOption, LudsListboxTrigger } from "@luds/ui/blocks/listbox";
import { LudsPopover, LudsPopoverTrigger } from "@luds/ui/blocks/popover";
import { phosphorCheck, phosphorMinus, phosphorCaretUp, phosphorCaretDown } from "@ng-icons/phosphor-icons/regular";

@Component({
  selector: "listbox-multiple-selection-demo",
  imports: [
    CommonModule,
    LudsListbox,
    LudsListboxOption,
    LudsListboxTrigger,
    LudsFormField,
    LudsFormFieldPrefix,
    LudsLabel,
    LudsDescription,
    LudsInput,
    LudsPopover,
    LudsPopoverTrigger,
    LudsCheckbox,
    ReactiveFormsModule,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorCheck, phosphorMinus, phosphorCaretUp, phosphorCaretDown })],
  template: ` <div ludsFormField>
    <label ludsLabel class="luds-body-medium-default">Frutas</label>
    <p ludsDescription class="luds-label-medium-default">Escolha uma ou mais opções.</p>
    <div ludsFormFieldPrefix>
      <button
        ludsCheckbox
        [ludsCheckboxChecked]="isAllSelected()"
        [ludsCheckboxIndeterminate]="isSomeSelected()"
        (ludsCheckboxCheckedChange)="toggleAllSelections($event)"
      >
        @if (isAllSelected()) {
          <ng-icon name="phosphorCheck"></ng-icon>
        } @else if (isSomeSelected()) {
          <ng-icon name="phosphorMinus"></ng-icon>
        }
      </button>
    </div>
    <input
      ludsInput
      readonly
      ludsListboxTrigger
      [ludsPopoverTrigger]="dropdown"
      [formControl]="optionControl"
      #popoverTrigger="ludsPopoverTrigger"
      [value]="selectedOptionNames"
    />
    <ng-icon [name]="popoverTrigger.open() ? 'phosphorCaretUp' : 'phosphorCaretDown'"></ng-icon>
    <ng-template #dropdown>
      <div ludsPopover>
        <div ludsListbox ludsListboxMode="multiple" [(ludsListboxValue)]="optionControl.value" aria-label="Frutas">
          @for (option of options; track option.id) {
            <div [ludsListboxOptionValue]="option" ludsListboxOption>
              <button disabled ludsCheckbox [ludsCheckboxChecked]="isSelected(option)">
                @if (isSelected(option)) {
                  <ng-icon name="phosphorCheck"></ng-icon>
                }
              </button>
              {{ option.name }}
            </div>
          }
        </div>
      </div>
    </ng-template>
  </div>`,
  standalone: true,
})
export class ListboxMultipleSelectionDemoComponent {
  options = [
    { id: 1, name: "Maçã" },
    { id: 2, name: "Banana" },
    { id: 3, name: "Laranja" },
    { id: 4, name: "Uva" },
    { id: 5, name: "Abacaxi" },
  ];

  optionControl = new FormControl<{ id: number; name: string }[]>([], {
    nonNullable: true,
  });

  get selectedOptionNames(): string {
    return this.optionControl.value.map((option) => option.name).join(", ") ?? "";
  }
  isSelected(option: any): boolean {
    return this.optionControl.value?.some((o) => o.id === option.id) || false;
  }

  isAllSelected(): boolean {
    const selected = this.optionControl.value ?? [];
    return selected.length === this.options.length;
  }

  isSomeSelected(): boolean {
    const selected = this.optionControl.value ?? [];
    return selected.length > 0 && selected.length < this.options.length;
  }

  toggleAllSelections(checked: boolean): void {
    if (checked) {
      this.optionControl.setValue([...this.options]);
    } else {
      this.optionControl.setValue([]);
    }
  }
}
