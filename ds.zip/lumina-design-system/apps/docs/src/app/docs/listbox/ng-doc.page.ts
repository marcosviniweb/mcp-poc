import { NgDocPage } from '@ng-doc/core';
import ComponentsCategory from 'apps/docs/src/categories/components/ng-doc.category';
import { ListboxSingleSelectionDemoComponent } from './demos/listbox-single-selection-demo.component';
import { ListboxMultipleSelectionDemoComponent } from './demos/listbox-multiple-selection-demo.component';

const Listbox: NgDocPage = {
  title: `Listbox`,
  mdFile: './index.md',
  category: ComponentsCategory,
  demos: {
    ListboxSingleSelectionDemoComponent,
    ListboxMultipleSelectionDemoComponent,
  },
};

export default Listbox;
