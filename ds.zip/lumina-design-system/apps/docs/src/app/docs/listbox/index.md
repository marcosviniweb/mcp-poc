{{ NgDocApi.details("libs/ui/blocks/listbox/src/listbox/listbox.ts#LudsListbox") }}

{{ JSDoc.description("libs/ui/blocks/listbox/src/listbox/listbox.ts#LudsListbox") }}

## Preview

{{ NgDocActions.demo("ListboxSingleSelectionDemoComponent") }}

## Importação

```typescript name="my-component.ts" group="my-group1"
import { LudsListbox, LudsListboxOption } from '@luds/ui/blocks/listbox';

@Component({
  standalone: true,
  imports: [LudsListbox, LudsListboxOption],
  templateUrl: './my-component.html',
})
export class MyComponent {}
```

```html name="my-component.html" group="my-group1"
<div ludsListbox>
  @for (let option of options; track option.id) {
  <div ludsListboxOption [ludsListboxOptionValue]="option">{{ option.name }}</div>
  }
</div>
```

## Exemplos

### Seleção Única

{{ NgDocActions.demo("ListboxSingleSelectionDemoComponent") }}

### Seleção Múltipla

{{ NgDocActions.demo("ListboxMultipleSelectionDemoComponent") }}
Veja a documentação da API: `ludsSelectionMode`
