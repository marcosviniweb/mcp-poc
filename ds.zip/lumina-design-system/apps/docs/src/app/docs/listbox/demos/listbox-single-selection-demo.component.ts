import { Component } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { NgIcon, provideIcons } from '@ng-icons/core';
import { phosphorCaretUp, phosphorCaretDown } from '@ng-icons/phosphor-icons/regular';
import { LudsDescription, LudsFormField, LudsLabel } from '@luds/ui/blocks/form-field';
import { LudsInput } from '@luds/ui/blocks/input';
import { LudsListbox, LudsListboxOption, LudsListboxTrigger } from '@luds/ui/blocks/listbox';
import { LudsPopover, LudsPopoverTrigger } from '@luds/ui/blocks/popover';

@Component({
  selector: 'listbox-single-selection-demo',
  imports: [
    LudsListbox,
    LudsListboxOption,
    LudsListboxTrigger,
    LudsFormField,
    LudsLabel,
    LudsDescription,
    LudsInput,
    LudsPopover,
    LudsPopoverTrigger,
    ReactiveFormsModule,
    NgIcon,
  ],
  providers: [provideIcons({ phosphorCaretUp, phosphorCaretDown })],
  template: `<div ludsFormField>
    <label ludsLabel class="luds-body-medium-default">Frutas</label>
    <p ludsDescription class="luds-label-medium-default">Escolha uma opção.</p>
    <input
      ludsInput
      readonly
      ludsListboxTrigger
      [ludsPopoverTrigger]="dropdown"
      [formControl]="optionControl"
      #popoverTrigger="ludsPopoverTrigger"
    />
    <ng-icon
      [name]="popoverTrigger.open() ? 'phosphorCaretUp' : 'phosphorCaretDown'"
    ></ng-icon>

    <ng-template #dropdown>
      <div ludsPopover>
        <div
          ludsListbox
          (ludsListboxValueChange)="optionControl.setValue($event[0].name)"
          aria-label="Frutas"
        >
          @for (option of options; track option.id) {
          <div [ludsListboxOptionValue]="option" ludsListboxOption>
            {{ option.name }}
          </div>
          }
        </div>
      </div>
    </ng-template>
  </div>`,
  standalone: true,
})
export class ListboxSingleSelectionDemoComponent {
  options = [
    { id: 1, name: 'Maçã' },
    { id: 2, name: 'Banana' },
    { id: 3, name: 'Laranja' },
    { id: 4, name: 'Uva' },
    { id: 5, name: 'Abacaxi' },
  ];

  optionControl = new FormControl('');
}
