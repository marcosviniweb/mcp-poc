import {
  NgDocRootComponent,
  NgDocNavbarComponent,
  NgDocSidebarComponent,
  NG_DOC_CONTEXT,
  NgDocContext,
} from "@ng-doc/app";
import { AfterViewInit, Component, Inject, Renderer2, OnDestroy } from "@angular/core";
import { RouterModule } from "@angular/router";
import { DOCUMENT } from "@angular/common";
import { Title } from "@angular/platform-browser";
import { capitalizeFirstLetter } from "./utils";

@Component({
  imports: [RouterModule, NgDocRootComponent, NgDocNavbarComponent, NgDocSidebarComponent],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  standalone: true
})
export class AppComponent implements AfterViewInit, OnDestroy {
  private observer?: MutationObserver;
  private bodyObserver?: MutationObserver;
  private pageObserver?: MutationObserver;

  constructor(
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document,
    private titleService: Title,
    @Inject(NG_DOC_CONTEXT) private context: NgDocContext,
  ) {}

  ngAfterViewInit() {
    this.setupMainSearchInput();
    this.setupOverlayObserver();
    this.setupPageObserver();
  }

  ngOnDestroy() {
    if (this.observer) {
      this.observer.disconnect();
    }
    if (this.bodyObserver) {
      this.bodyObserver.disconnect();
    }
    if (this.pageObserver) {
      this.pageObserver.disconnect();
    }
  }

  private setupMainSearchInput(): void {
    const inputSearchBar = this.document.querySelector('ng-doc-search input');

    if (inputSearchBar) {
      this.renderer.setAttribute(inputSearchBar, 'placeholder', 'Pesquisar...');
    }
  }

  private setupOverlayObserver(): void {
    this.observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const element = node as Element;
            const searchInput = element.querySelector('input[placeholder="Find or ask anything..."]') ||
                              element.querySelector('ng-doc-search-dialog input');

            if (searchInput) {
              this.renderer.setAttribute(searchInput, 'placeholder', 'Pesquisar...');
            }
          }
        });
      });
    });
    this.observeBodyForOverlayCreation();
  }

  private observeBodyForOverlayCreation(): void {
    this.bodyObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const element = node as Element;
            if (element.classList?.contains('cdk-overlay-container')) {
              this.bodyObserver?.disconnect();
              this.observer?.observe(element, { childList: true, subtree: true });
            }
          }
        });
      });
    });

    this.bodyObserver.observe(this.document.body, { childList: true, subtree: true });
  }
  private setupPageObserver(): void {
    setTimeout(() => this.onPageContentChange(), 0);

    this.pageObserver = new MutationObserver(() => this.onPageContentChange());

    this.pageObserver.observe(this.document.body, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  }

  private onPageContentChange(): void {
    this.updateTitle();
    this.updateHeaderCategory();
  }

  private updateTitle(): void {
    const h1Element = this.document.querySelector("ng-doc-page-header h1");

    this.titleService.setTitle(
      h1Element ? `Lumina DS - ${capitalizeFirstLetter(h1Element.textContent?.trim() || "")}` : "Lumina DS",
    );
  }

  private updateHeaderCategory(): void {
    const h1Element = this.document.querySelector("ng-doc-page-header h1");
    const href = h1Element?.getAttribute("href");

    if (href && !this.document.querySelector("header.ng-doc-page-header .category-title")) {
      this.addCategoryInHeader(href);
    }
  }

  private addCategoryInHeader(url: string): void {
    const category = this.getCategory(url);
    const header = this.document.querySelector("header.ng-doc-page-header");

    if (!this.shouldAddCategory(header, category)) return;

    this.removePreviousCategory(header!);
    this.insertCategoryElement(header!, category);
  }

  private shouldAddCategory(header: Element | null, category: string): boolean {
    if (!header || !category) return false;

    const existingCategory = header.querySelector(".category-title");
    return existingCategory?.textContent !== category;
  }

  private removePreviousCategory(header: Element): void {
    const existingCategory = header.querySelector(".category-title");
    existingCategory?.remove();
  }

  private insertCategoryElement(header: Element, category: string): void {
    const categoryElement = this.renderer.createElement("div");
    this.renderer.addClass(categoryElement, "category-title");
    this.renderer.setProperty(categoryElement, "textContent", category);

    const h1Element = header.querySelector("h1");
    if (h1Element) {
      header.insertBefore(categoryElement, h1Element);
    }
  }

  private getCategory(url: string): string {
    const slug = url.split("/")?.[0];
    return this.context.navigation.find((cat) => cat.route.includes(slug))?.title || "";
  }
}
