import { NgDocApi } from '@ng-doc/core';
import DevelopmentCategory from './categories/development/ng-doc.category';

const api: NgDocApi = {
  title: 'Referência de API',
  category: DevelopmentCategory,
  scopes: [
    {
      name: '@luds/ui',
      route: '@luds/ui',
      include: 'libs/ui/**/*.ts',
      exclude: 'libs/ui/**/*.spec.ts'
    },
  ],
};

export default api;
