import { NgDocCategory } from '@ng-doc/core';

const DesignTokensCategory: NgDocCategory = {
  title: 'DESIGN TOKENS',
  expanded: true,
  order: 3,
};

export default DesignTokensCategory;
