import { NgDocCategory } from '@ng-doc/core';

const DevelopmentCategory: NgDocCategory = {
  title: 'DESENVOLVIMENTO',
  expanded: true,
  order: 2,
};

export default DevelopmentCategory;
