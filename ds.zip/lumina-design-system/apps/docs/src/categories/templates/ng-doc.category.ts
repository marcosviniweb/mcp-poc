import { NgDocCategory } from '@ng-doc/core';

const TemplatesCategory: NgDocCategory = {
  title: 'TEMPLATES',
  expanded: true,
  order: 5,
};

export default TemplatesCategory;
