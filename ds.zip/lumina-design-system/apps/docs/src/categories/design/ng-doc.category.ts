import { NgDocCategory } from '@ng-doc/core';

const DesignCategory: NgDocCategory = {
  title: 'DESIGN',
  expanded: true,
  order: 1,
};

export default DesignCategory;
