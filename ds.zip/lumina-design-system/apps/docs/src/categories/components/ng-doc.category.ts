import { NgDocCategory } from '@ng-doc/core';

const ComponentsCategory: NgDocCategory = {
  title: 'COMPONENTES',
  expanded: true,
  order: 4,
};

export default ComponentsCategory;
